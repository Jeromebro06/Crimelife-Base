fx_version 'cerulean'
game 'gta5'

shared_script '@warrios_core/imports.lua'

client_scripts {
	'@warrios_core/client/wrapper.lua',
	'menu_default.lua'
}

server_script 'server.lua'



ui_page {
	'html/ui.html'
}

files {
	'html/ui.html',
	'html/css/app.css',
	'html/js/mustache.min.js',
	'html/js/app.js'
}