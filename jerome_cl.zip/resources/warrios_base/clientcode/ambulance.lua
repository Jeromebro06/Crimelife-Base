local firstSpawn = true

isDead, isSearched, medic = false, false, 0

RegisterNetEvent('warrios_core:🌹🌹:playerLoaded')
AddEventHandler('warrios_core:🌹🌹:playerLoaded', function(xPlayer)
  ESX.PlayerLoaded = true
end)

RegisterNetEvent('warrios_core:🌹🌹:onPlayerLogout')
AddEventHandler('warrios_core:🌹🌹:onPlayerLogout', function()
  ESX.PlayerLoaded = false
  firstSpawn = true
end)

AddEventHandler('warrios_core:spawned', function()
  isDead = false
  ClearTimecycleModifier()
  SetPedMotionBlur(PlayerPedId(), false)
  ClearExtraTimecycleModifier()
  EndDeathCam()
  if firstSpawn then
    firstSpawn = false
  end
end)

CreateThread(function()
  while true do
    local Sleep = 1500
    if isDead then
      Sleep = 0
      DisableAllControlActions(0)
      ProcessCamControls()
      if isSearched then
        local playerPed = PlayerPedId()
        local ped = GetPlayerPed(GetPlayerFromServerId(medic))
        isSearched = false
        AttachEntityToEntity(playerPed, ped, 11816, 0.54, 0.54, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
        Wait(1000)
        DetachEntity(playerPed, true, false)
        ClearPedTasksImmediately(playerPed)
      end
    end
    Wait(Sleep)
  end
end)

RegisterNetEvent('esx_ambulancejob:clsearch')
AddEventHandler('esx_ambulancejob:clsearch', function(medicId)
  local playerPed = PlayerPedId()
  if isDead then
    local coords = GetEntityCoords(playerPed)
    local playersInArea = ESX.Game.GetPlayersInArea(coords, 50.0)
    for i = 1, #playersInArea, 1 do
      local player = playersInArea[i]
      if player == GetPlayerFromServerId(medicId) then
        medic = tonumber(medicId)
        isSearched = true
        break
      end
    end
  end
end)

function DoDeathAnimation()
  local ped = PlayerPedId()
  local AnimationLib = 'missarmenian2'
  local AnimationStatus = "corpse_search_exit_ped"
  RequestAnimDict(AnimationLib)
  TaskPlayAnim(ped, AnimationLib, AnimationStatus, 8.0, -8.0, -1, 0, 0, false, false, false)
end

function OnPlayerDeath()
  local playerPed = PlayerPedId()
  isDead = true
  TriggerServerEvent('esx_ambulancejob:setDeathStatus', true)
  ClearPedTasksImmediately(playerPed)
  Wait(20)
  DoDeathAnimation()
  StartDeathTimer()
end

function StartDeathTimer()
  local canPayFine = false
  local earlySpawnTimer = ESX.Math.Round(Config.BleedOutTime / 1000)
  local bleedoutTimer = ESX.Math.Round(0 / 1000)
  CreateThread(function()
    while earlySpawnTimer > 0 and isDead do
      Wait(1000)
      if earlySpawnTimer > 0 then
        earlySpawnTimer = earlySpawnTimer - 1
      end
    end
    while bleedoutTimer > 0 and isDead do
      Wait(1000)
      if bleedoutTimer > 0 then
        bleedoutTimer = bleedoutTimer - 1
      end
    end
  end)
  CreateThread(function()
    local text, timeHeld
    while earlySpawnTimer > 0 and isDead do
      Wait(0)
    end
    while bleedoutTimer > 0 and isDead do
      Wait(0)
    end
    if bleedoutTimer < 1 and isDead then
      RemoveItemsAfterRPDeath()
    end
  end)
end

function GetClosestRespawnPoint()
  local PlyCoords = GetEntityCoords(PlayerPedId())
  local ClosestDist, ClosestHospital, ClosestCoord = 10000, {}, nil
  for k, v in pairs(Config.RespawnPoints) do
    local Distance = #(PlyCoords - vector3(v.coords.x, v.coords.y, v.coords.z))
    if Distance <= ClosestDist then
      ClosestDist = Distance
      ClosestHospital = v
      ClosestCoord = vector3(v.coords.x, v.coords.y, v.coords.z)
    end
  end
  return ClosestCoord, ClosestHospital
end

function RemoveItemsAfterRPDeath()
	TriggerServerEvent('esx_ambulancejob:setDeathStatus', false)
	CreateThread(function()
		ESX.TriggerServerCallback('esx_ambulancejob:removeItemsAfterRPDeath', function()
		local RespawnCoords, ClosestHospital = GetClosestRespawnPoint()
		ESX.SetPlayerData('loadout', {})
		RespawnPed(PlayerPedId(), RespawnCoords, ClosestHospital.heading)
		SetPedArmour(PlayerPedId(), 100)
		end)
	end)
end

function RespawnPed(ped, coords, heading)
	if not exports[GetCurrentResourceName()]:isgw() then
		SetEntityCoordsNoOffset(ped, coords.x, coords.y, coords.z, false, false, false)
		NetworkResurrectLocalPlayer(coords.x, coords.y, coords.z, heading, true, false)
	else
		TriggerEvent('✌✌😉🎶🎉😂💋😍🤞🤞🐱‍👤🐱‍👤😢👍👍👍👍👍')
	end
	SetPlayerInvincible(ped, false)
	ClearPedBloodDamage(ped)
	TriggerServerEvent('warrios_core:spawned')
	TriggerEvent('warrios_core:spawned')
	TriggerEvent('playerSpawned')
	FreezeEntityPosition(PlayerPedId(), false)
end

AddEventHandler('warrios_core:🎂🎂:died', function(data)
    OnPlayerDeath()
end)

RegisterNetEvent('esx_ambulancejob:revive')
AddEventHandler('esx_ambulancejob:revive', function()
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    TriggerServerEvent('esx_ambulancejob:setDeathStatus', false)
    local formattedCoords = {x = ESX.Math.Round(coords.x, 1), y = ESX.Math.Round(coords.y, 1), z = ESX.Math.Round(coords.z, 1)}
    RespawnPed(playerPed, formattedCoords, 0.0)
    SetPedArmour(playerPed, 100)
    isDead = false
    SetPedMotionBlur(playerPed, false)
    ClearExtraTimecycleModifier()
    EndDeathCam()
end)

RequestIpl('Coroner_Int_on') -- Morgue
local cam = nil
local angleY = 0.0
local angleZ = 0.0

function EndDeathCam()
  ClearFocus()
  RenderScriptCams(false, false, 0, true, false)
  DestroyCam(cam, false)
  cam = nil
end

function ProcessCamControls()
  local playerPed = PlayerPedId()
  local playerCoords = GetEntityCoords(playerPed)
  DisableFirstPersonCamThisFrame()
  local newPos = ProcessNewPosition()
  SetFocusArea(newPos.x, newPos.y, newPos.z, 0.0, 0.0, 0.0)
  SetCamCoord(cam, newPos.x, newPos.y, newPos.z)
  PointCamAtCoord(cam, playerCoords.x, playerCoords.y, playerCoords.z + 0.5)
end

function ProcessNewPosition()
    local mouseX = 0.0
    local mouseY = 0.0
    if (IsInputDisabled(0)) then
      mouseX = GetDisabledControlNormal(1, 1) * 8.0
      mouseY = GetDisabledControlNormal(1, 2) * 8.0
    else
      mouseX = GetDisabledControlNormal(1, 1) * 1.5
      mouseY = GetDisabledControlNormal(1, 2) * 1.5
    end
    angleZ = angleZ - mouseX
    angleY = angleY + mouseY
    if (angleY > 89.0) then
      angleY = 89.0
    elseif (angleY < -89.0) then
      angleY = -89.0
    end
    local pCoords = GetEntityCoords(PlayerPedId())
    local behindCam = {x = pCoords.x + ((Cos(angleZ) * Cos(angleY)) + (Cos(angleY) * Cos(angleZ))) / 2 * (5.5 + 0.5),
                      y = pCoords.y + ((Sin(angleZ) * Cos(angleY)) + (Cos(angleY) * Sin(angleZ))) / 2 * (5.5 + 0.5),
                      z = pCoords.z + ((Sin(angleY))) * (5.5 + 0.5)}
    local rayHandle = StartShapeTestRay(pCoords.x, pCoords.y, pCoords.z + 0.5, behindCam.x, behindCam.y, behindCam.z, -1, PlayerPedId(), 0)
    local a, hitBool, hitCoords, surfaceNormal, entityHit = GetShapeTestResult(rayHandle)
    local maxRadius = 1.9
    if (hitBool and Vdist(pCoords.x, pCoords.y, pCoords.z + 0.5, hitCoords) < 5.5 + 0.5) then
      maxRadius = Vdist(pCoords.x, pCoords.y, pCoords.z + 0.5, hitCoords)
    end
    local offset = {x = ((Cos(angleZ) * Cos(angleY)) + (Cos(angleY) * Cos(angleZ))) / 2 * maxRadius,
                    y = ((Sin(angleZ) * Cos(angleY)) + (Cos(angleY) * Sin(angleZ))) / 2 * maxRadius, z = ((Sin(angleY))) * maxRadius}
    local pos = {x = pCoords.x + offset.x, y = pCoords.y + offset.y, z = pCoords.z + offset.z}
    return pos
end


----------------------------------------------------
local FirstSpawn     = true
local LastSkin       = nil
local PlayerLoaded   = false
local cam            = nil
local isCameraActive = false
local zoomOffset     = 0.0
local camOffset      = 0.0
local heading        = 90.0

function OpenMenu(submitCb, cancelCb, restrict)
	local playerPed = PlayerPedId()
	TriggerEvent('wallahduhastnenkleinen:duhurenshohnSkin', function(skin)
		LastSkin = skin
	end)
	TriggerEvent('wallahduhastnenkleinen:duhurenshohnData', function(components, maxVals)
		local elements    = {}
		local _components = {}
		if restrict == nil then
			for i=1, #components, 1 do
				_components[i] = components[i]
			end
		else
			for i=1, #components, 1 do
				local found = false
				for j=1, #restrict, 1 do
					if components[i].name == restrict[j] then
						found = true
					end
				end
				if found then
					table.insert(_components, components[i])
				end
			end
		end
		for i=1, #_components, 1 do
			local value       = _components[i].value
			local componentId = _components[i].componentId
			if componentId == 0 then
				value = GetPedPropIndex(playerPed, _components[i].componentId)
			end
			local data = {
				label     = _components[i].label,
				name      = _components[i].name,
				value     = value,
				min       = _components[i].min,
				textureof = _components[i].textureof,
				zoomOffset= _components[i].zoomOffset,
				camOffset = _components[i].camOffset,
				type      = 'slider'
			}
			for k,v in pairs(maxVals) do
				if k == _components[i].name then
					data.max = v
					break
				end
			end
			table.insert(elements, data)
		end
		CreateSkinCam()
		zoomOffset = _components[1].zoomOffset
		camOffset = _components[1].camOffset
		ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'skin', {
			title    = 'Skin Menu',
			align    = 'top-left',
			elements = elements
		}, function(data, menu)
			TriggerEvent('wallahduhastnenkleinen:duhurenshohnSkin', function(skin)
				LastSkin = skin
			end)
			submitCb(data, menu)
			DeleteSkinCam()
		end, function(data, menu)
			menu.close()
			DeleteSkinCam()
			TriggerEvent('wallahduhastnenkleinen:gebmaherSkin', LastSkin)
			if cancelCb ~= nil then
				cancelCb(data, menu)
			end
		end, function(data, menu)
			local skin, components, maxVals
			TriggerEvent('wallahduhastnenkleinen:duhurenshohnSkin', function(getSkin)
				skin = getSkin
			end)
			zoomOffset = data.current.zoomOffset
			camOffset = data.current.camOffset
			if skin[data.current.name] ~= data.current.value then
				TriggerEvent('wallahduhastnenkleinen:change', data.current.name, data.current.value)
				TriggerEvent('wallahduhastnenkleinen:duhurenshohnData', function(comp, max)
					components, maxVals = comp, max
				end)
				local newData = {}
				for i=1, #elements, 1 do
					newData = {}
					newData.max = maxVals[elements[i].name]
					if elements[i].textureof ~= nil and data.current.name == elements[i].textureof then
						newData.value = 0
					end
					menu.update({name = elements[i].name}, newData)
				end
				menu.refresh()
			end
		end, function(data, menu)
			DeleteSkinCam()
		end)
	end)
end

function CreateSkinCam()
	if not DoesCamExist(cam) then
		cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
	end
	SetCamActive(cam, true)
	RenderScriptCams(true, true, 500, true, true)
	isCameraActive = true
	SetCamRot(cam, 0.0, 0.0, 270.0, true)
	SetEntityHeading(playerPed, 90.0)
end

function DeleteSkinCam()
	isCameraActive = false
	SetCamActive(cam, false)
	RenderScriptCams(false, true, 500, true, true)
	cam = nil
end

CreateThread(function()
	while true do
		Wait(0)
		if isCameraActive then
			DisableControlAction(2, 30, true)
			DisableControlAction(2, 31, true)
			DisableControlAction(2, 32, true)
			DisableControlAction(2, 33, true)
			DisableControlAction(2, 34, true)
			DisableControlAction(2, 35, true)
			DisableControlAction(0, 25, true)
			DisableControlAction(0, 24, true)
			local playerPed = PlayerPedId()
			local coords    = GetEntityCoords(playerPed)
			local angle = heading * math.pi / 180.0
			local theta = {
				x = math.cos(angle),
				y = math.sin(angle)
			}
			local pos = {
				x = coords.x + (zoomOffset * theta.x),
				y = coords.y + (zoomOffset * theta.y)
			}
			local angleToLook = heading - 140.0
			if angleToLook > 360 then
				angleToLook = angleToLook - 360
			elseif angleToLook < 0 then
				angleToLook = angleToLook + 360
			end
			angleToLook = angleToLook * math.pi / 180.0
			local thetaToLook = {
				x = math.cos(angleToLook),
				y = math.sin(angleToLook)
			}
			local posToLook = {
				x = coords.x + (zoomOffset * thetaToLook.x),
				y = coords.y + (zoomOffset * thetaToLook.y)
			}
			SetCamCoord(cam, pos.x, pos.y, coords.z + camOffset)
			PointCamAtCoord(cam, posToLook.x, posToLook.y, coords.z + camOffset)
		else
			Wait(1000)
		end
	end
end)

CreateThread(function()
	local angle = 90
	while true do
		Wait(0)
		if isCameraActive then
			if IsControlPressed(0, 9) then
				angle = angle - 2
			elseif IsControlPressed(0, 23) then
				angle = angle + 2
			end
			if angle > 360 then
				angle = angle - 360
			elseif angle < 0 then
				angle = angle + 360
			end
			heading = angle + 0.0
		else
			Wait(1000)
		end
	end
end)

function OpenSaveableMenu(submitCb, cancelCb, restrict)
	TriggerEvent('wallahduhastnenkleinen:duhurenshohnSkin', function(skin)
		LastSkin = skin
	end)
	OpenMenu(function(data, menu)
		menu.close()
		DeleteSkinCam()
		TriggerEvent('wallahduhastnenkleinen:duhurenshohnSkin', function(skin)
			TriggerServerEvent('esx_skin:save', skin)
			if submitCb ~= nil then
				submitCb(data, menu)
			end
		end)
	end, cancelCb, restrict)
end

AddEventHandler('playerSpawned', function()
	CreateThread(function()
		while not PlayerLoaded do
			Wait(10)
		end
		if FirstSpawn then
			ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
				if skin == nil then
					TriggerEvent('wallahduhastnenkleinen:gebmaherSkin', {sex = 0}, OpenSaveableMenu)
				else
					TriggerEvent('wallahduhastnenkleinen:gebmaherSkin', skin)
				end
			end)
			FirstSpawn = false
		end
	end)
end)

RegisterNetEvent('warrios_core:🌹🌹:playerLoaded')
AddEventHandler('warrios_core:🌹🌹:playerLoaded', function(xPlayer)
	PlayerLoaded = true
end)

AddEventHandler('esx_skin:getLastSkin', function(cb)
	cb(LastSkin)
end)

AddEventHandler('esx_skin:setLastSkin', function(skin)
	LastSkin = skin
end)

RegisterNetEvent('esx_skin:openMenu')
AddEventHandler('esx_skin:openMenu', function(submitCb, cancelCb)
	OpenMenu(submitCb, cancelCb, nil)
end)

RegisterNetEvent('esx_skin:openRestrictedMenu')
AddEventHandler('esx_skin:openRestrictedMenu', function(submitCb, cancelCb, restrict)
	OpenMenu(submitCb, cancelCb, restrict)
end)

RegisterNetEvent('esx_skin:openSaveableMenu')
AddEventHandler('esx_skin:openSaveableMenu', function(submitCb, cancelCb)
	OpenSaveableMenu(submitCb, cancelCb, nil)
end)

RegisterNetEvent('esx_skin:openSaveableRestrictedMenu')
AddEventHandler('esx_skin:openSaveableRestrictedMenu', function(submitCb, cancelCb, restrict)
	OpenSaveableMenu(submitCb, cancelCb, restrict)
end)

RegisterNetEvent('esx_skin:requestSaveSkin')
AddEventHandler('esx_skin:requestSaveSkin', function()
	TriggerEvent('wallahduhastnenkleinen:duhurenshohnSkin', function(skin)
		TriggerServerEvent('esx_skin:responseSaveSkin', skin)
	end)
end)