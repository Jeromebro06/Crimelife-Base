local playergroup, fps, zeyzkleiderschrank  = "user", false, "esx_skin:openSaveableMenu"
local aduty, seconds, isDead = false, 5, false
local src, playerjob, zeysniereistseinjob, coordsp, blipev, nachtmodus, afk = nil, nil, nil, nil, nil, false, false
local sended, carsended, ziehalr, abg, zcool, eventactive = false, false, false, false, false, false
local defaultsize = 150.0
local hits = 2
local afkTime = 0
local wetter = 'wa'
local gwactive = false
local zbjob = 'fraklos'
local isBikeSpawned = false
local lastSpawnTime = 0
local cooldown = 45
local currentBike = nil
local drawfps = false
local iseventactive = false
local eventcoords = nil
local hu = false
local speakindicator = false
local onlypistol = false

local _wheel, _base, _lights1, _lights2, _arrow1, _arrow2 = nil, nil, nil, nil, nil, nil
local model1 = GetHashKey('vw_prop_vw_luckywheel_02a')
local model2 = GetHashKey('vw_prop_vw_luckywheel_01a')
local m1a = GetHashKey('vw_prop_vw_luckylight_off')
local m1b = GetHashKey('vw_prop_vw_luckylight_on')
local m2a = GetHashKey('vw_prop_vw_jackpot_off')
local m2b = GetHashKey('vw_prop_vw_jackpot_on')
local WheelPos = vector4(-2264.4128, 3248.2031, 32.0, 106.7244)
local _isRolling = false

RegisterKeyMapping('mainmenu', "Main Menü", "keyboard", "f1")
RegisterKeyMapping('heal', "Heal / Weste", "keyboard", "g")
RegisterKeyMapping("cancelweste", "Weste Ziehen abbrechen", "keyboard", 'e')
RegisterKeyMapping('handsup', "Hände hoch", "keyboard", "h")
RegisterKeyMapping('cycleproximity', "Voice Range ändern", "keyboard", "y")
RegisterKeyMapping('spawnbike', "Spawn BF400", "keyboard", "l")
RegisterKeyMapping('+radiotalk', 'Funk Animation', 'keyboard', 'M')

RegisterKeyMapping('aduty', "Aduty", "keyboard", "f9")
RegisterKeyMapping("+noclip", "NoClip", "keyboard", "u")
RegisterKeyMapping('+chat', "Chat", "keyboard", "t")

function successnotify(washaterzusagen)
    TriggerEvent('notifications', "g", "Warrios - System", washaterzusagen)
end

function warningnotify(washaterzusagen)
    TriggerEvent('notifications', "r", "Warrios - System", washaterzusagen)
end

for _, info in pairs(Config.blips) do
    info.blip = AddBlipForCoord(info.coords)
    SetBlipSprite(info.blip, info.id)
    SetBlipDisplay(info.blip, 4)
    SetBlipScale(info.blip, info.sprite)
    SetBlipColour(info.blip, info.colour)
    SetBlipAsShortRange(info.blip, true)
    if info.enabletitle then
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(info.title)
        EndTextCommandSetBlipName(info.blip)
    end
end

function updateweather()
    if wetter == 'wa' then
        SetWeatherTypePersist("EXTRASUNNY")
        SetWeatherTypeNow("EXTRASUNNY")
        SetWeatherTypeNowPersist("EXTRASUNNY")
    elseif wetter == 'wb' then
        SetWeatherTypePersist("RAIN")
        SetWeatherTypeNow("RAIN")
        SetWeatherTypeNowPersist("RAIN")
    elseif wetter == 'wc' then
        SetWeatherTypePersist("XMAS")
        SetWeatherTypeNow("XMAS")
        SetWeatherTypeNowPersist("XMAS")
    end
end

function updatetime()
    if nachtmodus then
        NetworkOverrideClockTime(00, 00, 00)
    else
        NetworkOverrideClockTime(13, 00, 00)
    end
end

function NameTag(x, y, z, text, size)
    local _, _x, _y = World3dToScreen2d(x, y, z)
    SetTextScale(size, size)
    SetTextFont(4)
    SetTextColour(255, 255, 255, 255)
    SetTextDropShadow()
    SetTextProportional(1)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x, _y)
end

function reloadhud()
    ESX.TriggerServerCallback("kd", function(players, job, kd, kills, tode, xp, money)
        zbjob = job
        if job == "unemployed" then job = "fraklos" end
        SetDiscordAppId(Config.DiscordPrescence["appid"])
        SetDiscordRichPresenceAsset(Config.DiscordPrescence["logoname"])
        SetDiscordRichPresenceAssetText(Config.DiscordPrescence["servername"])
        SetDiscordRichPresenceAssetSmall(Config.DiscordPrescence["logoname"])
        SetDiscordRichPresenceAssetSmallText(Config.DiscordPrescence["servername"])
        SetDiscordRichPresenceAction(0, "Discord", Config.DiscordPrescence["discord"])
        SetRichPresence(GetPlayerName(PlayerId()) .. " | " .. players .. " Spieler | "..job)
        if xp then
            lvl = math.floor(xp / 1000) or 0
        end
        SendNUIMessage({
            action = 'hud',
            kd = kd,
            kill = kills, 
            tod = tode,
            lvl = lvl,
            money = money,
            id = GetPlayerServerId(PlayerId()),
        })
    end)
end

CreateThread(function()
    Wait(2000)
    reloadhud()
    while true do 
        reloadhud()
        Wait(15000)
    end
end)

RegisterCommand("id", function()
    successnotify("Deine ID: "..GetPlayerServerId(PlayerId()).."")
end)

local carry = {
	InProgress = false,
	targetSrc = -1,
	type = "",
	personCarrying = {
		animDict = "missfinale_c2mcs_1",
		anim = "fin_c2_mcs_1_camman",
		flag = 49,
	},
	personCarried = {
		animDict = "nm",
		anim = "firemans_carry",
		attachX = 0.27,
		attachY = 0.15,
		attachZ = 0.63,
		flag = 33,
	}
}

local function ensureAnimDict(animDict)
    if not HasAnimDictLoaded(animDict) then
        RequestAnimDict(animDict)
        while not HasAnimDictLoaded(animDict) do
            Wait(0)
        end      
    end
    return animDict
end

RegisterCommand("carry",function(source, args)
    if playergroup ~= "user" then
        if aduty then
            if not carry.InProgress then
                local closestPlayer, dist = ESX.Game.GetClosestPlayer()
                if closestPlayer and dist <= 3 then
                    local targetSrc = GetPlayerServerId(closestPlayer)
                    if targetSrc ~= -1 and targetSrc ~= 0 then
                        carry.InProgress = true
                        carry.targetSrc = targetSrc
                        TriggerServerEvent("🎫🎫🎫🎭🎭🎭🧵🧵🎐🎆🎫🎫",targetSrc)
                        ensureAnimDict(carry.personCarrying.animDict)
                        carry.type = "carrying"
                    else
                        warningnotify("Keiner in der nähe!")
                    end
                else
                    warningnotify("Keiner in der nähe!")
                end
            else
                carry.InProgress = false
                ClearPedSecondaryTask(PlayerPedId())
                DetachEntity(PlayerPedId(), true, false)
                TriggerServerEvent("🎏🎏🎏🎨🎨🎨🥿🥿🥿⚾⚾⚾", carry.targetSrc)
                carry.targetSrc = 0
            end
        else
            warningnotify("Dafür musst du im Aduty sein!")
        end
    else
        warningnotify("Keine Rechte")
    end
end, false)

RegisterCommand("cancelweste", function()
    local playerPed = PlayerPedId()
    if ziehalr then
        exports[GetCurrentResourceName()]:progress(0, false, '')
        zcool = true
        abg = true
        ziehalr = false
        warningnotify("Weste ziehen abgebrochen")
        FreezeEntityPosition(playerPed, false)
        ClearPedTasks(playerPed)
    end
end)

RegisterNetEvent("🎫🎫🎫🎫🎫🎞🎀🎨🎏🎪🧵🎠🎭🎫🎫🎫")
AddEventHandler("🎫🎫🎫🎫🎫🎞🎀🎨🎏🎪🧵🎠🎭🎫🎫🎫", function(targetSrc)
	local targetPed = GetPlayerPed(GetPlayerFromServerId(targetSrc))
	carry.InProgress = true
	ensureAnimDict(carry.personCarried.animDict)
	AttachEntityToEntity(PlayerPedId(), targetPed, 0, carry.personCarried.attachX, carry.personCarried.attachY, carry.personCarried.attachZ, 0.5, 0.5, 180, false, false, false, false, 2, false)
	carry.type = "beingcarried"
end)

RegisterNetEvent("🎞🎞🎞🎞🎞🎞🎫🎏🎏🎏🎏")
AddEventHandler("🎞🎞🎞🎞🎞🎞🎫🎏🎏🎏🎏", function()
	carry.InProgress = false
	ClearPedSecondaryTask(PlayerPedId())
	DetachEntity(PlayerPedId(), true, false)
end)

local safezonein = false
CreateThread(function()
    while true do
        Wait(0)
        local found = false
        local playerPed = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        for k, radius in pairs(Config.Safezones) do
            local dist = #(GetEntityCoords(playerPed) - k)
            if dist <= (radius + 40.0) then
                DrawMarker(28, k.x, k.y, k.z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, radius, radius, (radius / 3 * 2.5), 200, 0, 255, 120, false, false, 2, false, false, false, false)
                found = true
                if dist <= radius then
                    if not safezonein then
                        safezonein = true
                        NetworkSetFriendlyFireOption(false)
                        SetEntityCanBeDamaged(vehicle, false)
                        DisablePlayerFiring(playerPed, true)
                        SetPlayerCanDoDriveBy(playerPed, false)
                        SetVehicleMaxSpeed(vehicle, 10.0)
                        successnotify('Safezone betreten')
                    else
                        NetworkSetFriendlyFireOption(false)
                        DisablePlayerFiring(playerPed, true)
                        SetPlayerCanDoDriveBy(playerPed, false)
                        DisableControlAction(0, 106, true)
                        DisableControlAction(0, 24, true)
                        DisableControlAction(0, 69, true)
                        DisableControlAction(0, 70, true)
                        DisableControlAction(0, 92, true)
                        DisableControlAction(0, 114, true)
                        DisableControlAction(0, 257, true)
                        DisableControlAction(0, 331, true)
                        DisableControlAction(0, 68, true)
                        DisableControlAction(0, 263, true)
                        DisableControlAction(0, 264, true)
                    end
                elseif safezonein then
                    safezonein = false
                    NetworkSetFriendlyFireOption(true)
                    SetVehicleMaxSpeed(vehicle, 1000.0)
                    SetEntityCanBeDamaged(vehicle, true)
                    successnotify('Safezone verlassen')
                end
            end
        end
        if not found then
            Wait(500)
            if safezonein then
                safezonein = false
                NetworkSetFriendlyFireOption(true)
                SetVehicleMaxSpeed(vehicle, 1000.0)
                SetEntityCanBeDamaged(vehicle, true)
            end
        end
    end
end)

CreateThread(function()
    while true do
        local sleep = 1000
        if carry.InProgress then
            sleep = 0
			if carry.type == "beingcarried" then
				if not IsEntityPlayingAnim(PlayerPedId(), carry.personCarried.animDict, carry.personCarried.anim, 3) then
					TaskPlayAnim(PlayerPedId(), carry.personCarried.animDict, carry.personCarried.anim, 8.0, -8.0, 100000, carry.personCarried.flag, 0, false, false, false)
				end
			elseif carry.type == "carrying" then
				if not IsEntityPlayingAnim(PlayerPedId(), carry.personCarrying.animDict, carry.personCarrying.anim, 3) then
					TaskPlayAnim(PlayerPedId(), carry.personCarrying.animDict, carry.personCarrying.anim, 8.0, -8.0, 100000, carry.personCarrying.flag, 0, false, false, false)
				end
			end
		end
        Wait(sleep)
    end
end)

CreateThread(function()
    while true do
        local sleep = 1500
        local playerPed = PlayerPedId()
        local playerId = PlayerId()
        if IsPedInAnyVehicle(playerPed, false) then
            DisablePlayerVehicleRewards(playerId)
            sleep = 0
            carsended = false
            local vehicle = GetVehiclePedIsIn(playerPed, false)
            local speed = math.floor(GetEntitySpeed(vehicle) * 3.6)
            local engineLoadPercentage = 0
            if speed > 0 then
                local engineLoad = GetVehicleCurrentRpm(vehicle) ^ 3
                engineLoadPercentage = math.ceil(engineLoad * 100)
            end
            SendNUIMessage({
                action = 'carhud',
                enable = true,
                eng = engineLoadPercentage,
                speed = speed
            })
        else
            if not carsended then
                carsended = true
                SendNUIMessage({
                    action = 'carhud',
                    enable = false,
                })
            end
            if isBikeSpawned and currentBike then
                DeleteVehicle(currentBike)
                currentBike = nil
                isBikeSpawned = false
            end
        end
        Wait(sleep)
    end
end)

CreateThread(function()
    ClearPlayerWantedLevel(PlayerId())
    SetMaxWantedLevel(0)
    ReplaceHudColour(116, 49)
        local textEntries = {
        ['PM_SCR_INF'] = "",
        ['PM_SCR_STA'] = "",
        ['PM_SCR_SET'] = "~q~Einstellungen",
        ['PM_SCR_GAL'] = "",
        ['PM_SCR_RPL'] = "",
        ['PM_PANE_CFX'] = "~q~Warrios Tasten",
        ['PM_SCR_GAM'] = "~q~Leave Server",
        ['PM_SCR_MAP'] = "~q~Warrios Map",
        ['PM_PANE_LEAVE'] = "~p~Trennen von Warrios Crimelife~s~",
        ['FE_THDR_GTAO'] = '~q~Warrios Crimelife - ID:'..GetPlayerServerId(PlayerId()),
        ['PM_PANE_QUIT'] = "~p~FiveM Schliesen"
    }
    
    for entry, value in pairs(textEntries) do
        AddTextEntry(entry, value)
    end
    while true do
        Wait(0)
        local playerPed = PlayerPedId()
        local playerID = PlayerId()
        local health = GetEntityHealth(playerPed)
        local weapon = GetSelectedPedWeapon(playerPed)
        local myCoords = GetEntityCoords(playerPed)
        RestorePlayerStamina(playerID, 1.0)
        if IsPedArmed(playerPed, 4) then
            DisableControlAction(1, 140, true)  -- Disable Melee Attack Light
            DisableControlAction(1, 141, true)  -- Disable Melee Attack Heavy
            DisableControlAction(1, 142, true)  -- Disable Melee Attack Alternative
            SetPedInfiniteAmmo(playerPed, true, weapon)
            SetPedInfiniteAmmoClip(playerPed, false)
            SetWeaponRecoilShakeAmplitude(weapon, 0.0)
        end

        if onlypistol then
            local weapontype = GetWeapontypeGroup(weapon)
            if weapontype ~= 416676503 and weapontype ~= 2685387236 and weapontype ~= -1609580060 or weapon == GetHashKey('weapon_appistol') then
                SetCurrentPedWeapon(playerPed, GetHashKey('WEAPON_UNARMED'), true)
            end
        end

        if fps then
            DisableOcclusionThisFrame()
            SetDisableDecalRenderingThisFrame()
        end

        if aduty then
            for _, player in ipairs(GetActivePlayers()) do
                local otherCoords = GetEntityCoords(GetPlayerPed(player))
                local distance = #(myCoords - otherCoords)
                if distance <= 50.0 then
                    local playerID = GetPlayerServerId(player)
                    local playerName = GetPlayerName(player)
                    local displayName = NetworkIsPlayerTalking(player) 
                                        and string.format("~w~[📢] %s - %s", playerID, playerName) 
                                        or string.format("~w~%s - %s", playerID, playerName)
                    NameTag(otherCoords.x, otherCoords.y, otherCoords.z + 1.1, displayName, 0.31)
                    DrawLine(myCoords, otherCoords, 255, 255, 255, 255)
                end
            end
        end

        if speakindicator then
            for _, player in ipairs(GetActivePlayers()) do
                if player ~= playerID then
                    local otherCoords = GetEntityCoords(GetPlayerPed(player))
                    local distance = #(myCoords - otherCoords)
                    if distance <= 30.0 and NetworkIsPlayerTalking(player) and IsEntityVisible(GetPlayerPed(player)) then
                        DrawMarker(2, otherCoords.x, otherCoords.y, otherCoords.z + 1.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, -0.1, -0.1, -0.1, 230, 0, 255, 255, false, false, 2, false, false, false, false)
                        DrawMarker(27, otherCoords.x, otherCoords.y, otherCoords.z - 1.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 0.8, 0.8, 1.0, 200, 0, 255, 120, false, false, 2, false, false, false, false)
                    end
                end
            end
        end

        if IsPauseMenuActive() then
            exports[GetCurrentResourceName()]:disablehud()
        end

        if health <= 2 and not IsDead then
            IsDead = true
            if not sended then
                sended = true
                local killerPlayerId = GetPlayerServerId(NetworkGetPlayerIndexFromPed(GetPedSourceOfDeath(PlayerPedId())))
                TriggerServerEvent('🍿🍿🌭🌭🌭🍞🥪🥪🥟🥟🥩🧀🥪🌯🌯🥫🥫🍛🍚', killerPlayerId)
                TriggerEvent('diedingw', killerPlayerId)
            end
        end

        if IsDead then
            exports[GetCurrentResourceName()]:setAutoSpawn(false)
            IsPedDeath()
        end

        if eventactive and not gwactive then
            DrawMarker(28, coordsp.x, coordsp.y, coordsp.z-10.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, eventsize, eventsize, 99999.0, 0, 0, 255, 170, false, false, 2, false, false, false, false)
        end
    end
end)

CreateThread(function()
    while true do
        gwactive = exports[GetCurrentResourceName()]:isgw()
        updateweather()
        updatetime()
        if Player(GetPlayerServerId(PlayerId())).state then
            playergroup = Player(GetPlayerServerId(PlayerId())).state.group
        end
        local dist = #(GetEntityCoords(PlayerPedId()) - vector3(-1004.2165, -3235.7639, 13.9444))
        if dist <= 170 then
            onlypistol = true
        else
            onlypistol = false
        end
        Wait(5000)
    end
end)

CreateThread(function()
    while true do
        local playerPed = PlayerPedId()
        Wait(1000)
        if zcool then
            Wait(1500)
            zcool = false
        end
        SetPedAccuracy(playerPed, 100)
        SetCamShakeAmplitude(playerPed, 0.2)
        ClearPedBloodDamage(playerPed)
        RestorePlayerStamina(playerPed, 1.0)
        StatSetInt("MP0_STAMINA", 100, true)
        SetPlayerHealthRechargeMultiplier(PlayerId(), 0.0)
        local isPedStill = IsPedStill(playerPed)
        local isPedInAnyVehicle = IsPedInAnyVehicle(playerPed)
        local isNuiFocused = IsNuiFocused()
        local isPauseMenuActive = IsPauseMenuActive()
        local isEntityVisible = IsEntityVisible(playerPed)
        if not isPedInAnyVehicle and not isNuiFocused and not isPauseMenuActive and isEntityVisible and not safezonein then
            if isPedStill then
                afkTime = afkTime + 1
            else
                if afkTime > 35 then
                    if afkTime > 60 then
                        local minutes = math.floor(afkTime / 60)
                        successnotify('du warst ' .. minutes .. ' Minute(n) AFK')
                    else
                        successnotify('du warst ' .. afkTime .. ' Sekunden AFK')
                    end
                    TriggerServerEvent('🌭🌭🌭🥪🍜🥩🧀🥐🥐🥟🥗', afkTime)
                    EnableAFK(false)
                end
                afkTime = 0
            end
        else
            afkTime = 0
        end
        afk = afkTime > 35
        EnableAFK(afk)
        if seconds > 0 and IsDead == true then
            seconds = seconds - 1
        end
        if eventactive and not gwactive then
            SendNUIMessage({
                action = "health",
                health = math.floor((GetEntityHealth(PlayerPedId())-100)),
                armor = math.floor(GetPedArmour(PlayerPedId()))
            })
        end
    end
end)

CreateThread(function()
    while true do
        local sleep = 1500
        if(#(GetEntityCoords(PlayerPedId()) - vector3(WheelPos.x, WheelPos.y, WheelPos.z)) < 1.7) and not _isRolling then
            sleep = 0
            exports[GetCurrentResourceName()]:showE('UM AM GLÜCKSRAD ZU DREHEN')
            if IsControlJustReleased(0, 38) then
                TriggerServerEvent('�@:🐈���⚽:�(B0😊Eh�IL�')
            end
        end
        Wait(sleep)
    end
end)

CreateThread(function()
    while true do
        if eventactive and not gwactive then
            Wait(1000)
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local distance = #(coordsp - playerCoords)
            RemoveBlip(blipev)
            addblip()
            if eventsize > 20.0 then
                eventsize = eventsize - 0.5
            end
            if eventsize == 20 then
                if GetEntityHealth(playerPed) >= 20 then
                    hits = 6
                else
                    hits = 10
                end
            end
            if distance < 1500.0 then
                SendNUIMessage({
                    type = "enableeventud",
                    enable = true,
                    time = math.floor((eventsize - 20)*2) .." sec"
                })
            else
                SendNUIMessage({
                    type = "enableeventud",
                    enable = false,
                    time = nil
                })
            end
            if distance > eventsize then
                if distance < 1500.0 then
                    if not aduty then
                        SetEntityHealth(playerPed, GetEntityHealth(playerPed) -hits)
                    end
                end
            end
        else
            eventsize = defaultsize
            hits = 2
            RemoveBlip(blipev)
            SendNUIMessage({
                type = "enableeventud",
                enable = false,
                time = nil
            })
            Wait(5000)
        end
    end
end)

RegisterCommand('heal', function()
    local playerPed = PlayerPedId()
    if not ziehalr then
        if not zcool then 
            ziehalr = true
            abg = false
            ensureAnimDict('anim@heists@narcotics@funding@gang_idle')
            TaskPlayAnim(playerPed, "anim@heists@narcotics@funding@gang_idle" ,"gang_chatting_idle01", 8.0, -8.0, -1, 1, 0, false, false, false)
            FreezeEntityPosition(playerPed, true)
            exports[GetCurrentResourceName()]:progress(3500, true, 'Ziehe Weste / Heal ...')
            Wait(3500)
            exports[GetCurrentResourceName()]:progress(0, false, '')
            if not abg then
                ziehalr = false
                zcool = true
                ClearPedTasks(playerPed)
                ClearPedTasksImmediately(playerPed)
                FreezeEntityPosition(playerPed, false)
                AddArmourToPed(playerPed, 100)
                SetEntityHealth(playerPed, 200)
                successnotify('Du hast eine Weste gezogen')
            end
        else
            warningnotify("Du musst kurz warten!")
        end
    else
        warningnotify("Du ziehst bereits eine Weste")
    end
end)

RegisterNetEvent('notifications')
AddEventHandler('notifications', function(zeyshautfarbe, zeyzinfowannerdrankommt, washatzeywohlzusagendieserhuan)
    local msg = washatzeywohlzusagendieserhuan
    if string.find(msg, '<') or string.find(msg, '>') or string.find(msg, '<video') or string.find(msg, '<img') or string.find(msg, '<script') or string.find(msg, 'http://') or string.find(msg, 'https://') or string.find(msg, '.png') or string.find(msg, '.jpg')  or string.find(msg, '.jpeg') then
        return
    end
    if zeyshautfarbe ~= "g" and zeyshautfarbe ~= "r" and zeyshautfarbe ~= "y"  and zeyshautfarbe ~= "t" then
        SendNUIMessage({
            action = 'notify',
            type = "g",
            title = zeyzinfowannerdrankommt,
            message = washatzeywohlzusagendieserhuan    
        })
	else
		SendNUIMessage({
            action = 'notify',
            type = zeyshautfarbe,
            title = zeyzinfowannerdrankommt,
            message = washatzeywohlzusagendieserhuan    
        })
    end
    PlaySoundFrontend(-1, "ATM_WINDOW", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1)
end)

RegisterNetEvent('💞💞💞💞💞💞💞💞💞☪🛹🛹')
AddEventHandler('💞💞💞💞💞💞💞💞💞☪🛹🛹', function(message, time)
    SendNUIMessage({
        action = 'announce',
        message = message,
        time = time
    })
    Wait(500)
    PlaySoundFrontend(-1, "Dropped", "HUD_FRONTEND_MP_COLLECTABLE_SOUNDS", 1)
end)

RegisterNetEvent("💚💚💚💚💕💞🛐🕳💫💫💤✝✝")
AddEventHandler("💚💚💚💚💕💞🛐🕳💫💫💤✝✝", function()
    SetEntityHealth(PlayerPedId(), 200)
    SetPedArmour(PlayerPedId(), 100)
end)

RegisterCommand('fps', function()
    fps = not fps
    if fps then
        ClearOverrideWeather()
        ClearWeatherTypePersist()
        SetWeatherTypePersist('CLEAR')
        SetWeatherTypeNow('CLEAR')
        SetWeatherTypeNowPersist('CLEAR')
        SetTimecycleModifier("cinema")
        SetForceVehicleTrails(false)
        SetForcePedFootstepsTracks(false)
        SetRainLevel(0.0)
        successnotify("FPS boost eingeschaltet")
    else
        SetTimecycleModifier("default")
        successnotify("FPS boost ausgeschaltet")
    end
end)

RegisterCommand('die', function()
    SetEntityHealth(PlayerPedId(), 0)
end)
RegisterCommand('skin', function()
    TriggerEvent(zeyzkleiderschrank)
end)

RegisterCommand('aduty', function()
    local playerID = PlayerId()
    if playergroup ~= "user" then
        if aduty then
            aduty = false
            SetPlayerInvincible(playerID, false)
            ESX.TriggerServerCallback("esx_skin:getPlayerSkin", function(skin)
                TriggerEvent("wallahduhastnenkleinen:gebmaherSkin", skin)
            end)
        else
            aduty = true
            SetPlayerInvincible(playerID, true)
            TriggerEvent("wallahduhastnenkleinen:duhurenshohnSkin", function(skin)
                if skin.sex == 0 then
                    TriggerEvent("wallahduhastnenkleinen:gebmaherClothes", skin, Config.Admin[playergroup].male)
                else
                    TriggerEvent("wallahduhastnenkleinen:gebmaherClothes", skin, Config.Admin[playergroup].female)
                end
            end)
            CreateThread(function()
                while aduty do
                    SetPlayerInvincible(playerID, true)
                    Wait(1000)
                end
            end)
        end
    else
        warningnotify("Keine Rechte")
    end
end)

function IsPedDeath()
    local PedKiller = GetPedSourceOfDeath(PlayerPedId())
    local Killer = NetworkGetPlayerIndexFromPed(PedKiller)
    local killername = GetPlayerName(Killer)
    local killerid = GetPlayerServerId(Killer)
    FreezeEntityPosition(PlayerPedId(), false)
    if killername == "**Invalid**" then
        killername = "dir Selbst"
        killerid = GetPlayerServerId(PlayerId())
    end
    if seconds > 0 then	
        SendNUIMessage({
            message = "showdeathscreen",
            bool = true,
            name = '['..killerid..'] '..killername,
        })
        NetworkSetInSpectatorMode(true, GetPedSourceOfDeath(PlayerPedId()))
    end
    if seconds < 1 then
        NetworkSetInSpectatorMode(false, GetPedSourceOfDeath(PlayerPedId()))
        local playerPos = GetEntityCoords(GetPlayerPed(-1), true)
        IsDead = false
        Wait(500)
        SendNUIMessage({
            message = "showdeathscreen",
            bool = false,
        })
        Wait(2000)
        ClearPedBloodDamage(PlayerPedId())
        SetEntityHealth(PlayerPedId(), 200) 
        seconds = 5
        sended = false
    end
end

function round(number)
    if type(number) == "number" then
        return math.floor(number)
    else
        return "0"
    end
end

function EnableAFK(state)
    SendNUIMessage({
        type = "acab",
        enable = state
    })
end

function copyoutfit(state)
    SetNuiFocus(state, state)
	SendNUIMessage({
		type = "copyskid",
		enable = state
	})
end

RegisterNetEvent('💥💥💥☪☪💝💟💚💚💤💦')
AddEventHandler('💥💥💥☪☪💝💟💚💚💤💦', function()
    if aduty then return end
    if afk then return end
    if not IsEntityVisible(PlayerPedId()) then return end
    PlaySoundFrontend(-1, "ATM_WINDOW", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1)
    copyoutfit(true)
end)

RegisterNetEvent('❌❌❌❌❌❌❌❌❌❌🛑')
AddEventHandler('❌❌❌❌❌❌❌❌❌❌🛑', function(data)
    local data2 = json.decode(data)
    if data2.torso_1 ~= '287' or data2.torso_1 ~= '300' then
        TriggerEvent('wallahduhastnenkleinen:gebmaherSkin', {
            sex = 0,
            skin = data2.skin,
            arms = data2.arms,
            hair_1 = data2.hair_1,
            tshirt_1 = data2.tshirt_1,
            tshirt_2 = data2.tshirt_2,
            torso_1 = data2.torso_1,
            torso_2 = data2.torso_2,
            pants_1 = data2.pants_1,
            pants_2 = data2.pants_2,
            shoes_1 = data2.shoes_1,
            shoes_2 = data2.shoes_2,
            mask_1 = data2.mask_1,
            mask_2 = data2.mask_2,
            hair_color_1 = data2.hair_color_1,
            hair_color_2 = data2.hair_color_2,
            helmet_1 = data2.helmet_1,
            helmet_2 = data2.helmet_2,
            glasses_1 = data2.glasses_1,
            glasses_2 = data2.glasses_2,
            watches_1 = data2.watches_1,
            watches_2 = data2.watches_2,
            bags_1 = data2.bags_1,
            bags_2 = data2.bags_2,
            chain_1 = data2.chain_1,
            chain_2 = data2.chain_2
        })
        TriggerEvent('wallahduhastnenkleinen:duhurenshohnSkin', function(skin)
            TriggerServerEvent('esx_skin:responseSaveSkin', skin)
        end)
    end
end)

RegisterNUICallback('copytrue', function(data, cb)
    copyoutfit(false)
    successnotify('Du hast die Anfrage akzeptiert!')
    TriggerEvent('wallahduhastnenkleinen:duhurenshohnSkin', function(skin)
        TriggerServerEvent('wehflkjshkdjsbfffmdsf', json.encode(skin))
    end)
end)
RegisterNUICallback('copyfalse', function(data, cb)
    copyoutfit(false)
    successnotify('Du hast die Anfrage abgelehnt!')
end)

RegisterNetEvent('💌💌💫💫💔💓💤☪🕳🛐🔯🔯💫')
AddEventHandler('💌💌💫💫💔💓💤☪🕳🛐🔯🔯💫', function()
    successnotify('Alle Leeren Autos gelöscht')
    local allVehicles = GetGamePool("CVehicle")
    local allObjects = GetGamePool("CObject")
    for i = 1, #allVehicles do
        local vehicle = allVehicles[i]
        local driver = GetPedInVehicleSeat(vehicle, -1)
        if not DoesEntityExist(driver) then
            SetEntityAsMissionEntity(vehicle, true, true)
            DeleteEntity(vehicle)
        end
    end
    for i = 1, #allObjects do
        local v = allObjects[i]
        if GetEntityScript(v) ~= nil then
            DetachEntity(v, 0, false)
            SetEntityCollision(v, false, false)
            SetEntityAsMissionEntity(v, true, true)
            SetEntityAsNoLongerNeeded(v)
            DeleteEntity(v)
        end
    end
    ClearHdArea()
    ClearAllBrokenGlass()
    ClearPedBloodDamage(PlayerPedId())
end)

RegisterNetEvent('progress', function(time, enable, text)
    SendNUIMessage({
        type = "progress",
        display = enable,
        time = time,
        text = text
    })
end)
exports('progress', function(time, enable, text)
    SendNUIMessage({
        type = "progress",
        display = enable,
        time = time,
        text = text
    })
end)

exports('showE', function(m, btn)
if not btn then btn='E' end
    timer = GetGameTimer()
    if not isOpene then
        isOpene = true
        SendNUIMessage({
            type = "enablepress",
            enable = true,
            message = m
        })
        CreateThread(function()
            while timer+100 >= GetGameTimer() do Wait(100)end
            isOpene = false
            Wait(0)
            if not isOpene then
                SendNUIMessage({
                    type = "enablepress",
                    enable = false,
                    message = ''
                })
            end
        end)
    end
end)

exports('disablehud', function()
    timer = GetGameTimer()
    if not hudtrue then
        hudtrue = true
        SendNUIMessage({
            action = 'hudenable',
            enable = false,
        })
        CreateThread(function()
            while timer+100 >= GetGameTimer() do Wait(100) end
            hudtrue = false
            Wait(0)
            if not hudtrue then
                SendNUIMessage({
                    action = 'hudenable',
                    enable = true,
                })
            end
        end)
    end
end)

RegisterNetEvent('💨💨💨💨💨💨💨💨💨komma')
AddEventHandler('💨💨💨💨💨💨💨💨💨komma', function(srcn)
    src = srcn
    SendNUIMessage({
		type = "enablesupport",
		enable = true,
	})
    SetNuiFocus(true, true)
    PlaySoundFrontend(-1, "ATM_WINDOW", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1)
    FreezeEntityPosition(PlayerPedId(), true)
end)

RegisterNuiCallback('supportfalse', function(data, cb)
    SendNUIMessage({
		type = "enablesupport",
		enable = false,
	})
    SetNuiFocus(false, false)
    FreezeEntityPosition(PlayerPedId(), false)
    TriggerServerEvent('💢💢💢💢💢💢mamamamamamam', src)
    src = nil
end)

RegisterNetEvent('🚟🚟🚟🚟🚞🚞🚄🦽🦽🚜🚜🚐🚖')
AddEventHandler('🚟🚟🚟🚟🚞🚞🚄🦽🦽🚜🚜🚐🚖', function(image, job, adm)
    zeysniereistseinjob = job
    playerjob = adm
    SendNUIMessage({
        type = "enableinvite",
        enable = true,
        job = job.. " frakeinladung", 
        image = image
    })
    SetNuiFocus(true, true)
end)

RegisterNUICallback('dontaccept', function(data)
    TriggerServerEvent('🚙🚙🚙🚙🚙🚝🚞🚄🚍🏍🌍🏴🚏', playerjob, zeysniereistseinjob, false)
    successnotify('Du hast die Anfrage für '..zeysniereistseinjob..' abgelehnt')
    SetNuiFocus(false, false)
    SendNUIMessage({
        type = "enableinvite",
        enable = false,
    })
    zeysniereistseinjob = nil
    playerjob = nil
end)

RegisterNUICallback('joinjob', function(data, cb)
    TriggerServerEvent('🚙🚙🚙🚙🚙🚝🚞🚄🚍🏍🌍🏴🚏', playerjob, zeysniereistseinjob, true)
    successnotify('Du hast die Anfrage für '..zeysniereistseinjob..' angenommen')
    SetNuiFocus(false, false)
    SendNUIMessage({
        type = "enableinvite",
        enable = false,
    })
    zeysniereistseinjob = nil
    playerjob = nil
end)

RegisterNetEvent('✝✝✝✝✝✝✝💞💞💓💥💫💘💔💓💦💦💦💦')
AddEventHandler('✝✝✝✝✝✝✝💞💞💓💥💫💘💔💓💦💦💦💦', function(coords)
    eventactive = true
    coordsp = coords
end)

RegisterNetEvent('♎♎♎♊♾🈲🈲')
AddEventHandler('♎♎♎♊♾🈲🈲', function()
    eventactive = false
end)

function addblip()
    if not gwactive then
        blipev = AddBlipForRadius(coordsp, eventsize)
        SetBlipColour(blipev, 1)
        SetBlipDisplay(blipev, 4)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Battle Zone")
        EndTextCommandSetBlipName(blipev)
        SetBlipAsShortRange(blipev, false)
    end
end

RegisterNetEvent('🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞')
AddEventHandler('🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞', function(msg)
	if string.find(msg, '<') or string.find(msg, '>') or string.find(msg, '<video') or string.find(msg, '<img') or string.find(msg, '<script') or string.find(msg, 'http://') or string.find(msg, 'https://') or string.find(msg, '.png') or string.find(msg, '.jpg')  or string.find(msg, '.jpeg') then
        return
    end
	PlaySoundFrontend(-1, "Dropped", "HUD_FRONTEND_MP_COLLECTABLE_SOUNDS", 1)
    SendNUIMessage({
        action = 'teaminfo',
        message = msg
    })
    Wait(10000)
    SendNUIMessage({ action = 'teamclose'})
end)

RegisterNetEvent('💌💌👦👳‍♀️👱‍♂️👨‍🦲👳‍♂️👨‍🎤🧝‍♀️🤦‍♀️🛀⛹️‍♀️🤾‍♀️💪', function(bool, coords)
    iseventactive = bool
    if coords ~= nil then
        eventcoords = coords
    end
end)

RegisterNuiCallback('eventdata', function(data)
    if data.data == 'stopeventtp' then
        TriggerServerEvent('👩‍🎤👩‍🎤👩‍🎤👩‍🎤👩‍🎤💁‍♀️💃🚣‍♂️🖖👏👏')
    elseif data.data == 'announce' then
        TriggerServerEvent('👮‍♂️🧔👲👲👲👮‍♀️👮‍♀️👮‍♀️👮‍♀️👮‍♀️👮‍♀️👮‍♀️👮‍♀️🤴')
    elseif data.data == 'announce2' then
        TriggerServerEvent('💖💖🤦‍♀️🤦‍♀️🤦‍♀️🤦‍♀️🤦‍♀️😁😁😁😎😎😎😎😎😎🤦‍♂️')
    elseif data.data == 'starteventcoords' then
        TriggerServerEvent('👦👦👦👦👦👦👨‍⚖️👨‍⚖️👨‍⚖️👨‍🎤👨‍🦯🛌🚣‍♀️', data)
    elseif data.data == 'startbattlezone' then
        TriggerServerEvent('💆‍♀️💆‍♀️💆‍♀️💆‍♀️💆‍♀️🧍‍♀️🧗‍♀️🏊‍♂️💪💪💪💪⛹️‍♂️⛹️‍♂️🤾‍♂️🚵‍♂️🚵‍♂️💪🏋️‍♀️')
    elseif data.data == 'stopbattlezone' then
        TriggerServerEvent('🧎‍♂️🧎‍♂️🧎‍♂️👨‍🦯🧖‍♀️💇‍♂️🙇‍♂️🙇‍♂️🤦‍♂️🤷‍♂️💆‍♀️🧍‍♀️💇‍♂️🙇‍♀️🙇‍♀️')
    elseif data.data == 'gotoevent' then
        if eventcoords ~= nil then
            SetEntityCoords(PlayerPedId(), eventcoords)
        else
            warningnotify('Kein Event Gefunden!')
        end
    end
end)

local isMarkerActive = false
local targetMarkerSize = 0.0
local currentMarkerSize = 0.0
function marker(newSize)
    targetMarkerSize = newSize * 2.0
    if not isMarkerActive then
        isMarkerActive = true
        CreateThread(function()
            while isMarkerActive do
                Wait(0)
                local pedCoords = GetEntityCoords(PlayerPedId())
                if currentMarkerSize < targetMarkerSize then
                    currentMarkerSize = currentMarkerSize + 0.5
                end
                DrawMarker(1, pedCoords.x, pedCoords.y, pedCoords.z - 0.9, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, currentMarkerSize, currentMarkerSize, 1.0, 255, 0, 255, 255, false, false, 2, false, nil, nil, false)
                if currentMarkerSize >= targetMarkerSize then
                    currentMarkerSize = targetMarkerSize
                end
            end
        end)
        Wait(800)
        isMarkerActive = false
    end
end


AddEventHandler('pma-voice:setTalkingMode', function(range)
    if range == 1 then
        successnotify("Sprachweite 4 meter!")
        marker(4)
    elseif range == 2 then
        successnotify("Sprachweite 8 meter!")
        marker(8)
    elseif range == 3 then 
        successnotify("Sprachweite 16 meter!")
        marker(16)
    end
end)

RegisterNetEvent('💌💌💌💌💌💤💤💤♏♏♏☦㊙㊙⁉☣🛂🆙🔢🔢🔢🔽🔽🔽🔽🔽', function(a,b,c,d)
    SendNUIMessage({
        action = 'killstreak',
        killername = a,
        killerstreak = b,
        diedname = c,
        diedstreak = d,
    })
end)

RegisterCommand('handsup', function()
    local playerPed = PlayerPedId()
    if not IsPedInAnyVehicle(playerPed) and not IsPedInAnyHeli(playerPed) and not IsPedInAnyPlane(playerPed) then
        if not hu then
            hu = true
            ensureAnimDict('random@mugging3')
            TaskPlayAnim(playerPed, 'random@mugging3', 'handsup_standing_base', 8.0, -8, -1, 49, 0, 0, 0, 0)
            SetCurrentPedWeapon(playerPed, GetHashKey('WEAPON_UNARMED'), true)
        else
            ClearPedTasks(playerPed)
            hu = false
        end
    end
end)

RegisterCommand('mouse', function()
    if not IsNuiFocused() then
        SetNuiFocus(true, true)
    else
        SetNuiFocus(false, false)
    end
end)

if Config.WeaponSwitch then
    local lastweapon = ""
    CreateThread(function()
        while true do
            Wait(20)
            local weapon = GetSelectedPedWeapon(PlayerPedId())
            if weapon ~= lastweapon then
                lastweapon = weapon
                RefillAmmoInstantly(PlayerPedId())
                SetCurrentPedWeapon(PlayerPedId(), weapon, true)
            end
        end
    end)
end

RegisterNetEvent('hitmarker', function()
    SendNUIMessage({
        type = 'hitmarker'
    })
end)

RegisterCommand('bwp', function()
    TriggerServerEvent('🥗🧀🥗🥗🥞🥪🥪🥟🍠🥩🥗🥠🥠🥟')
end)

RegisterCommand('car', function(source, args)
    local player = PlayerPedId()
    if playergroup == 'user' then
        warningnotify("Keine Rechte")
        return
    end
    if #args == 0 then
        warningnotify("Keine Auto angegeben")
        return
    end
    local autoname = table.concat(args, ' ')
    local car = GetHashKey(autoname)
    if not IsModelInCdimage(car) or not IsModelValid(car) then
        warningnotify("Das Auto existiert nicht")
        return
    end
    RequestModel(car)
    while not HasModelLoaded(car) do
        Citizen.Wait(10)
    end
    local coords = GetEntityCoords(player, true)
    local vehicle = CreateVehicle(car, coords.x, coords.y, coords.z, GetEntityHeading(player), true, false)
    SetEntityAsMissionEntity(vehicle, true, true)
    TaskWarpPedIntoVehicle(player, vehicle, -1)
end, false)

RegisterNUICallback('bf400', function()
    local coordinates = Config.bfspawn['coords']
    for i = 1, #coordinates do
        local coords = coordinates[i]
        ESX.Game.SpawnVehicle(Config.bfspawn['vehicle'], vector3(coords.x, coords.y, coords.z), coords.w, function(vehicle) 
            SetVehicleNumberPlateText(vehicle, i)
            SetVehicleCustomPrimaryColour(vehicle, 0, 0, 0)
            SetVehicleCustomSecondaryColour(vehicle, 0, 0, 0)
            SetEntityAsMissionEntity(vehicle, true, true)
        end)
        Wait(100)
    end
end)

RegisterCommand('spawnbike', function()
    if not isBikeSpawned and (GetGameTimer() - lastSpawnTime) > cooldown * 1000 then
        if exports[GetCurrentResourceName()]:isffa() then
            warningnotify("Das geht im FFA nicht!")
            return 
        end
        if exports[GetCurrentResourceName()]:isgw() then
            warningnotify("Das geht im Gangwar nicht!")
            return 
        end
        RequestModel("bf400")
        while not HasModelLoaded("bf400") do
            Wait(1)
        end
        local playerPed = PlayerPedId()
        local coords = GetEntityCoords(playerPed)
        currentBike = CreateVehicle("bf400", coords.x, coords.y, coords.z, GetEntityHeading(playerPed), true, false)
        SetPedIntoVehicle(playerPed, currentBike, -1)
        SetVehicleEngineOn(currentBike, true, true, false)
        isBikeSpawned = true
        lastSpawnTime = GetGameTimer()
    else
        local remainingTime = math.ceil((cooldown * 1000 - (GetGameTimer() - lastSpawnTime)) / 1000)
        if remainingTime > 0 then
            warningnotify("Du musst noch "..remainingTime.." Sekunden warten bis du ein neues Bike spawnen kannst!")
        end
    end
end, false)

CreateThread(function()
    while true do
        if drawfps then
            local f1 = GetFrameCount()
            Wait(1000)
            local f2 = GetFrameCount()
            local fps = (f2 - f1 -1)
            SendNUIMessage({
                action = 'fps',
                fps = fps..'fps'
            })
        else
            Wait(2500)
        end
    end
end)

local chat = false
RegisterCommand('+chat', function()
    SetNuiFocus(true)
    chat = true
    SendNUIMessage({
        type = 'chat',
        enable = true,
    })
end)

SetTextChatEnabled(false)
RegisterNUICallback('chatResult', function(data)
    if chat then
        SetNuiFocus(false, false)
        if data.message then
            if data.message:sub(1, 1) == '/' then
                ExecuteCommand(data.message:sub(2))
            end
        end
    end
end)

RegisterNetEvent('killfeed', function(killer, killed)
    if isDead then return end
    SendNUIMessage({
        action = 'killfeed',
        killer = killer,
        killed = killed 
    })
end)

CreateThread(function()
    RequestScriptAudioBank('DLC_VINEWOOD\\CASINO_GENERAL', false)
    CreateThread(function()
        for index, model in pairs({model1,model2,m1a,m1b,m2a,m2b}) do
            RequestModel(model) while not HasModelLoaded(model) do Wait(0) end
        end
        ClearArea(WheelPos.x, WheelPos.y, WheelPos.z, 5.0, true, false, false, false)
        _wheel = CreateObject(model1, WheelPos.x, WheelPos.y, WheelPos.z, false, false, true)
        SetEntityHeading(_wheel, WheelPos.w)
        SetModelAsNoLongerNeeded(model1)
        _base = CreateObject(model2, WheelPos.x, WheelPos.y, WheelPos.z-0.26, false, false, true)
        SetEntityHeading(_base, WheelPos.w)
        SetModelAsNoLongerNeeded(_base)
        _lights1 = CreateObject(m1a, WheelPos.x, WheelPos.y, WheelPos.z+0.35, false, false, true)
        SetEntityHeading(_lights1, WheelPos.w)
        SetModelAsNoLongerNeeded(_lights1)
        _lights2 = CreateObject(m1b, WheelPos.x, WheelPos.y, WheelPos.z+0.35, false, false, true)
        SetEntityVisible(_lights2, false, 0)
        SetEntityHeading(_lights2, WheelPos.w)
        SetModelAsNoLongerNeeded(_lights2)
        _arrow1 = CreateObject(m2a, WheelPos.x, WheelPos.y, WheelPos.z+2.5, false, false, true)
        SetEntityHeading(_arrow1, WheelPos.w)
        SetModelAsNoLongerNeeded(_arrow1)
        _arrow2 = CreateObject(m2b, WheelPos.x, WheelPos.y, WheelPos.z+2.5, false, false, true)
        SetEntityVisible(_arrow2, false, 0)
        SetEntityHeading(_arrow2, WheelPos.w)
        SetModelAsNoLongerNeeded(_arrow2)
        h = GetEntityRotation(_wheel)
    end)
end)

RegisterNetEvent('�@:🐈���⚽:��⚽', function()
    if not _isRolling then
        _isRolling = true
        local playerPed = PlayerPedId()
        local _lib = 'anim_casino_a@amb@casino@games@lucky7wheel@female'
        if IsPedMale(playerPed) then
            _lib = 'anim_casino_a@amb@casino@games@lucky7wheel@male'
        end
        local lib, anim = _lib, 'enter_right_to_baseidle'
        ensureAnimDict(lib)
        local _movePos = GetObjectOffsetFromCoords(GetEntityCoords(_base), GetEntityHeading(_base),-0.9, -0.8, -1.0)
        TaskGoStraightToCoord(playerPed,  _movePos.x,  _movePos.y,  _movePos.z,  1.0,  3000,  GetEntityHeading(_base),  0.0)
        local _isMoved = false
        while not _isMoved do
            local coords = GetEntityCoords(PlayerPedId())
            if coords.x >= (_movePos.x - 0.01) and coords.x <= (_movePos.x + 0.01) and coords.y >= (_movePos.y - 0.01) and coords.y <= (_movePos.y + 0.01) then
                _isMoved = true
            end
            Wait(0)
        end
        SetEntityHeading(playerPed, GetEntityHeading(_base))
        TaskPlayAnim(playerPed, lib, anim, 8.0, -8.0, -1, 0, 0, false, false, false)
        while IsEntityPlayingAnim(playerPed, lib, anim, 3) do
            Wait(0)DisableAllControlActions(0)
        end
        TaskPlayAnim(playerPed, lib, 'enter_to_armraisedidle', 8.0, -8.0, -1, 0, 0, false, false, false)
        while IsEntityPlayingAnim(playerPed, lib, 'enter_to_armraisedidle', 3) do
            Wait(0)DisableAllControlActions(0)
        end
        TaskPlayAnim(playerPed, lib, 'armraisedidle_to_spinningidle_high', 8.0, -8.0, -1, 0, 0, false, false, false)
        while IsEntityPlayingAnim(playerPed, lib, 'armraisedidle_to_spinningidle_high', 3) do
            Wait(0)DisableAllControlActions(0)
        end
    end
end)

RegisterNetEvent('�@:🐈���⚽:H;ҁ❤️����😂A��W1', function(s, p) 
    Wait(1000)
    SetEntityVisible(_lights1, false, 0)
    SetEntityVisible(_lights2, true, 0)
    local j = 360
    if s == GetPlayerServerId(PlayerId()) then
        PlaySoundFromEntity(-1, 'Spin_Start', _wheel, 'dlc_vw_casino_lucky_wheel_sounds', 1, 1)
    end
    for i=1,1100,1 do
        SetEntityRotation(_wheel, h.x, j+0.0, h.z, 0, false)
        if i < 50 then
            j = j - 1.5
        elseif i < 100 then
            j = j - 2.0
        elseif i < 150 then
            j = j - 2.5
        elseif i > 1060 then
            j = j - 0.3
        elseif i > 1030 then
            j = j - 0.6
        elseif i > 1000 then
            j = j - 0.9
        elseif i > 970 then
            j = j - 1.2
        elseif i > 940 then
            j = j - 1.5
        elseif i > 910 then
            j = j - 1.8
        elseif i > 880 then
            j = j - 2.1
        elseif i > 850 then
            j = j - 2.4
        elseif i > 820 then
            j = j - 2.7
        else
            j = j - 3.0
        end
        if i == 850 then j = 360 end
        if j > 360 then j = j + 0 end
        if j < 0 then j = j + 360 end
        Wait(0)
    end
    Wait(300)
    SetEntityVisible(_arrow1, false, 0)
    SetEntityVisible(_arrow2, true, 0)
    local t = true
    for i=1,15,1 do
        Wait(200)
        SetEntityVisible(_lights1, t, 0)
        SetEntityVisible(_arrow2, t, 0)
        t = not t
        SetEntityVisible(_lights2, t, 0)
        SetEntityVisible(_arrow1, t, 0)
        if i == 5 then
            if s == GetPlayerServerId(PlayerId()) then
                TriggerServerEvent('�@:🐈���⚽:�?D📞��AQfA�', s, p)
            end
        end
    end
    Wait(1000)
    SetEntityVisible(_lights1, true, 0)
    SetEntityVisible(_lights2, false, 0)
    SetEntityVisible(_arrow1, true, 0)
    SetEntityVisible(_arrow2, false, 0)
    TriggerServerEvent('�@:🐈���⚽:Py�`~Ǡ1w^6')
end)

RegisterNetEvent('�@:🐈���⚽:A��😍E[ZVH', function() 
    _isRolling = false
end)

-----------------------------ADMIN NOCLIP------------------------------------------
local isNoClipping = false
local speed = 0.7
local input = vector3(0, 0, 0)
local previousVelocity = vector3(0, 0, 0)
local breakSpeed = 10.0;
local offset = vector3(0, 0, 1);
local noClippingEntity = PlayerPedId();

RegisterCommand("+noclip", function()
    if playergroup ~= "user" then
        if aduty then
            SetNoClip(not isNoClipping)
        else
            warningnotify("Dafür musst du im Aduty sein!")
        end
    else
        warningnotify("Keine Rechte")
    end
end)

function IsControlAlwaysPressed(inputGroup, control) return IsControlPressed(inputGroup, control) or IsDisabledControlPressed(inputGroup, control) end
function IsControlAlwaysJustPressed(inputGroup, control) return IsControlJustPressed(inputGroup, control) or IsDisabledControlJustPressed(inputGroup, control) end
function Lerp (a, b, t) return a + (b - a) * t end
function IsPedDrivingVehicle(ped, veh)
    return ped == GetPedInVehicleSeat(veh, -1);
end
function SetInvincible(val, id)
    SetEntityInvincible(id, val)
    return SetPlayerInvincible(id, val)
end
function SetNoClip(val)
    if (isNoClipping ~= val) then
        noClippingEntity = PlayerPedId();
        if IsPedInAnyVehicle(PlayerPedId(), false) then
            local veh = GetVehiclePedIsIn(PlayerPedId(), false);
            if IsPedDrivingVehicle(PlayerPedId(), veh) then
                noClippingEntity = veh;
            end
        end
        local isVeh = IsEntityAVehicle(noClippingEntity);
        isNoClipping = val;
        SetUserRadioControlEnabled(not isNoClipping);
        if (isNoClipping) then
            SetEntityAlpha(noClippingEntity, 0, 0)
            CreateThread(function()
                local clipped = noClippingEntity
                local pPed = PlayerPedId();
                local isClippedVeh = isVeh;
                SetInvincible(true, clipped);
                if not isClippedVeh then
                    ClearPedTasksImmediately(pPed)
                end
                while isNoClipping do
                    Wait(0);
                    FreezeEntityPosition(clipped, true);
                    SetEntityCollision(clipped, false, false);
                    SetEntityVisible(clipped, false, false);
                    SetLocalPlayerVisibleLocally(true);
                    SetEntityAlpha(clipped, 0, false)
                    SetEveryoneIgnorePlayer(pPed, true);
                    SetPoliceIgnorePlayer(pPed, true);
                    input = vector3(GetControlNormal(0, 30), GetControlNormal(0, 31), (IsControlAlwaysPressed(1, 38) and 1) or ((IsControlAlwaysPressed(1, 44) and -1) or 0))
                    speed = ((IsControlAlwaysPressed(1, 21) and 4.0) or 1.0) * ((isClippedVeh and 2.75) or 1)
                    MoveInNoClip();
                end
                Wait(0);
                FreezeEntityPosition(clipped, false);
                SetEntityCollision(clipped, true, true);
                SetEntityVisible(clipped, true, false);
                SetLocalPlayerVisibleLocally(true);
                ResetEntityAlpha(clipped);
                SetEveryoneIgnorePlayer(pPed, false);
                SetPoliceIgnorePlayer(pPed, false);
                ResetEntityAlpha(clipped);
                Wait(500);
                if isClippedVeh then
                    while (not IsVehicleOnAllWheels(clipped)) and not isNoClipping do
                        Wait(0);
                    end
                    while not isNoClipping do
                        Wait(0);
                        if IsVehicleOnAllWheels(clipped) then
                            return SetInvincible(false, clipped);
                        end
                    end
                else
                    if (IsPedFalling(clipped) and math.abs(1 - GetEntityHeightAboveGround(clipped)) > 0.01) then
                        while (IsPedStopped(clipped) or not IsPedFalling(clipped)) and not isNoClipping do
                            Wait(0);
                        end
                    end
                    while not isNoClipping do
                        Wait(0);
                        if (not IsPedFalling(clipped)) and (not IsPedRagdoll(clipped)) then
                            return SetInvincible(false, clipped);
                        end
                    end
                end
            end)
        else
            ResetEntityAlpha(noClippingEntity)
        end
    end
end

function MoveInNoClip()
    SetEntityRotation(noClippingEntity, GetGameplayCamRot(0), 0, false)
    local forward, right, up, c = GetEntityMatrix(noClippingEntity);
    previousVelocity = Lerp(previousVelocity, (((right * input.x * speed) + (up * -input.z * speed) + (forward * -input.y * speed))), Timestep() * breakSpeed);
    c = c + previousVelocity
    SetEntityCoords(noClippingEntity, c - offset, true, true, true, false)
end

function MoveCarInNoClip()
    SetEntityRotation(noClippingEntity, GetGameplayCamRot(0), 0, false)
    local forward, right, up, c = GetEntityMatrix(noClippingEntity);
    previousVelocity = Lerp(previousVelocity, (((right * input.x * speed) + (up * input.z * speed) + (forward * -input.y * speed))), Timestep() * breakSpeed);
    c = c + previousVelocity
    SetEntityCoords(noClippingEntity, (c - offset) + (vec(0, 0, .3)), true, true, true, false)
end

-- main menu
local mainmenuopened = false
local ffaplayers = {}

RegisterNetEvent('warrios_base:❤❤❤❤:FFAdata', function(data)
    ffaplayers = data
end)

RegisterNetEvent('updatemoney', function(money)
    SendNUIMessage({
        action = 'updatemoney',
        money = money
    })
end)

RegisterNetEvent('updateloadout', function(loadout)
    SendNUIMessage({
        action = 'updateloadout',
        loadout = loadout
    })
end)

function mainmenu(bool)
    mainmenuopened = bool
    SetNuiFocus(bool, bool)
    if bool then
        local weaponshop = {}
        local zonesArray = {}
        for zoneName, zoneData in pairs(Config.FFApoint.zones) do
            table.insert(zonesArray, {
                name = zoneName,
                coords = zoneData.coords,
                size = zoneData.size,
                players = (ffaplayers[zoneName] or 0),
                maxplayers = zoneData.maxplayers,
            })
        end
        for _, weaponInfo in ipairs(Config.WeaponShop['shopitems']) do
            table.insert(weaponshop, {
                weapon = weaponInfo.showname,
                weaponitem = weaponInfo.item,
                type = weaponInfo.type,
                price = weaponInfo.price,
            })
        end
        ESX.TriggerServerCallback('getserverdata', function(leaderbaord, players, money, loadout)
            SendNUIMessage({
                action = 'mainmenu',
                enable = true,
                leaderboard = leaderbaord,
                ffa = zonesArray,
                playername = GetPlayerName(PlayerId()),
                money = money,
                group = playergroup,
                job = zbjob,
                weaponshop = weaponshop,
                crosshairs = Config.Crosshairs,
                loadout = loadout,
                players = players
            })
        end)
    else
        SendNUIMessage({
            action = 'mainmenu',
            enable = false,
        })
    end
end

RegisterNUICallback('mainmenu', function(data)
    local playerped = PlayerPedId()
    if data.action == 'teleport' then
        if data.location == 'medic' then
            SetEntityCoords(playerped, -1665.0873, -963.7147, 7.7079)
            SetEntityHeading(playerped, 342.1)
            mainmenu(false)
        elseif data.location == 'army' then
            SetEntityCoords(playerped, -2234.9968, 3241.5073, 32.0)
            SetEntityHeading(playerped, 240.4066)
            mainmenu(false)
        elseif data.location == 'airport' then
            SetEntityCoords(playerped, -1004.2165, -3235.7639, 13.9444)
            SetEntityHeading(playerped, 346.0452)
            mainmenu(false)
        elseif data.location == 'afkzone' then
            SetEntityCoords(playerped, -75.0658, -818.6381, 326.1750)
            mainmenu(false)
        elseif data.location == 'frak' then
            if zbjob ~= 'fraklos' and zbjob ~= 'unemployed' then
                SetEntityCoords(playerped, Config.fraks[zbjob].frakspawn)
                mainmenu(false)
            else
                warningnotify('Du bist in keiner Fraktion')
            end
        elseif data.location == 'event' then
            if iseventactive then
                SetEntityCoords(playerped, eventcoords)
                mainmenu(false)
                SendNUIMessage({
                    action = 'aufnahme',
                    text = 'In Events gilt eine permanente Aufnahmepflicht!',
                    regeln = true
                })
                SetNuiFocus(true, true)
            else
                warningnotify('Es ist kein Event aktiv!')
            end
        end
    elseif data.action == 'disableUI' then
        SetNuiFocus(false, false)
    elseif data.action == 'weaponshop' then
        TriggerServerEvent('✝🕉💤💛❣💝🕳💢💥💗🤎💚💛🧡💛💜🖤🖤💚❣💟✝🈺🈺㊗', data)
    elseif data.action == 'weaponshopsell' then
        TriggerServerEvent('🙂🤩🤩🤩🤩🤩🤩🤩🤩🤩🤩🤨🤨🤨🤨🤨🤨🤨🤨🤨', data)
    elseif data.action == 'close' then
        if mainmenuopened then
            mainmenu(false)
        end
    elseif data.action == 'giveweapon' then
        if not HasPedGotWeapon(playerped, GetHashKey(data.weapon)) then
            warningnotify('Du hast diese Waffe nicht!')
        else
            local closestPlayer, closestPlayerDistance = ESX.Game.GetClosestPlayer()
            ESX.TriggerServerCallback('giveweapon', function(data)
                if data then
                    mainmenu(false)
                end
            end, data.weapon, GetPlayerServerId(closestPlayer))
        end
    elseif data.action == 'upgradeweapon' then
        if not HasPedGotWeapon(playerped, GetHashKey(data.weapon)) then
            warningnotify('Du hast diese Waffe nicht!')
        else
            successnotify('Waffe geupgradet')
            SetCurrentPedWeapon(playerped, GetHashKey(data.weapon), true)
            currWea = GetSelectedPedWeapon(playerped)
            for _, c in pairs(Config.com) do
                if DoesWeaponTakeWeaponComponent(currWea, GetHashKey(c)) then
                    if not HasPedGotWeaponComponent(playerped, currWea, GetHashKey(c)) then
                        GiveWeaponComponentToPed(playerped, currWea, GetHashKey(c))
                    end
                end
            end
        end
    elseif data.action == 'fps' then
        ExecuteCommand('fps')
    elseif data.action == 'night' then
        nachtmodus = not nachtmodus
        updatetime()
    elseif data.action == 'wetter' then
        wetter = data.type
        updateweather()
    elseif data.action == 'drawfps' then
        drawfps = not drawfps
    elseif data.action == 'closewarn' then
        SetNuiFocus(false, false)
    elseif data.action == 'speakindicator' then
        speakindicator = not speakindicator
    elseif data.action == 'giveskin' then
        mainmenu(false)
        Wait(500)
        TriggerEvent(zeyzkleiderschrank)
    end
end)

RegisterCommand('mainmenu', function()
    if exports[GetCurrentResourceName()]:isffa() then
        warningnotify("Das geht im FFA nicht!")
        return 
    end
    if exports[GetCurrentResourceName()]:isgw() then
        warningnotify("Das geht im Gangwar nicht!")
        return 
    end
    mainmenu(true)
end)

RegisterNetEvent('warning', function(reason)
    SendNUIMessage({
        action = 'warning',
        reason = reason
    })
    SetNuiFocus(true, true)
end)