local isffa = false
local currentzone = ''
local currentcoords = nil

exports('isffa', function()
    return isffa
end)

CreateThread(function()
    while true do
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        local sleep = 2000
        if isffa then
            local isInZone = false
            for _, zoneData in pairs(Config.FFApoint["zones"]) do
                local distance = #(playerCoords - zoneData.coords)
                if distance < zoneData.renderdistance then
                    sleep = 0
                    DrawMarker(28, zoneData.coords, 0.0, 0.0, 0.0, 0, 0.0, 0.0, zoneData.size, zoneData.size, zoneData.height, 200, 0, 255, 120, false, false, 2, false, false, false, false)
                    if distance < zoneData.size then
                        isInZone = true
                    end
                end
            end
            if not isInZone then
                local zoneName = Config.FFApoint.zones[currentzone]
                local spawnPoints = zoneName.spawns
                local randomSpawn = spawnPoints[math.random(1, #zoneName.spawns)]
                SetEntityCoords(PlayerPedId(), randomSpawn.x, randomSpawn.y, randomSpawn.z)
                SetEntityHeading(PlayerPedId(), randomSpawn.w)
            end
        end
        Wait(sleep)
    end
end)

RegisterNUICallback('joinffa', function(data)
    if data.players >= data.maxplayers then
        TriggerEvent("notifications", "r", "FFA", "Dieses FFA ist voll")
    else
        mainmenu(false)
        currentcoords = GetEntityCoords(PlayerPedId())
        TriggerServerEvent('joinffa', data.id)
        currentzone = data.id
        RemoveAllPedWeapons(PlayerPedId())
        local weapons = Config.FFApoint.zones[data.id]['weapons']
        for i = 1, #weapons do
            GiveWeaponToPed(PlayerPedId(), GetHashKey(weapons[i]), 200, false, true)
        end
    end
end)

RegisterNetEvent('warrios_base:❤❤❤❤:setffa', function(bool)
    isffa = bool
end)

RegisterCommand('quitffa', function(args)
    if not isffa then
        TriggerEvent("notifications", "r", "FFA", "Du bist in keinem FFA")
    else
        TriggerServerEvent('quitffa', currentzone, currentcoords)
        RemoveAllPedWeapons(PlayerPedId())
        ESX.TriggerServerCallback('getinv', function(i)
            local lolli = {}
            lolli = {}
            for _, i2 in pairs(i) do
                table.insert(lolli, i2.name)
            end
            for i = 1, #lolli do
                GiveWeaponToPed(PlayerPedId(), GetHashKey(lolli[i]), 200, false, false)
            end
        end)
    end
end)

RegisterNetEvent('respawnffa', function()
    local zoneName = Config.FFApoint.zones[currentzone]
    local spawnPoints = zoneName.spawns
    local randomSpawn = spawnPoints[math.random(1, #zoneName.spawns)]
    SetEntityCoordsNoOffset(PlayerPedId(), randomSpawn.x, randomSpawn.y, randomSpawn.z)
    SetEntityHeading(PlayerPedId(), randomSpawn.w)
    RemoveAllPedWeapons(PlayerPedId())
    local weapons = Config.FFApoint.zones[currentzone]['weapons']
    for i = 1, #weapons do
        GiveWeaponToPed(PlayerPedId(), GetHashKey(weapons[i]), 200, false, false)
    end
end)