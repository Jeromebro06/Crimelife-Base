local gwjob = nil
local gwjoblabel = nil
local isgw = false
local otherjob = nil
local canstartgw = true
local canjoingw = false
local gwname = nil
local gwcars = false
local vehiclesin = {}
local time = 0
local isingwzones = false
local garagecoords = nil
local garagename = nil
local zone = nil
local frakgarageopen = false
local garageopen = false

exports('isgw', function()
    return isgw
end)

function FrakGarage(bool)
    frakgarageopen = bool
    SetNuiFocus(bool, bool)
    if bool == true then
        local vehiclelist = {}
        for spawnname, details in pairs(Config.fraks[gwjob].garage.cars) do
            table.insert(vehiclelist, {
                vehicle = spawnname,
                vehiclename = details.showname,
            })
        end
    end
    SendNUIMessage({
        action = 'frakgarage',
        enable = bool,
        vehicles = vehiclelist
    })
end

for _, data in pairs(Config.fraks) do
    local blip = AddBlipForCoord(data.frakspawn)
    SetBlipSprite(blip, data.blip.id)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, data.blip.sprite)
    SetBlipColour(blip, data.blip.colour)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(data.blip.title)
    EndTextCommandSetBlipName(blip)
end

RegisterNetEvent('🌹🌹🤣🤦‍♂️😘😘😘😂😁💕💕😘🤣🌹🌹🌹🌹', function(bool, job, name, frak)
    canjoingw = bool
    otherjob = job
    gwname = name
    if frak then
        if frak == 'frak1' then
            garagecoords = Config.GWpoint.zones[name].garagefrak1.coords
            garagename = frak
        else
            garagecoords = Config.GWpoint.zones[name].garagefrak2.coords
            garagename = frak
        end
    end
    time = (Config.GWpoint.gangwartime * 60)
end)

-- Function to update time
local function updateTime()
    while true do 
        Wait(1000)
        if time and time > 0 then
            local minutes = math.floor(time / 60)
            local seconds = time % 60
            SendNUIMessage({
                action = 'time',
                time = string.format("%02d:%02d", minutes, seconds)
            })
            time = time - 1
        end
    end
end

-- Function to handle player interactions with markers and zones
local function handleMarkersAndZones()
    while Config.GWpoint["enabled"] do
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        local sleep = 2000
        
        if not isgw and gwjob and gwjob ~= 'unemployed' and gwjob ~= 'fraklos' and gwjob ~= nil then
            -- Garage interaction
            local garageCoords = Config.fraks[gwjob].garage.coords
            local distanceToGarage = #(playerCoords - garageCoords)
            if distanceToGarage < 15.0 and not frakgarageopen then
                sleep = 0
                DrawMarker(36, garageCoords, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.5, 1.5, 1.5, 0, 0, 255, 170, false, false, 2, false, false, false, false)
                if distanceToGarage < 1.0 and not IsPauseMenuActive() then
                    exports[GetCurrentResourceName()]:showE('UM DIE GARAGE ZU ÖFFNEN')
                    if IsControlJustPressed(0, 38) then
                        FrakGarage(true)
                    end
                end
            end

            -- Zone interaction
            for a, d in pairs(Config.GWpoint.zones) do
                local distanceToZone = #(playerCoords - d.point)
                if distanceToZone < 15.0 then
                    sleep = 0
                    DrawMarker(Config.GWpoint["markertype"], d.point, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.0, 1.0, 1.0, Config.GWpoint.markercolor["r"], Config.GWpoint.markercolor["g"], Config.GWpoint.markercolor["b"], Config.GWpoint.markercolor["a"], false, true, 2, false, false, false, false)
                    if distanceToZone < 0.8 and not IsPauseMenuActive() then
                        local isffa = exports[GetCurrentResourceName()]:isffa() or false
                        if not isffa then 
                            exports[GetCurrentResourceName()]:showE('UM DIE ZONE '..d.name:upper()..' ANZUGREIFEN')
                            if IsControlJustPressed(0, 38) then
                                angreifenui(true, d.name)
                                zone = a
                            end
                        end
                    end
                end
            end
        end

        -- Gangwar zone interaction
        if isgw then
            local zoneCoords = Config.GWpoint.zones[gwname].zonecoords
            local distanceToZone = #(playerCoords - zoneCoords)
            if distanceToZone <= Config.GWpoint.zones[gwname].zonesize + 150.0 then
                sleep = 0
                DrawMarker(28, zoneCoords, 0.0, 0.0, 0.0, 0, 0.0, 0.0, Config.GWpoint.zones[gwname].zonesize, Config.GWpoint.zones[gwname].zonesize, Config.GWpoint.zones[gwname].zoneheight, 17, 185, 184, 170, false, false, 2, false, false, false, false)
                if distanceToZone <= Config.GWpoint.zones[gwname].zonesize then
                    isingwzones = true
                    NetworkSetFriendlyFireOption(true)
                    ResetEntityAlpha(playerPed)
                    SetLocalPlayerAsGhost(false)
                else
                    isingwzones = false
                    DisablePlayerFiring(playerPed, true)
                    NetworkSetFriendlyFireOption(false)
                    ClearPlayerWantedLevel(PlayerId())
                    SetLocalPlayerAsGhost(true)
                    SetGhostedEntityAlpha(600)
                    SetEntityAlpha(playerPed, 128, false)
                end
            end
        end

        -- Garage interaction in Gangwar
        if isgw and garagecoords then
            local distanceToGarage = #(playerCoords - garagecoords)
            if distanceToGarage <= 15.0 then
                sleep = 0
                if not garageopen then
                    DrawMarker(36, garagecoords, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.5, 1.5, 1.5, 0, 0, 255, 170, false, false, 2, false, false, false, false)
                end
                if distanceToGarage <= 1.5 then
                    if not garageopen then
                        exports[GetCurrentResourceName()]:showE('UM DIE GARAGE ZU ÖFFNEN')
                    end
                    if IsControlJustPressed(0, 38) then
                        gwgarage(true)
                    end
                end
            end
        end

        Wait(sleep)
    end
end

-- Function to update job information
local function updateJobInfo()
    while true do 
        local playerId = GetPlayerServerId(PlayerId())
        local playerState = Player(playerId) and Player(playerId).state or {}
        gwjob = playerState.job and playerState.job.name or nil
        gwjoblabel = playerState.job and playerState.job.label or nil
        Wait(1000 * 30)
    end
end

-- Create threads for the tasks
CreateThread(updateTime)
CreateThread(handleMarkersAndZones)
CreateThread(updateJobInfo)

RegisterNUICallback('frakgarage', function(data)
    FrakGarage(false)
    if gwjob ~='unemployed' and gwjob ~= 'fraklos' and Config.fraks[gwjob] then
        local spawncoord = Config.fraks[gwjob].garage.spawncood
        local heading = Config.fraks[gwjob].garage.spawnheading
        local callback_vehicle = CreateVehicle(data.name, spawncoord, heading, true, false)
        SetPedIntoVehicle(playerPed, callback_vehicle, -1)
        SetVehicleEngineOn(callback_vehicle, true, true, false)
        SetVehicleCustomPrimaryColour(callback_vehicle, Config.fraks[gwjob].frakcolor.r,  Config.fraks[gwjob].frakcolor.g,  Config.fraks[gwjob].frakcolor.b)
        SetVehicleCustomSecondaryColour(callback_vehicle, Config.fraks[gwjob].frakcolor.r,  Config.fraks[gwjob].frakcolor.g,  Config.fraks[gwjob].frakcolor.b)
        TaskWarpPedIntoVehicle(PlayerPedId(), callback_vehicle, -1)
        SetVehicleNumberPlateText(callback_vehicle, gwjob)
    end
end)

RegisterCommand('quitgw', function()
    if isgw then
        local ped =  PlayerPedId() 
        SetEntityCoords(ped, Config.fraks[gwjob].gwpoint)
        gwui(false)
        successnotify('Gangwar Verlassen!')
    else
        TriggerEvent('notifications', 'r', 'Information', 'Du bist in keinem Gangwar!')
    end
end)

function gwui(bool)
    isgw = bool
    TriggerServerEvent('💋💋💋💋💋💋💋💋💋💋💋💋💋💋💋💋💋💋💋', bool)
    SendNUIMessage({
        action = 'gwui',
        enable = bool,
        joblabel = gwjoblabel,
        joblogo = Config.fraks[gwjob].jobimage,
        geglabel = Config.fraks[otherjob].label,
        geglogo = Config.fraks[otherjob].jobimage
    })
end

local angui = false
function angreifenui(bool, name)
    angui = bool
    SetNuiFocus(bool, bool)
    SendNUIMessage({
        action = 'gwangreifen',
        enable = bool,
        name = (name or '')
    })
end

RegisterNuiCallback('zoneangreifen', function()
    angreifenui(false)
    TriggerServerEvent('💢💢💢💢💢✝✝✝🕉🕉💤💕', zone)
end)

RegisterNetEvent('👏👏👏👏🎂🎂🎂🎂🎂🎂🎂', function(bool)
    canstartgw = bool
end)

RegisterNetEvent('👀✔🐱‍🚀🐱‍🚀🐱‍🚀🐱‍🚀🐱‍🚀🐱‍🚀🐱‍🚀🐱‍🚀🐱‍🚀🐱‍👓🐱‍👓🐱‍👓🐱‍👓🐱‍👓😒😒', function()
    gwui(true)
    SetEntityCoords(PlayerPedId(), garagecoords)
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'aufnahme',
        text = 'Im Gangwar gilt eine permanente Aufnahmepflicht!',
        regeln = false
    })
end)

RegisterNetEvent('🐱‍💻🐱‍💻🐱‍💻🎶🎶🤦‍♂️🤣💕😂🎶😎🎉🙌😂😂', function()
    if isgw then
        local ped =  PlayerPedId() 
        SetEntityCoords(ped, Config.fraks[gwjob].gwpoint)
        gwui(false)
        successnotify('Gangwar Verlassen!')
    end
end)

function gwgarage(bool)
    if not gwcars then
        gwcars = true
        for vehicle, details in pairs(Config.GWpoint.cars) do
            table.insert(vehiclesin, {
                vehicle = vehicle,
                vehiclename = details.showname,
            })
        end
        SendNUIMessage({
            type = 'updateVehicles',
            vehiclesin = vehiclesin
        })
    end
    garageopen = bool
    SetNuiFocus(bool, bool)
    SendNUIMessage({
        action = 'gwgarage',
        enable = bool
    })
end

local spawncoord = nil
local heading = nil
RegisterNUICallback('gwgarage', function(data)
    gwgarage(false)
    if garagename == 'frak1' then
        spawncoord = Config.GWpoint.zones[gwname].garagefrak1.spawncood
        heading = Config.GWpoint.zones[gwname].garagefrak1.spawnheading
    else
        spawncoord = Config.GWpoint.zones[gwname].garagefrak2.spawncood
        heading = Config.GWpoint.zones[gwname].garagefrak2.spawnheading
    end
    ESX.Game.SpawnVehicle(data.name, {
        x = spawncoord.x,
        y = spawncoord.y,
        z = spawncoord.z
    }, heading, function(callback_vehicle)

        SetVehicleCustomPrimaryColour(callback_vehicle, Config.fraks[gwjob].frakcolor.r,  Config.fraks[gwjob].frakcolor.g,  Config.fraks[gwjob].frakcolor.b)
        SetVehicleCustomSecondaryColour(callback_vehicle, Config.fraks[gwjob].frakcolor.r,  Config.fraks[gwjob].frakcolor.g,  Config.fraks[gwjob].frakcolor.b)

        TaskWarpPedIntoVehicle(PlayerPedId(), callback_vehicle, -1)
        SetVehicleNumberPlateText(callback_vehicle, gwjob)
        SetVehicleColours(vehicle, colorPrimary, colorSecondary)
    end)
end)

RegisterNetEvent('✌✌😉🎶🎉😂💋😍🤞🤞🐱‍👤🐱‍👤😢👍👍👍👍👍', function()
    SetEntityCoordsNoOffset(PlayerPedId(), garagecoords, false, false, false)
    NetworkResurrectLocalPlayer(garagecoords, GetEntityHeading(PlayerPedId()), true, false)
end)

RegisterNetEvent('😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁🐱‍🚀', function(f1, f2)
    if garagename == 'frak1' then
        SendNUIMessage({
            action = 'uppoints',
            my = f1,
            ot = f2
        })
    else
        SendNUIMessage({
            action = 'uppoints',
            my = f2,
            ot = f1
        })
    end
end)

RegisterNetEvent('diedingw', function(killer)
    if isingwzones then
        if isgw then
            TriggerServerEvent('💢💢💢💢💢💢💢💢💢💢💢💌💌💌❣❣❣', killer, garagename)
        end
    end
end)

local blipTable = {}
function CreateBlip(coords, name, owner, blipcolor)
    local blip = AddBlipForCoord(coords)
    SetBlipSprite(blip, 437)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, 0.7)
    BeginTextCommandSetBlipName('STRING')
    SetBlipAsShortRange(blip, true)
    SetBlipColour(blip, blipcolor)
    AddTextComponentString(('Gangwar %s | %s'):format(name, owner:upper()))
    EndTextCommandSetBlipName(blip)
    table.insert(blipTable, blip)
end

RegisterNetEvent('updateblips', function(blips)
    for i=1, #blipTable do
        RemoveBlip(blipTable[i])
    end
    for _, v in ipairs(blips) do
        CreateBlip(Config.GWpoint.zones[v.name].point, Config.GWpoint.zones[v.name].name, v.owner, Config.fraks[v.owner].blip.colour)
    end
end)

ESX.TriggerServerCallback('getowners', function(owners)
    if owners then
        for _, v in ipairs(owners) do
            local zoneConfig = Config.GWpoint.zones[v.name]
            if zoneConfig then
                local ownerConfig = Config.fraks[v.owner]
                if ownerConfig and ownerConfig.blip and ownerConfig.blip.colour then
                    CreateBlip(zoneConfig.point, tostring(zoneConfig.name), tostring(v.owner), ownerConfig.blip.colour)
                else
                    print("^8[WARRIOS] ^1Fehler: Fehlende Blip-Konfiguration für Fraktion oder Farbe.")
                end
            else
                print("^8[WARRIOS] ^1Fehler: Fehlende Konfiguration für Zone.")
            end
        end
    else
        print("^8[WARRIOS] ^1Fehler: Keine Daten von Server erhalten.")
    end
end)

RegisterNuiCallback('closeweaponshop', function()
    if garageopen then
        gwgarage(false)
    end
    if angui then 
        angreifenui(false)
    end
end)