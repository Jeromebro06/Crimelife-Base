Config = {}

Config.MoneyPerKill = 20000
Config.Frakbonus = 2500
Config.WeaponSwitch = true
Config.TimeBetweenCarClears = 10

Config.DiscordPrescence = {
    appid = 1146902046230974504,
    logoname = "logo",
    servername = "Warrios Crimelife",
    discord = "https://discord.gg/warrioscl"
}

-- safezones
Config.Safezones = {
    [vector3(-1662.3506, -958.5938, 7.7203)] = 30.0,
    [vector3(-2254.0938, 3249.2612, 32.8102)] = 25.0,
    [vector3(-75.1837, -818.8724, 322.1749)] = 15.0 ,
    [vector3(-1004.2066, -3235.8062, 13.9444)] = 15.0
}

-- ffa 
Config.FFApoint = {
    zones = {
        ['Dach'] = {
            players = 0,
            maxplayers = 15,
            spawns = {
                vector4(-201.8423, -132.8664, 85.2247, 344.7795),
                vector4(-176.7781, -211.8094, 78.3396, 351.8340),
                vector4(-206.2139, -236.6597, 78.3395, 232.9458),
                vector4(-169.4917, -286.5458, 81.8304, 55.2123)
            },
            weapons = {
                'weapon_sniperrifle',
                'weapon_switchblade',
                'weapon_pistol',
            },
            coords = vector3(-194.3475, -250.0082, 78.3394),
            size = 80.0,
            height = 70.0,
            renderdistance = 150.0,
        },
        ['Golfplatz'] = {
            players = 0,
            maxplayers = 20,
            spawns = {
                vector4(-1080.8590, 11.6053, 50.6994, 243.2829),
                vector4(-1047.5962, -16.7567, 49.2228, 69.2284),
                vector4(-1152.9281, -53.2777, 44.5600, 253.2671),
                vector4(-1196.0176, -29.3645, 45.7818, 336.9003),
                vector4(-1188.0345, 128.7468, 61.4063, 235.4631)
            },
            weapons = {
                'weapon_appistol',
                'weapon_specialcarbine_mk2',
                'weapon_pistol',
                'weapon_switchblade'
            },
            coords = vector3(-1135.0786, 47.4933, 53.8852),
            size = 130.0,
            height = 120.0,
            renderdistance = 170.0,
        },
        ['Hafen'] = {
            players = 0,
            maxplayers = 15,
            spawns = {
                vector4(-50.5656, -2447.0544, 6.0025, 238.7672),
                vector4(8.0387, -2447.4639, 6.0068, 335.6341),
                vector4(-9.9946, -2496.4346, 6.0068, 143.8668),
                vector4(-102.2944, -2490.3535, 6.0269, 238.3676),
                vector4(-67.2591, -2415.0637, 8.8197, 253.8115)
            },
            weapons = {
                'weapon_pistol',
                'weapon_pistol50',
                'weapon_pistol_mk2',
                'weapon_switchblade',
                'weapon_advancedrifle'
            },
            coords = vector3(-48.6400, -2467.2488, 6.0111),
            size = 70.0,
            height = 60.0,
            renderdistance = 90.0,
        }
    }
}

-- gw config
Config.GWpoint = {
    enabled = true,
    markertype = 21,
    markercolor = {r=208, g=0, b=255, a=255},
    minonline = 0,
    gangwartime = 10, -- in min
    zones = {
        ['skaterpak'] = {
            point = vector3(-941.0281, -791.7308, 15.9510),
            name = "Skaterpark",
            zonecoords = vector3(-928.2346, -752.7422, 19.8178),
            zonesize = 100.0,
            zoneheight = 50.0,
            garagefrak1 = {
                coords = vector3(1140.9917, 2209.7546, 48.8265),
                spawncood = vector3(1140.0800, 2214.9192, 48.7272),
                spawnheading =  92.0447,
            },
            garagefrak2 = {
                coords = vector3(936.3266, 2489.6265, 50.7040),
                spawncood = vector3(936.7134, 2485.5476, 49.8614),
                spawnheading =  252.3536,
            }
        },
        ['baustelle'] = {
            point = vector3(997.7631, 2485.0962, 49.8252),
            name = "Baustelle",
            zonecoords = vector3(1056.0369, 2366.7454, 44.7074),
            zonesize = 120.0,
            zoneheight = 70.0,
            garagefrak1 = {
                coords = vector3(-842.9586, -930.0275, 15.6422),
                spawncood = vector3(-848.4426, -930.3030, 15.0765),
                spawnheading =  7.0214,
            },
            garagefrak2 = {
                coords = vector3(-885.7427, -603.6968, 29.0393),
                spawncood = vector3(-883.9647,-602.2818,28.9232),
                spawnheading =  205.3399,
            }
        },
        ['trailerpark'] = {
            point = vector3(1146.4646, -644.0898, 56.7505),
            name = "Trailerpark",
            zonecoords = vector3(1086.9451, -654.4636, 58.2619),
            zonesize = 150.0,
            zoneheight = 70.0,
            garagefrak1 = {
                coords = vector3(1139.8158, -872.6590, 53.8613),
                spawncood = vector3(1155.2950, -871.3376, 53.4858),
                spawnheading = 346.794,
            },
            garagefrak2 = {
                coords = vector3(860.8893, -563.2446, 57.3319),
                spawncood = vector3(866.6094, -561.8556, 56.7687),
                spawnheading =  208.3198,
            }
        },
        ['farm'] = {
            point = vector3(1353.6361, 1147.8744, 113.7590),
            name = "Farm",
            zonecoords = vector3(1436.4390, 1113.6295, 114.0782),
            zonesize = 150.0,
            zoneheight = 70.0,

            garagefrak1 = {
                coords = vector3(1302.6121, 1199.6956, 107.3487),
                spawncood = vector3(1299.1479, 1202.3716, 107.0837),
                spawnheading = 184.9591,
            },
            garagefrak2 = {
                coords = vector3(1431.4398, 926.2242, 102.1605),
                spawncood = vector3(1406.0714, 932.7069, 107.2516),
                spawnheading =  354.8986,
            }
        },
        ['golfplatz'] = {
            point = vector3(-1137.2529, -2.1664, 48.9822),
            name = "Golfplatz",
            zonecoords = vector3(-1137.2529, -2.1664, 48.9822),
            zonesize = 150.0,
            zoneheight = 70.0,

            garagefrak1 = {
                coords = vector3(-928.5978, -87.1076, 39.2796),
                spawncood = vector3(-928.5978, -87.1076, 39.2796),
                spawnheading = 99.0902,
            },
            garagefrak2 = {
                coords = vector3(-1334.8528, 31.2068, 53.5465),
                spawncood = vector3(-1334.8528, 31.2068, 53.5465),
                spawnheading =  285.2976,
            }
        },
    },
    cars = {
        ['vstr'] = {
            showname = 'VSTR',
        },
        ['schafter4'] = {
            showname = 'Schafter',
        },
        ['bf400'] = { 
            showname = 'BF400',
        },
        ['revolter'] = {
            showname = 'Revolter',
        },
        ['drafter'] = {
            showname = 'Drafter',
        },
        ['jugular'] = {
            showname = 'Jugular',
        }
    }
}

-- waffen shop shop
Config.WeaponShop = {
    shopitems = {
        {
            showname = 'Kampfaxt',
            item = 'weapon_battleaxe',
            type = 'WEAPON',
            price = 100000,
        },
        {
            showname = 'SMG',
            item = 'weapon_smg',
            type = 'WEAPON',
            price = 2400000,
        },
        {
            showname = 'Pistole',
            item = 'weapon_pistol',
            type = 'WEAPON',
            price = 800000,
        },
        {
            showname = 'AP Pistole',
            item = 'weapon_appistol',
            type = 'WEAPON',
            price = 1900000,
        },
        {
            showname = 'Pistole 50er',
            item = 'weapon_pistol50',
            type = 'WEAPON',
            price = 1200000,
        },
        {
            showname = 'Advancedgewehr',
            item = 'weapon_advancedrifle',
            type = 'WEAPON',
            price = 1100000,
        },
        {
            showname = 'PDW',
            item = 'weapon_combatpdw',
            type = 'WEAPON',
            price = 1800000,
        },
        {
            showname = 'Micro SMG',
            item = 'weapon_microsmg',
            type = 'WEAPON',
            price = 3000000,
        }
    }
}

-- blips
Config.blips = {
    {enabletitle = true, title="Pier-Zone", colour=18, id=150, sprite=0.7, coords = vector3(-1659.4415, -953.3511, 7.7196)},
    {enabletitle = true, title="Army-Zone", colour=18, id=150, sprite=0.7, coords = vector3(-2254.0938, 3249.2612, 32.8102)},
}

-- ambulancejob
Config.BleedOutTime = 4.5 * 1000
Config.RespawnPoints = {
	{coords = vector3(-1659.4415, -953.3511, 7.7196), heading = 240.9964},
	{coords = vector3(-2234.0115, 3238.6875, 32.8102), heading = 234.4778},
    {coords = vector3(-1004.2165, -3235.7639, 13.9444), heading = 346.0452}
}

--battle zones
Config.zoneLocations = {
    vector3(-692.7319, 5796.1650, 21.2167), -- haus/wald
    vector3(-272.4015, 6635.3154, 7.4030), -- hafen zone
    vector3(86.7139, 6541.6411, 31.6762), -- baustelle
    vector3(156.5970, 6607.5278, 31.8817), --
    vector3(368.6845, 6502.3682, 28.4199), --
    vector3(-29.0568, 6445.3672, 31.3742), --
}

Config.bfspawn = {
    vehicle = 'bf400',
    coords = {
        vector4(-189.2712, 6224.8154, 31.4893, 169.2630), --[01]
        vector4(-190.8185, 6225.0898, 31.4893, 179.3099), --[02]
        vector4(-192.2985, 6224.9307, 31.4893, 193.6348), --[03]
        vector4(-193.7145, 6224.5249, 31.4902, 196.5335), --[04]
        vector4(-195.2111, 6223.9790, 31.4924, 211.9882), --[05]
        vector4(-196.6487, 6223.3003, 31.4946, 206.6434), --[06]
        vector4(-197.6226, 6221.6094, 31.4942, 210.5529), --[07]
        vector4(-199.3961, 6221.0869, 31.4895, 248.0638), --[08]
        vector4(-200.2383, 6219.6338, 31.4899, 225.3521), --[09]
        vector4(-201.6990, 6218.8418, 31.4904, 226.9345), --[10]
        vector4(-202.9713, 6217.5703, 31.4902, 228.2050), --[11]
        vector4(-204.2189, 6216.2222, 31.4900, 225.2429), --[12]
        vector4(-205.5583, 6214.8135, 31.4897, 236.9726), --[13]
        vector4(-206.2944, 6213.0439, 31.4893, 249.9862), --[14]
        vector4(-205.8057, 6211.8887, 31.4894, 276.6626), --[15]
        vector4(-205.7392, 6210.1465, 31.4896, 286.9026), --[16]
        vector4(-205.3017, 6208.6226, 31.4898, 285.4501), --[17]
        vector4(-209.0303, 6208.2383, 31.4897, 288.2321), --[18]
        vector4(-209.7009, 6209.8901, 31.4895, 287.7455), --[19]
        vector4(-210.1810, 6211.7358, 31.4893, 278.2750), --[20]
    }
}

--fraksystem
Config.fraks = {
    ['police'] = {
        label = "LSPD",
        frakspawn = vector3(428.7329, -981.1516, 30.7102),
        jobimage = "https://content.invisioncic.com/w324406/monthly_2024_02/LSPD.png.fb1346221069e43f5cd0e5b508568c05.png",
        gwpoint = vector3(440.8824, -981.3873, 30.6896),
        frakcolor = {r = 0, g = 0, b = 255},
        blip = {
            title="Police Department",
            colour=38,
            id=543,
            sprite=0.8,
        },
        garage = {
            coords = vector3(412.7163, -980.8770, 29.4268),
            spawncood = vector3(407.5290, -980.0663, 28.8439),
            spawnheading =  48.5585,
            cars = {
                ['revolter'] = {
                    showname = 'Revolter',
                },
                ['drafter'] = {
                    showname = 'Drafter',
                },
                ['rs7c8sv'] = {
                    showname = 'RS7',
                }
            }
        }
    },
    ['vagos'] = {
        label = "Vagos",
        frakspawn = vector3(-1123.7102, -1608.5697, 4.3984), 
        jobimage = "https://image.jimcdn.com/app/cms/image/transf/dimension=421x1024:format=png/path/s604eeeb1f5e5128f/image/ie6ba460ff0aa7b3d/version/1555007139/image.png",
        gwpoint = vector3(-1129.1494, -1605.0325, 4.3984),
        frakcolor = {r = 255, g = 228, b = 0},
        blip = {
            title="Vagos Hood",
            colour=5,
            id=543,
            sprite=0.8,
        },
        garage = {
            coords = vector3(-1121.9990, -1600.3309, 4.3984),
            spawncood = vector3(-1135.4120, -1582.2524, 3.9078),
            spawnheading = 303.0147,
            cars = {
                ['revolter'] = {
                    showname = 'Revolter',
                },
                ['drafter'] = {
                    showname = 'Drafter',
                }
            }
        }
    },
    ['santamuerte'] = {
        label = "Santa muerte",
        frakspawn = vector3(-3024.0530, 81.0726, 11.6081), 
        jobimage = "https://images.fineartamerica.com/images/artworkimages/medium/2/santa-muerte-5-syvorov-ilia-transparent.png",
        gwpoint = vector3(-3026.2407, 89.5636, 12.3463),
        frakcolor = {r = 99, g = 123, b = 167},
        blip = {
            title="Santa muerte Hood",
            colour=53,
            id=543,
            sprite=0.8,
        },
        garage = {
            coords = vector3(-3026.4502, 95.0496, 11.6051),
            spawncood = vector3(-3018.8057, 99.3046, 11.6262),
            spawnheading = 314.2400,
            cars = {
                ['revolter'] = {
                    showname = 'Revolter',
                },
                ['drafter'] = {
                    showname = 'Drafter',
                }
            }
        }
    },
    ['galaxy'] = {
        label = "Galaxy",
        frakspawn = vector3(-1888.0248, 2050.0208, 140.9834), 
        jobimage = "https://cdn.discordapp.com/attachments/1223748678569824367/1225912512902598716/channels4_profile.jpg?ex=6622daff&is=661065ff&hm=6c4083e0e55b8ce54f138b85bef4ecb62bb7db5d3a38d64b092d2089f65984d2&",
        gwpoint = vector3(-1885.4772, 2048.1968, 140.9677),
        frakcolor = {r = 99, g = 123, b = 167},
        blip = {
            title="Galaxy Hood",
            colour=53,
            id=543,
            sprite=0.8,
        },
        garage = {
            coords = vector3(-1891.2595, 2042.1473, 140.9386),
            spawncood = vector3(-1880.9370, 2041.4866, 140.7313),
            spawnheading = 245.6103,
            cars = {
                ['revolter'] = {
                    showname = 'Revolter',
                },
                ['drafter'] = {
                    showname = 'Drafter',
                }
            }
        }
    }
}

Config.Crosshairs = {
    { --1
        default = true,
        img = "https://em-content.zobj.net/source/joypixels/275/white-circle_26aa.png",
        size = 100 -- %
    },
    { --2
        default = false,
        img = "https://cdn-icons-png.flaticon.com/128/2576/2576760.png",
        size = 100 -- %
    },
    { --3
        default = false,
        img = "https://www.clker.com/cliparts/q/8/Q/v/9/H/crosshair-hi.png",
        size = 100 -- %
    },
    { --4
        default = false,
        img = "https://tr.rbxcdn.com/aec293500d412d56e98ef5b29693a55c/420/420/Hat/Png",
        size = 100 --%
    },
    { --5
        default = false,
        img = "https://icons.veryicon.com/png/o/leisure/maps-and-travel/crosshair-5.png",
        size = 100 --%
    },
    { --6
        default = false,
        img = "https://cdn3d.iconscout.com/3d/premium/thumb/optical-sight-7235145-5867818.png?f=webp",
        size = 100 --%
    },
    { --7
        default = false,
        img = "https://clipart-library.com/img1/37380.png",
        size = 100 --%
    },
    { --8
        default = false,
        img = "https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Crosshairs_Red.svg/1024px-Crosshairs_Red.svg.png",
        size = 80 --%
    },
    { --9
        default = false,
        img = "crosshairs/crosshair_1.png",
        size = 100 --%
    },
    { --10
        default = false,
        img = "crosshairs/crosshair_2.png",
        size = 100 --%
    },
    { --11
        default = false,
        img = "crosshairs/crosshair_3.png",
        size = 100 --%
    }
}

Config.Admin = {
    pl = {
        male = {
            ['tshirt_1'] = 15,  ['tshirt_2'] = 0,
            ['torso_1'] = 287,   ['torso_2'] = 2,
            ['decals_1'] = 0,   ['decals_2'] = 0,
            ['arms'] = 3,
            ['pants_1'] = 114,   ['pants_2'] = 2,
            ['shoes_1'] = 78,   ['shoes_2'] = 2,
            ['helmet_1'] = -1,  ['helmet_2'] = 0,
            ['mask_1'] = 135,  ['mask_2'] = 2,
            ['chain_1'] = 0,    ['chain_2'] = 0,
            ['ears_1'] = 0,     ['ears_2'] = 0,
            ['bags_1'] = 0,     ['bags_2'] = 0,
            ['hair_1'] = 0,     ['hair_2'] = 0,
            ['bproof_1'] = 0,  ['bproof_2'] = 0
        },
        female = {
            ['tshirt_1'] = 15,  ['tshirt_2'] = 0,
            ['torso_1'] = 300,   ['torso_2'] = 2,
            ['decals_1'] = 0,   ['decals_2'] = 0,
            ['arms'] = 8,
            ['pants_1'] = 121,   ['pants_2'] = 2,
            ['shoes_1'] = 82,   ['shoes_2'] = 2,
            ['helmet_1'] = -1,  ['helmet_2'] = 0,
            ['mask_1'] = 135,  ['mask_2'] = 2,
            ['chain_1'] = 0,    ['chain_2'] = 0,
            ['ears_1'] = 0,     ['ears_2'] = 0,
            ['bags_1'] = 0,     ['bags_2'] = 0,
            ['hair_1'] = 0,     ['hair_2'] = 0,
            ['bproof_1'] = 0,  ['bproof_2'] = 0
        }
    },
    mod = {
        male = {
            ['tshirt_1'] = 15,  ['tshirt_2'] = 0,
            ['torso_1'] = 287,   ['torso_2'] = 6,
            ['decals_1'] = 0,   ['decals_2'] = 0,
            ['arms'] = 3,
            ['pants_1'] = 114,   ['pants_2'] = 6,
            ['shoes_1'] = 78,   ['shoes_2'] = 6,
            ['helmet_1'] = -1,  ['helmet_2'] = 0,
            ['mask_1'] = 135,  ['mask_2'] = 6,
            ['chain_1'] = 0,    ['chain_2'] = 0,
            ['ears_1'] = 0,     ['ears_2'] = 0,
            ['bags_1'] = 0,     ['bags_2'] = 0,
            ['hair_1'] = 0,     ['hair_2'] = 0,
            ['bproof_1'] = 0,  ['bproof_2'] = 0
        },
        female = {
            ['tshirt_1'] = 15,  ['tshirt_2'] = 0,
            ['torso_1'] = 300,   ['torso_2'] = 6,
            ['decals_1'] = 0,   ['decals_2'] = 0,
            ['arms'] = 8,
            ['pants_1'] = 121,   ['pants_2'] = 6,
            ['shoes_1'] = 82,   ['shoes_2'] = 6,
            ['helmet_1'] = -1,  ['helmet_2'] = 0,
            ['mask_1'] = 135,  ['mask_2'] = 6,
            ['chain_1'] = 0,    ['chain_2'] = 0,
            ['ears_1'] = 0,     ['ears_2'] = 0,
            ['bags_1'] = 0,     ['bags_2'] = 0,
            ['hair_1'] = 0,     ['hair_2'] = 0,
            ['bproof_1'] = 0,  ['bproof_2'] = 0
        }
    },
    admin = {
        male = {
            ['tshirt_1'] = 15,  ['tshirt_2'] = 0,
            ['torso_1'] = 287,   ['torso_2'] = 12,
            ['decals_1'] = 0,   ['decals_2'] = 0,
            ['arms'] = 3,
            ['pants_1'] = 114,   ['pants_2'] = 12,
            ['shoes_1'] = 78,   ['shoes_2'] = 12,
            ['helmet_1'] = -1,  ['helmet_2'] = 0,
            ['mask_1'] = 135,  ['mask_2'] = 12,
            ['chain_1'] = 0,    ['chain_2'] = 0,
            ['ears_1'] = 0,     ['ears_2'] = 0,
            ['bags_1'] = 0,     ['bags_2'] = 0,
            ['hair_1'] = 0,     ['hair_2'] = 0,
            ['bproof_1'] = 0,  ['bproof_2'] = 0
        },
        female = {
            ['tshirt_1'] = 15,  ['tshirt_2'] = 0,
            ['torso_1'] = 300,   ['torso_2'] = 12,
            ['decals_1'] = 0,   ['decals_2'] = 0,
            ['arms'] = 8,
            ['pants_1'] = 121,   ['pants_2'] = 12,
            ['shoes_1'] = 82,   ['shoes_2'] = 12,
            ['helmet_1'] = -1,  ['helmet_2'] = 0,
            ['mask_1'] = 135,  ['mask_2'] = 12,
            ['chain_1'] = 0,    ['chain_2'] = 0,
            ['ears_1'] = 0,     ['ears_2'] = 0,
            ['bags_1'] = 0,     ['bags_2'] = 0,
            ['hair_1'] = 0,     ['hair_2'] = 0,
            ['bproof_1'] = 0,  ['bproof_2'] = 0
        } 
    },
    mng = {
        male = {
            ['tshirt_1'] = 15,  ['tshirt_2'] = 0,
            ['torso_1'] = 287,   ['torso_2'] = 1,
            ['decals_1'] = 0,   ['decals_2'] = 0,
            ['arms'] = 3,
            ['pants_1'] = 114,   ['pants_2'] = 1,
            ['shoes_1'] = 78,   ['shoes_2'] = 1,
            ['helmet_1'] = -1,  ['helmet_2'] = 0,
            ['mask_1'] = 135,  ['mask_2'] = 1,
            ['chain_1'] = 0,    ['chain_2'] = 0,
            ['ears_1'] = 0,     ['ears_2'] = 0,
            ['bags_1'] = 0,     ['bags_2'] = 0,
            ['hair_1'] = 0,     ['hair_2'] = 0,
            ['bproof_1'] = 0,  ['bproof_2'] = 0
        },
        female = {
            ['tshirt_1'] = 15,  ['tshirt_2'] = 0,
            ['torso_1'] = 300,   ['torso_2'] = 1,
            ['decals_1'] = 0,   ['decals_2'] = 0,
            ['arms'] = 8,
            ['pants_1'] = 121,   ['pants_2'] = 1,
            ['shoes_1'] = 82,   ['shoes_2'] = 1,
            ['helmet_1'] = -1,  ['helmet_2'] = 0,
            ['mask_1'] = 135,  ['mask_2'] = 1,
            ['chain_1'] = 0,    ['chain_2'] = 0,
            ['ears_1'] = 0,     ['ears_2'] = 0,
            ['bags_1'] = 0,     ['bags_2'] = 0,
            ['hair_1'] = 0,     ['hair_2'] = 0,
            ['bproof_1'] = 0,  ['bproof_2'] = 0
        } 
    },
    sup = {
        male = {
            ['tshirt_1'] = 15,  ['tshirt_2'] = 0,
            ['torso_1'] = 287,   ['torso_2'] = 5,
            ['decals_1'] = 0,   ['decals_2'] = 0,
            ['arms'] = 3,
            ['pants_1'] = 114,   ['pants_2'] = 5,
            ['shoes_1'] = 78,   ['shoes_2'] = 5,
            ['helmet_1'] = -1,  ['helmet_2'] = 0,
            ['mask_1'] = 135,  ['mask_2'] = 5,
            ['chain_1'] = 0,    ['chain_2'] = 0,
            ['ears_1'] = 0,     ['ears_2'] = 0,
            ['bags_1'] = 0,     ['bags_2'] = 0,
            ['hair_1'] = 0,     ['hair_2'] = 0,
            ['bproof_1'] = 0,  ['bproof_2'] = 0
        },
        female = {
            ['tshirt_1'] = 15,  ['tshirt_2'] = 0,
            ['torso_1'] = 300,   ['torso_2'] = 5,
            ['decals_1'] = 0,   ['decals_2'] = 0,
            ['arms'] = 8,
            ['pants_1'] = 121,   ['pants_2'] = 5,
            ['shoes_1'] = 82,   ['shoes_2'] = 5,
            ['helmet_1'] = -1,  ['helmet_2'] = 0,
            ['mask_1'] = 135,  ['mask_2'] = 5,
            ['chain_1'] = 0,    ['chain_2'] = 0,
            ['ears_1'] = 0,     ['ears_2'] = 0,
            ['bags_1'] = 0,     ['bags_2'] = 0,
            ['hair_1'] = 0,     ['hair_2'] = 0,
            ['bproof_1'] = 0,  ['bproof_2'] = 0			
        }
    },
}

Config.com = {
	'COMPONENT_AT_PI_SUPP',
	'COMPONENT_AT_SR_SUPP',
	'COMPONENT_AT_AR_SUPP',
	'COMPONENT_AT_AR_SUPP_02',
	'COMPONENT_AT_PI_SUPP_02',
	'COMPONENT_AT_AR_AFGRIP',
	'COMPONENT_AT_AR_AFGRIP_02',
	'COMPONENT_AT_PI_FLSH', 
	'COMPONENT_AT_PI_FLSH_03',
	'COMPONENT_AT_PI_FLSH_02',
	'COMPONENT_AT_AR_FLSH',
	'COMPONENT_AT_SCOPE_MACRO_MK2',
	'COMPONENT_AT_PI_RAIL_02',
	'COMPONENT_AT_SCOPE_MACRO',
	'COMPONENT_AT_SCOPE_MACRO_02',
	'COMPONENT_AT_SCOPE_MACRO_02_MK2',
	'COMPONENT_AT_SCOPE_MACRO_02_SMG_MK2',
	'COMPONENT_AT_SCOPE_SMALL',
	'COMPONENT_AT_SCOPE_MEDIUM',
	'COMPONENT_SMG_CLIP_03',
	'COMPONENT_MACHINEPISTOL_CLIP_03',
	'COMPONENT_COMBATPDW_CLIP_03',
	'COMPONENT_HEAVYSHOTGUN_CLIP_03',
	'COMPONENT_ASSAULTRIFLE_CLIP_03',
	'COMPONENT_CARBINERIFLE_CLIP_03',
	'COMPONENT_SPECIALCARBINE_CLIP_03',
	'COMPONENT_COMPACTRIFLE_CLIP_03',
	'COMPONENT_PISTOL_CLIP_02',
	'COMPONENT_COMBATPISTOL_CLIP_02',
	'COMPONENT_APPISTOL_CLIP_02',
	'COMPONENT_PISTOL50_CLIP_02',
	'COMPONENT_SNSPISTOL_CLIP_02',
	'COMPONENT_HEAVYPISTOL_CLIP_02',
	'COMPONENT_SNSPISTOL_MK2_CLIP_02',
	'COMPONENT_PISTOL_MK2_CLIP_02',
	'COMPONENT_VINTAGEPISTOL_CLIP_02',
	'COMPONENT_MICROSMG_CLIP_02',
	'COMPONENT_ASSAULTSMG_CLIP_02',
	'COMPONENT_MINISMG_CLIP_02',
	'COMPONENT_SMG_MK2_CLIP_02',
	'COMPONENT_MACHINEPISTOL_CLIP_02',
	'COMPONENT_COMBATPDW_CLIP_02',
	'COMPONENT_ASSAULTSHOTGUN_CLIP_02',
	'COMPONENT_HEAVYSHOTGUN_CLIP_02',
	'COMPONENT_ASSAULTRIFLE_CLIP_02',
	'COMPONENT_CARBINERIFLE_CLIP_02',
	'COMPONENT_ADVANCEDRIFLE_CLIP_02',
	'COMPONENT_SPECIALCARBINE_CLIP_02',
	'COMPONENT_BULLPUPRIFLE_CLIP_02',
	'COMPONENT_BULLPUPRIFLE_MK2_CLIP_02',
	'COMPONENT_SPECIALCARBINE_MK2_CLIP_02',
	'COMPONENT_ASSAULTRIFLE_MK2_CLIP_02',
	'COMPONENT_CARBINERIFLE_MK2_CLIP_02',
	'COMPONENT_COMPACTRIFLE_CLIP_02',
	'COMPONENT_MILITARYRIFLE_CLIP_02',
	'COMPONENT_MG_CLIP_02',
	'COMPONENT_COMBATMG_CLIP_02',
	'COMPONENT_COMBATMG_MK2_CLIP_02',
	'COMPONENT_GUSENBERG_CLIP_02',
	'COMPONENT_MARKSMANRIFLE_MK2_CLIP_02',
	'COMPONENT_HEAVYSNIPER_MK2_CLIP_02',
	'COMPONENT_MARKSMANRIFLE_CLIP_02'
}

Config.Prices = {
    [1] = {type = 'money', name = 'money', count = math.random(100000, 1000000), sound = 'cash', probability = {min = 1, max = 1}}
}