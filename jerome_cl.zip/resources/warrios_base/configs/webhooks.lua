Webhooks = {
    URLS = {
        GiveItem = "https://discord.com/api/webhooks/1262717089983234128/yGVhkPPBxu2925Ki8oToNBnPFAEF7QoBFd54F77zO7avAMVHf9IIOC9gPnxNggjmV3wV",
        GiveWeapon = "https://discord.com/api/webhooks/1262717089983234128/yGVhkPPBxu2925Ki8oToNBnPFAEF7QoBFd54F77zO7avAMVHf9IIOC9gPnxNggjmV3wV",
        GiveGroup = "https://discord.com/api/webhooks/1262717089983234128/yGVhkPPBxu2925Ki8oToNBnPFAEF7QoBFd54F77zO7avAMVHf9IIOC9gPnxNggjmV3wV",
        GiveMoney = "https://discord.com/api/webhooks/1262717089983234128/yGVhkPPBxu2925Ki8oToNBnPFAEF7QoBFd54F77zO7avAMVHf9IIOC9gPnxNggjmV3wV",

        TeamChat = "https://discord.com/api/webhooks/1262717288482734090/a_4lIguxRTE_3AoOy8TAKH1qrTkWvyEUgroAANL_w3ve09ckgDjY63BlqyO4sPIJTJ9M",
        SetJob = "https://discord.com/api/webhooks/1262717288482734090/a_4lIguxRTE_3AoOy8TAKH1qrTkWvyEUgroAANL_w3ve09ckgDjY63BlqyO4sPIJTJ9M",
        SupCall = "https://discord.com/api/webhooks/1262717288482734090/a_4lIguxRTE_3AoOy8TAKH1qrTkWvyEUgroAANL_w3ve09ckgDjY63BlqyO4sPIJTJ9M",
        GwAdmin = "https://discord.com/api/webhooks/1262717288482734090/a_4lIguxRTE_3AoOy8TAKH1qrTkWvyEUgroAANL_w3ve09ckgDjY63BlqyO4sPIJTJ9M",

        GwAngriffe = "https://discord.com/api/webhooks/1216486408814858301/me4RLaBKpwnKI57W8TjLgWyqxOWcOnkV5GWsywSBgl5pWqkmmoUdgBK-71zM9KPc3VTw",
        GwErgebnis = "https://discord.com/api/webhooks/1216486408814858301/me4RLaBKpwnKI57W8TjLgWyqxOWcOnkV5GWsywSBgl5pWqkmmoUdgBK-71zM9KPc3VTw",
        Killstreak = "https://discord.com/api/webhooks/1262718140471578654/Pbs2313M-akfssZvl711iP9Et9HhIgnMAkLTfJgNp7ddamxUeLI5VWS7p1hz-hUWuGoV",

        Identity = "https://discord.com/api/webhooks/1262717288482734090/a_4lIguxRTE_3AoOy8TAKH1qrTkWvyEUgroAANL_w3ve09ckgDjY63BlqyO4sPIJTJ9M",
        TeamInfo = "https://discord.com/api/webhooks/1262717288482734090/a_4lIguxRTE_3AoOy8TAKH1qrTkWvyEUgroAANL_w3ve09ckgDjY63BlqyO4sPIJTJ9M",
        WaffenShop = "https://discord.com/api/webhooks/1262717288482734090/a_4lIguxRTE_3AoOy8TAKH1qrTkWvyEUgroAANL_w3ve09ckgDjY63BlqyO4sPIJTJ9M",
        Event = "https://discord.com/api/webhooks/1262717288482734090/a_4lIguxRTE_3AoOy8TAKH1qrTkWvyEUgroAANL_w3ve09ckgDjY63BlqyO4sPIJTJ9M",

        TopAfk = "https://discord.com/api/webhooks/1262717892496064512/ihcIKlGaqFTGL3Jy8lhLjYXAxIP6BdaFFALRExAlyFGqcQ2m3FQL4JwVwRHkvoGY0Cja",
        TopKills = "https://discord.com/api/webhooks/1180904940386910338/mWfbV2NKlrzWuLjj8GYaMvBhQ0sulJIkENp4BmyWpaJvVrqEW4YZZ3N4JrLJkIOYakxm",
        GwBesitzer = "https://discord.com/api/webhooks/1250456383057297611/Zz9bLZb9F_VKT4H6yOApN5R38NM-DzIMLqpXkSBXbOMg3CIOdsy9bNokmj31ySXKvTTv",
    },
    UserProfile = {
        Name = "Warrios Crimelife",
        Image = "https://cdn.discordapp.com/attachments/1198657212466352138/1222528761258446870/W-bg.webp?ex=66168ba2&is=660416a2&hm=939e16070ca24b6a3c26a74e7b8df4db14ad734df1ec408a39a6d7432aeba563&"
    },
    Footer = "©-2024-Warrios Crimelife | "..os.date("%H:%M:%S %Y"),
}