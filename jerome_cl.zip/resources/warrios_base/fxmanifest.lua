fx_version 'cerulean'

game 'gta5'
description '© by Jeromebro'
loadscreen 'html/loading.html'
loadscreen_cursor 'yes'
loadscreen_manual_shutdown 'yes'
shared_scripts {
    '@warrios_core/imports.lua',
    'configs/config.lua',
}

server_scripts {
    'configs/webhooks.lua',
    '@warrios_core/lib/MySQL.lua',
    'server/*.*',
    'index.js'
}

client_scripts{
    'client/*.*',
    'locale.lua',
    'locales/de.lua',
    "lib/common.lua",
    "lib/observers/*.*",
    "bob74ipl/*.*",
    "bob74ipl/dlc/*.*",
}

ui_page "html/index.html"

files {
    'html/index.html',
    'html/img/*.*',
    'html/weapons/*.*',
    'html/font/*.*',
    'html/css/*.*',
    'html/js/*.*',
    'html/*.*',
    'html/crosshairs/*.*',
    'html/sounds/*.*',
    'weapondamage/*.meta'
}

data_file 'WEAPONINFO_FILE_PATCH'   'weapondamage/*.meta'
dependencies {
	'warrios_core',
    '/assetpacks',
    '/onesync'
}
shared_script "anvil.lua"