let hud = true;
let hitmarker = false;
let fps = false;
let chat = false;
let killfeed = true;
$(".progressbar").hide();
$(".fps").hide();

function formatNum(zahl) {
    let num = parseInt(zahl) || 0;
    return num.toLocaleString("de-DE");
}

window.addEventListener('message', function(event){
    if (event.data.type == "acab") {
        var afk = document.querySelector(".afk");
        afk.style.display = event.data.enable ? "flex" : "none";
    } else if (event.data.type == "copyskid") {
        var copyyy = document.querySelector(".copyoutfit");
        copyyy.style.display = event.data.enable ? "flex" : "none";
    } else if (event.data.type == "enableui") {
        var wrapper = document.querySelector(".identity");
        wrapper.style.display = event.data.enable ? "block" : "none";
    } else if (event.data.type == "enablesupport") {
        var wrapper2 = document.querySelector(".supportcall");
        wrapper2.style.display = event.data.enable ? "flex" : "none";
    } else if (event.data.type == "enablepress") {
        var component = document.querySelector(".presse");
        component.style.display = event.data.enable ? "block" : "none";
        $('.presst').html(event.data.message);
    } else if (event.data.type == "enableinvite") {
        var component2 = document.querySelector(".invite");
        component2.style.display = event.data.enable ? "block" : "none";
        var demoElement = document.querySelector(".frakinnername");
        demoElement.innerHTML = event.data.job;
        var bildElement = document.querySelector(".frakinnerimg");
        bildElement.src = event.data.image;
    } else if (event.data.type == "enableeventud") {
        var component3 = document.querySelector(".eventhud");
        component3.style.display = event.data.enable ? "flex" : "none";
        $('.timetode').text(event.data.time);
    } else if (event.data.message == 'showdeathscreen') {
        var ds = document.querySelector('.deathscreen');
        ds.style.display = event.data.bool ? "flex" : "none";
        $('.middletext p').text(event.data.name)
    } else if (event.data.action === 'teaminfo') {
        $('#teammessage').text(event.data.message);
        $("#teaminfo").fadeIn()
        document.querySelector("#teaminfo").style.display = "flex";
    } else if (event.data.action === 'teamclose') {
        $("#teaminfo").fadeOut()
    } else if (event.data.action === 'carhud') {
        if (event.data.enable === true) {
            $('.carhud').fadeIn();
            $('.kmhzahl h1').text(event.data.speed);
            updateCarSpeed(event.data.eng);
        }
        if (event.data.enable === false) {
            $('.carhud').fadeOut();
        }
    } else if (event.data.action === 'health') {
        updateh(event.data.health, event.data.armor)
    } else if (event.data.action === 'hud') {
        $('.moneyinsert').text(formatNum(event.data.money));
        $('.idinsert').text(event.data.id);
        $('.kdinsert').text(event.data.kd);
        $('.killsinsert').text(event.data.kill);
        $('.deathinsert').text(event.data.tod);
        $('.level').text(event.data.lvl);
        if (event.data.lvl) {
            $('.playerlevel').text('LVL '+ event.data.lvl);
        }
    } else if (event.data.action === 'hudenable') {
        if (hud === true) {
            if (event.data.enable == false) {
                $('.hud').fadeOut(500);
            } else {
                $('.hud').fadeIn(500);
            }
        }
    } else if (event.data.action === 'killstreak') {
        $('.killn').text(event.data.killername)
        $('.killst').text(event.data.killerstreak)
        $('.diedn').text(event.data.diedname)
        $('.diedst').text(event.data.diedstreak)
        $('.killstreakouter').fadeIn()
        setTimeout(() => {
            $('.killstreakouter').fadeOut()
        }, 4000);
    } else if (event.data.action === 'gwui') {
        if (event.data.enable === true) {
            $('.frakinner1 h3').text(event.data.joblabel);
            $('.frakinner2 h3').text(event.data.geglabel);
            $('.gwhud').fadeIn(400);
        } else {
            $('.gwhud').fadeOut(400);
        }
    } else if (event.data.action === 'gwgarage') {
        if (event.data.enable === true) {
            $('.gwgarage').fadeIn(400);
        } else {
            $('.gwgarage').fadeOut(400);
        }
    } else if (event.data.type === 'updateVehicles') {
        const vehiclesin = event.data.vehiclesin;
        if (vehiclesin !== undefined && vehiclesin.length > 0) {
            vehiclesin.forEach((v) => {
                const content = $(`
                    <div class="autoitem ${v.vehicle}">
                        <h3>${v.vehiclename}</h3>
                        <img src="img/${v.vehicle}.png">
                    </div>
                `);
                $(".gangwarbody").append(content);
                $(`.${v.vehicle}`).click(function() {
                    $.post(`https://${GetParentResourceName()}/gwgarage`, JSON.stringify({name: v.vehicle}));
                });
            });
        }
    } else if (event.data.action === 'time') {
        $('.gwtime').text(event.data.time)
    } else if (event.data.action === 'fps') {
        $('.fps p').text(event.data.fps)
    } else if (event.data.type === 'chat') {
        $('.chat').fadeIn(200);
        chat = true;
        $('.chat input').focus();
    } else if (event.data.action === 'uppoints') {
        console.log(event.data.my, event.data.ot);
        $('.f1p').text(event.data.my)
        $('.f2p').text(event.data.ot)
    } else if (event.data.action === 'frakgarage') {
        const vehiclesin2 = event.data.vehicles;
        $(".frakbody").empty();
        if (vehiclesin2 !== undefined && vehiclesin2.length > 0) {
            vehiclesin2.forEach((v) => {
                const content = $(`
                    <div class="autoitem ${v.vehicle}">
                        <h3>${v.vehiclename}</h3>
                        <img src="img/${v.vehicle}.png">
                    </div>
                `);
                $(".frakbody").append(content);
                $(`.${v.vehicle}`).click(function() {
                    $.post(`https://${GetParentResourceName()}/frakgarage`, JSON.stringify({name: v.vehicle}));
                });
            });
        }
        if (event.data.enable === true) {
            $('.frakgarage').fadeIn(400);
        } else {
            $('.frakgarage').fadeOut(400);
        }
    } else if (event.data.type === 'hitmarker') {
        if (hitmarker === true) {
            var selectElement2 = document.querySelector(".soundchoose");
            var selectedValue2 = selectElement2.value;
            var audio = new Audio(selectedValue2);
            var volumeControl = document.querySelector(".lautstaerke");
            audio.volume = volumeControl.value;
            audio.play();
        }      
    } else if (event.data.action === 'gwangreifen') {
        if (event.data.enable === true) {
            $('.angreifen h3').text(event.data.name);
            $('.angreifen').fadeIn(200);
        } else {
            $('.angreifen').fadeOut(200);
        }
    } else if (event.data.action === 'killfeed') {
        if (killfeed === true) {
            const content = $(`
                <div class="killitem">
                    <p class="killname1">${event.data.killer}</p>
                    <i class="fa-solid fa-gun"></i>
                    <p class="killname2">${event.data.killed}</p>
                </div>
            `);                
            $(".killfeed").prepend(content);
            content.fadeIn(300);
            setTimeout(() => {
                content.fadeOut(500, () => content.remove());
            }, 4000);
        }
    }
});

$('.giveskin').click(function (e) {
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action:'giveskin'}));
});

function updateh(h, a) {
    $(".line1").css("width", h + "%");
    $(".line2").css("width", a + "%");
};

$(".closesup").click(function() {
    $.post(`https://${GetParentResourceName()}/supportfalse`, JSON.stringify({}));
});
$('.gwabbrechen').click(function (e) { 
    $.post(`https://${GetParentResourceName()}/closeweaponshop`, JSON.stringify({}));
});
$('.gwangreifen').click(function (e) { 
    $.post(`https://${GetParentResourceName()}/zoneangreifen`, JSON.stringify({}));
});
$(".ja").click(function() {
    $.post(`https://${GetParentResourceName()}/copytrue`, JSON.stringify({}));
});
$(".nein").click(function() {
    $.post(`https://${GetParentResourceName()}/copyfalse`, JSON.stringify({}));
});
$(".eventbf").click(function() {
    $.post(`https://${GetParentResourceName()}/closeweaponshop`, JSON.stringify({}));
    $.post(`https://${GetParentResourceName()}/bf400`, JSON.stringify({}));
});
$('.close').click(function() {
    $.post(`https://${GetParentResourceName()}/closeweaponshop`, JSON.stringify({}));
});
$('.close2').click(function() {
    $.post(`https://${GetParentResourceName()}/closeweaponshop`, JSON.stringify({}));
});
$('.close3').click(function() {
    $.post(`https://${GetParentResourceName()}/closeweaponshop`, JSON.stringify({}));
});
$('.closegarage').click(function() {
    $.post(`https://${GetParentResourceName()}/closeweaponshop`, JSON.stringify({}));
});
$('.closefrak').click(function() {
    $.post(`https://${GetParentResourceName()}/closeweaponshop`, JSON.stringify({}));
});
$(".ann").click(function() {
    $.post(`https://${GetParentResourceName()}/joinjob`, JSON.stringify({}));
});
$(".abl").click(function() {
    $.post(`https://${GetParentResourceName()}/dontaccept`, JSON.stringify({}));
});

$(".stoptp").click(function() {
    $.post(`https://${GetParentResourceName()}/eventdata`, JSON.stringify({data: 'stopeventtp'}));
});
$(".ann321").click(function() {
    $.post(`https://${GetParentResourceName()}/eventdata`, JSON.stringify({data: 'announce'}));
});
$(".annrem").click(function() {
    $.post(`https://${GetParentResourceName()}/eventdata`, JSON.stringify({data: 'announce2'}));
});
$(".startevent").click(function() {
    var selectElement = document.querySelector(".eventchoose");
    var selectedValue = selectElement.value;
    $.post(`https://${GetParentResourceName()}/eventdata`, JSON.stringify({data: 'starteventcoords', name: selectedValue}));
});
$(".startbzone").click(function() {
    $.post(`https://${GetParentResourceName()}/eventdata`, JSON.stringify({data: 'startbattlezone'}));
});
$(".stopbzone").click(function() {
    $.post(`https://${GetParentResourceName()}/eventdata`, JSON.stringify({data: 'stopbattlezone'}));
});
$(".gotoevent").click(function() {
    $.post(`https://${GetParentResourceName()}/eventdata`, JSON.stringify({data: 'gotoevent'}));
});

$(".hudmode").change(function() {
    if (hud === true) {
        hud = false
        $('.hud').fadeOut()
    } else {
        hud = true
        $('.hud').fadeIn()
    }
});
$(".killfeedmode").change(function() {
    if (killfeed === true) {
        killfeed = false
    } else {
        killfeed = true
    }
});
$(".hitmarker").change(function() {
    if (hitmarker === true) {
        hitmarker = false
    } else {
        hitmarker = true
    }
});
$('.speakindicator').change(function () { 
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'speakindicator'}));
});

document.addEventListener("keydown", function(event) {
    if (event.key === "Escape") {
        $.post(`https://${GetParentResourceName()}/chatResult`, JSON.stringify({}));
        $('.chat').fadeOut(300);
        $('.chat input').val('');
        chat = false;
    } else if (event.key === "Enter") {
        if (chat === true) {
            chat = false;
            $('.chat').fadeOut(300);
            var value = $('.chat input').val();
            $.post(`https://${GetParentResourceName()}/chatResult`, JSON.stringify({message: value}));
            $('.chat input').val('');
        }
    }
});

$(function(){
    var animationTimeout;
    window.onload = () => { 
        window.addEventListener('message', (event) => {	            
            var item = event.data;
            if (item !== undefined && item.type === "progress") {	
                $('.progressbar h3').text(event.data.text);	                
                if (item.display === true) {
                    $(".progressbar").show();
                    var start = new Date();
                    var maxTime = item.time;
                    var timeoutVal = Math.floor(maxTime/100);
                    animateUpdate();
                    function updateProgress(percentage) {
                        colorizeBar(percentage);
                    }
                    function animateUpdate() {
                        var now = new Date();
                        var timeDiff = now.getTime() - start.getTime();
                        var perc = Math.round((timeDiff/maxTime)*100);
                        if (perc <= 100) {
                            updateProgress(perc);
                            animationTimeout = setTimeout(animateUpdate, timeoutVal);
                        } else {
                            clearTimeout(animationTimeout);
                            $(".progressbar").hide();
                        }
                    }
                } else {
                    clearTimeout(animationTimeout);
                    $(".progressbar").hide();
                }
            }
        });
    };
});

function colorizeBar(percentage) {
    const loadingBar = document.querySelector('.progress');
    const loadElements = loadingBar.querySelectorAll('.pgitm');
    const numberOfColoredElements = Math.round(loadElements.length * (percentage / 100));
    loadElements.forEach((load, index) => {
      load.style.backgroundColor = index < numberOfColoredElements ? 'rgb(111, 0, 255)' : 'rgba(255, 255, 255, 0.21)';
  });
};
function updateCarSpeed(speedPercentage) {
    var blueItemCount = Math.ceil((speedPercentage / 100) * 15);
    $(".carspeed div").removeClass("red");
    $(".carspeed div:lt(" + blueItemCount + ")").addClass("red");
}
function openTab(tabId) {
    var tabContents = document.getElementsByClassName("tab-box");
    for (var i = 0; i < tabContents.length; i++) {
      tabContents[i].style.display = "none";
    }
    $('#'+tabId).css('display', 'flex'); 
};

$(".addfriend").click(function() {
    var selectElement3 = document.querySelector(".addinput");
    var selectedValue3 = selectElement3.value;
    $.post(`https://${GetParentResourceName()}/addfriend`, JSON.stringify({data: selectedValue3}));
});

function openTab2(tabId) {
    var tabContents = document.getElementsByClassName("frakbox");
    for (var i = 0; i < tabContents.length; i++) {
        tabContents[i].style.display = "none";
    }
    document.getElementById(tabId).style.display = "flex";
};