var regeln = false;
function mainmenusidebar(side) {
    $('.mainmenuside').hide();
    $('.mainmenuside'+side).show();
    $('.sidebaritem').removeClass('sidebaractive');
    $('.sidebarbutton'+side).addClass('sidebaractive');
};

$(".armyteleport").click(function() {
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'teleport', location: 'army'}));
});
$(".medicteleport").click(function() {
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'teleport', location: 'medic'}));
});
$('.airportteleport').click(function () { 
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'teleport', location: 'airport'}));
});

$(".eventteleport").click(function() {
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'teleport', location: 'event'}));
});

$(".frakteleport").click(function() {
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'teleport', location: 'frak'}));
});

$('.afkteleport').click(function() { 
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'teleport', location: 'afkzone'}));
});

$('.closemainmenu').click(function() { 
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'close'}));    
});

function joinffa(id, p, mp) {
    $.post(`https://${GetParentResourceName()}/joinffa`, JSON.stringify({id: id, players: p, maxplayers: mp}));
}

$(".inventorybody").on("click", ".aufsatz", function() {
    const weapon = $(this).data("weapon");
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({ action: 'upgradeweapon', weapon: weapon }));
});
$(".inventorybody").on("click", ".geben", function() {
    const weapon = $(this).data("weapon");
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({ action: 'giveweapon', weapon: weapon }));
});

$(".fpsmode").change(function() {
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'fps'}));
});
$(".nightmode").change(function() {
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'night'}));
});
$(".drawfps").change(function() {
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'drawfps'}));
    if (fps == false) {
        fps = true;
        $('.fps').show();
    } else {
        fps = false;
        $('.fps').hide();
    }
});
$(".wetterbutton").click(function() {
    var selectElement = document.querySelector(".wetterchoose");
    var selectedValue = selectElement.value;
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'wetter', type: selectedValue}));
});

$('.verstanden').click(function() {
    if (regeln === true) {
        $('.aufnahme').fadeOut(200);
        $('.eventregeln').fadeIn(200);
    } else {
        $('.aufnahme').fadeOut(200);
        $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'disableUI'}));
    }
});

$('.acceps').click(function() {
    $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'disableUI'}));
    $('.eventregeln').fadeOut();
});

function loadweapons(weapons) {
    $(".weaponshopbody").empty();
    const weaponInfoList = weapons;
    if (weaponInfoList !== undefined && weaponInfoList.length > 0) {
        weaponInfoList.forEach((weaponInfo) => {
            const content = $(`
                <div class="shopitemouter">
                    <div class="shopitem">
                        <div class="shopitemhead">
                            <p class="weaponname">${weaponInfo.weapon}</p>
                            <div class="shopitemheadright">
                                <p class="itemtype">${weaponInfo.type}</p>
                            </div>
                        </div>
                        <div class="shopitemimage">
                            <img src="weapons/${weaponInfo.weaponitem}.png">
                        </div>
                        <div class="shopitemprice">
                            <p class="price">${formatNum(weaponInfo.price)}$</p>
                        </div>
                    </div>
                    <div class="butt">
                        <button class="buysbutton ${weaponInfo.weaponitem}">KAUFEN</button>
                        <button class="buysbutton2 ${weaponInfo.weaponitem}2">VERKAUFEN</button>
                    </div>
                </div>
            `);
            $(".weaponshopbody").append(content);
            $(`.${weaponInfo.weaponitem}`).click(function() {
                $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action:'weaponshop', name: weaponInfo.weaponitem, price: weaponInfo.price, type: weaponInfo.type}));
            });
            $(`.${weaponInfo.weaponitem}2`).click(function() {
                $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action:'weaponshopsell', name: weaponInfo.weaponitem, price: weaponInfo.price, type: weaponInfo.type}));
            });
        });
    }
};

function loadffa(data) {
    if (data !== undefined && data.length > 0) {
        $(".ffabody").empty();
        data.forEach((v) => {
            const content = $(`
            <div class="ffaitem">
                <div class="preview">
                    <div class="previewhead">
                        <h2>${v.name}</h2>
                        <h3>FFA</h3>   
                    </div>
                    <img src="img/${v.name}.png" alt="">
                </div>
                <div class="ffabutton">
                    <button class="ffabutt" onclick="joinffa('${v.name}', ${v.players}, ${v.maxplayers})">Join</button>
                    <div class="showpl"><i class="fa-sharp fa-solid fa-person ffaicon"></i> ${v.players}/${v.maxplayers}</div>
                </div>                    
            </div>
            `);
            $(".ffabody").append(content);
        });
    }
};

function loadleaderboard(data) {
    $(".leaderboardbody").empty();
    if (data) {
        data.forEach((v, index) => {
            if (v.name === "0") {
                return;
            }
            let rankClass;
            if (index === 0) {
                rankClass = 'gold';
            } else if (index === 1) {
                rankClass = 'silver';
            } else if (index === 2) {
                rankClass = 'bronce';
            } else {
                rankClass = 'ranked';
            }
            const content = $(`
            <div class="rankeduser">
                <div class="rank">
                    <p class="${rankClass}">#${v.placement}</p>
                </div>
                <div class="rankedname">
                    <p>${v.name}</p>
                </div>
                <div class="rankedstat">
                    <p>${v.kills}</p>
                </div>
                <div class="rankedstat">
                    <p>${v.tode}</p>
                </div>
                <div class="rankedstat">
                    <p>${v.kd}</p>
                </div>
            </div>
            `);
            $(".leaderboardbody").append(content);
        });
    }
};       

function inventar(data) {
    if (data !== undefined && data.length > 0) {
        $(".inventorybody").empty();
        data.forEach((weapon) => {
            const invItem = $(`
                <div class="invitem">
                    <img class="invimg" src="weapons/${weapon.name}.png">
                    <div class="invbuttons">
                        <button class="invbutton aufsatz" data-weapon="${weapon.name}">Upgrade</button>
                        <button class="invbutton geben" data-weapon="${weapon.name}">Geben</button>
                    </div>
                </div>
            `);
            $(".inventorybody").append(invItem);
        });
    }
};

function crosshair(data) {
    $('.crosshairbody').empty();
    data.forEach((v, index) => {
        const content = $(`
            <div class="crosshairbox cr${index + 1}">
                <img src="${v.img}" alt="">
            </div>
        `);
        $(".crosshairbody").append(content);
        if (v.default === true) {
            $(`.cr${index + 1}`).click(function() {
                $(".crosshair").fadeOut(200);
            });
        } else {
            $(`.cr${index + 1}`).click(function() {
                $(".crosshair").fadeIn();
                $(".crosshair").css('display', 'flex');
                $(".crosshair img").attr('src', v.img);
                $(".crosshair img").css('width', v.size+"%");
                $(".crosshair img").css('height', v.size+"%");
            });
        }
    });
}

function playerlist(data) {
    
}

function sidebar(group, job) {
    $('.sidebar').empty();
    let content = `
        <div class="sidebaritem sidebarbutton1 sidebaractive" onclick="mainmenusidebar(1)">
            <div class="sidebariconbox">
                <i class="fa-sharp fa-solid fa-map"></i>
            </div>
            <div class="sidebartextbox">
                <p>Teleporter</p>
            </div>
        </div>
        <div class="sidebaritem sidebarbutton2" onclick="mainmenusidebar(2)">
            <div class="sidebariconbox">
                <i class="fa-sharp fa-solid fa-gun"></i>
            </div>
            <div class="sidebartextbox">
                <p>Waffen Shop</p>
            </div>
        </div>
        <div class="sidebaritem sidebarbutton3" onclick="mainmenusidebar(3)">
            <div class="sidebariconbox">
                <i class="fa-sharp fa-solid fa-backpack"></i>
            </div>
            <div class="sidebartextbox">
                <p>Inventar</p>
            </div>
        </div>
        <div class="sidebaritem sidebarbutton4" onclick="mainmenusidebar(4)">
            <div class="sidebariconbox">
                <i class="fa-solid fa-person-rays"></i>
            </div>
            <div class="sidebartextbox">
                <p>FFA</p>
            </div>
        </div>
        <div class="sidebaritem sidebarbutton5" onclick="mainmenusidebar(5)">
            <div class="sidebariconbox">
                <i class="fa-sharp fa-solid fa-chart-simple"></i>
            </div>
            <div class="sidebartextbox">
                <p>Leaderboard</p>
            </div>
        </div>
        <div class="sidebaritem sidebarbutton6" onclick="mainmenusidebar(6)">
            <div class="sidebariconbox">
                <i class="fa-sharp fa-regular fa-crosshairs"></i>
            </div>
            <div class="sidebartextbox">
                <p>Crosshair</p>
            </div>
        </div>
        <div class="sidebaritem sidebarbutton7" onclick="mainmenusidebar(7)">
            <div class="sidebariconbox">
                <i class="fa-sharp fa-solid fa-gear"></i>
            </div>
            <div class="sidebartextbox">
                <p>Einstellungen</p>
            </div>
        </div>`;

    if (job && job !== 'unemployed' && job !== 'fraklos') {
        content += `
        <div class="sidebaritem sidebarbutton12" onclick="mainmenusidebar(12)">
            <div class="sidebariconbox">
                <i class="fa-sharp fa-solid fa-briefcase"></i>
            </div>
            <div class="sidebartextbox">
                <p>Fraktion</p>
            </div>
        </div>`;
    }

    content += ``;

    if (group !== 'user') {
        content += `
        <div class="sidebaritem sidebarbutton9" onclick="mainmenusidebar(9)">
            <div class="sidebariconbox">
                <i class="fa-sharp fa-solid fa-megaphone"></i>
            </div>
            <div class="sidebartextbox">
                <p>Event Admin</p>
            </div>
        </div>
        <div class="sidebaritem sidebarbutton10" onclick="mainmenusidebar(10)">
            <div class="sidebariconbox">
                <i class="fa-sharp fa-solid fa-user-crown"></i>
            </div>
            <div class="sidebartextbox">
                <p>Administration</p>
            </div>
        </div>
        <div class="sidebaritem sidebarbutton11" onclick="mainmenusidebar(11)">
            <div class="sidebariconbox">
                <i class="fa-solid fa-swords"></i>
            </div>
            <div class="sidebartextbox">
                <p>Arena</p>
            </div>
        </div>
        <div class="sidebaritem sidebarbutton8" onclick="mainmenusidebar(8)">
            <div class="sidebariconbox">
                <i class="fa-sharp fa-solid fa-question"></i>
            </div>
            <div class="sidebartextbox">
                <p>Hilfe</p>
            </div>
        </div>`;
    }

    $(".sidebar").append(content);
}

window.addEventListener('message', function(event){
    if (event.data.action === 'notify'){
        var item = event.data;
        if (item !== undefined) {
            const createNotification = (type) => {
                const content = $(`
                    <div class="notify_item notify_${type}">
                        <div class="notify_head">
                            <div class="notify_icon notify_icon_${type}">
                                <i class="fa-sharp fa-solid fa-circle-info"></i>
                            </div>
                            <h2 class="notify_title notify_title_${type}">${item.title}</h2>
                        </div>
                        <p>${item.message}</p>
                        <div class="loadingbar">
                            <div class="loadingbar_inner loadingbar_${type}"></div>
                        </div>
                    </div>
                `);
                $(".notify_container").prepend(content);
                setTimeout(() => {
                    content.fadeOut(500, () => content.remove());
                }, 5000);
            };
            switch (item.type) {
                case "g":
                    createNotification("g");
                    break;
                case "r":
                    createNotification("r",);
                    break;
                case "y":
                    createNotification("y");
                    break;
                case "t":
                    createNotification("t");
                    break;
            }
        }        
    } else if (event.data.action === 'mainmenu') {
        if (event.data.enable === true) {
            mainmenusidebar(1);
            $('.mainmenu').fadeIn(200);
            loadleaderboard(event.data.leaderboard);
            loadffa(event.data.ffa);
            sidebar(event.data.group, event.data.job);
            loadweapons(event.data.weaponshop);
            inventar(event.data.loadout);
            crosshair(event.data.crosshairs);
            playerlist(event.data.players);
            $('.playername').text(event.data.playername);
            $('.playermoney').text(formatNum(event.data.money) + '$');
        } else {
            $('.mainmenu').fadeOut(200);
        }
    } else if (event.data.action === 'updatemoney') {
        $('.playermoney').text(formatNum(event.data.money) + '$');
        $('.moneyinsert').text(formatNum(event.data.money));
    } else if (event.data.action === 'announce') {
        const content = $(`
            <div class="announce">
                <div class="announcetitle">
                    <div class="announceicon">
                        <i class="fa-sharp fa-solid fa-circle-info"></i>
                    </div>
                    <h2>ANNOUNCEMENT</h2>
                </div>
                <div class="announcetext">
                    <p>${event.data.message}</p>
                </div>
                <div class="announceloader">
                    <div class="announceloaderinner"></div>
                </div>
            </div>
        `);
        const announceTime = event.data.time || 4000;
        content.find('.announceloaderinner').css('animation-duration', `${announceTime + 400}ms`);
        $(".announcebox").prepend(content);
        content.show();
        setTimeout(() => {
            content.fadeOut(500, () => content.remove());
        }, announceTime);
    } else if (event.data.action === 'aufnahme') {
        $('.aufnahme').fadeIn();
        $('.aufnahme p').text(event.data.text);
        $('.aufnahme').css('display', 'flex');
        regeln = event.data.regeln;
    } else if (event.data.action === 'warning') {
        $('.warning').css('display', 'flex');
        $('.warntext').text(event.data.reason);
    } else if (event.data.action === 'updateloadout') {
        inventar(event.data.loadout);
    }
});

document.addEventListener("keydown", function(event) {
    if (event.key === "Escape") {
        $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'close'}));
    }
});

$(document).ready(function() {
    var $button = $("#warnButton");
    var $loadingBar = $(".buttoninnerwarn");
    var progress = 0;
    var interval;
    function startLoading() {
        interval = setInterval(function() {
            progress += 1;
            $loadingBar.css("width", progress + "%");
            if (progress >= 100) {
                $('.warning').hide();
                $.post(`https://${GetParentResourceName()}/mainmenu`, JSON.stringify({action: 'closewarn'}));
                clearInterval(interval);
            }
        }, 100);
    }
    function resetLoading() {
        clearInterval(interval);
        progress = 0;
        $loadingBar.css("width", "0%");
    }
    $button.mousedown(function() {
        startLoading();
    });
    $button.mouseup(function() {
        resetLoading();
    });
    $button.mouseleave(function() {
        resetLoading();
    });
});