const axios = require('axios').default;
axios.defaults.headers = {};

const getDiscordUserProfile = async(identifier, options = {}) => {
    if (typeof identifier !== 'string') {
        console.log(`[^1ERROR^7] ^5Discord API:^7 identifier is not a string (^3${typeof identifier}^7)`);
        return null;
    }
    else if (typeof options !== 'object') {
        console.log(`[^1ERROR^7] ^5Discord API:^7 options is not an object (^3${typeof options}^7)`);
        return null;
    }
    const token = 'MTE0NjkwMjA0NjIzMDk3NDUwNA.GQKjj1.VXNhnFy6racZJ9JvOX9sPAoh-9Pbv9KlYAoDjw';
    const id = identifier.replace('discord:', '');
    const profile = await axios({
        method: 'GET',
        url: `https://discord.com/api/v10/users/${id}`,
        responseType: 'json',
        headers: { 'Accept-Encoding': 'application/json', 'Content-Type': 'application/json', 'Authorization': `Bot ${token}` }
    }).then(async(user) => {
        user.data.avatar_url = `https://cdn.discordapp.com/avatars/${user.data.id}/${user.data.avatar}.webp?size=4096`;
        if (typeof options.imageData === 'boolean' && options.imageData === true) {
            await axios({
                method: 'GET',
                url: user.data.avatar_url,
                responseType: 'text',
            }).then((image) => {
                user.data.avatar_data = image.data;
            }).catch((err) => {
                console.log(`[^1ERROR^7] ^5Discord CDN:^7 ${err.message}`);
            });
        }
        return user.data;
    }).catch((err) => {
        console.log(`[^1ERROR^7] ^5Discord API:^7 ${err.message}`);
        return null;
    });
    return profile;
}

exports('Discord', getDiscordUserProfile);