Locales = {}
function _(str, ...) -- Translate string
	if Locales['de'] ~= nil then
		if Locales['de'][str] ~= nil then
			return string.format(Locales['de'][str], ...)
		else
			return 'This does not exist!'
		end
	else
		return 'This does not exist!'
	end

end
function _U(str, ...) -- Translate string first char uppercase
	return tostring(_(str, ...):gsub("^%l", string.upper))
end