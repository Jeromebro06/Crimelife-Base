RegisterCommand("frakleave", function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.job.name == 'unemployed' then
        TriggerClientEvent("notifications", source, "r", "Frak-System", "Du bist in keiner Fration")
    else
        xPlayer.setJob('unemployed', 0) 
        Wait(100)
        TriggerClientEvent("notifications", source, "g", "Frak-System", "Du hast deine Fraktion verlassen")
    end
end)

RegisterCommand("announce", function(source, args)
    local xPlayer = ESX.GetPlayerFromId(source)
    local argString = table.concat(args, " ")
    if source == 0 or source == nil then 
        if argString ~= nil then
            TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, argString, 7000)
        end
        return
    end
    if xPlayer then
        if xPlayer.getGroup() ~= "user" then
            if argString ~= nil then
                TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, argString, 7000)
            end
        end
    end
end)

RegisterCommand("revive", function(source, args)
    local xPlayer = ESX.GetPlayerFromId(source)
    if args[1] == nil then args[1] = source end
    if args[1] == 'me' then args[1] = source end
    if xPlayer.getGroup() ~= "user" then
		if args[1] == nil then
			TriggerClientEvent('esx_ambulancejob:revive', source)
		elseif args[1] == "me" then
			TriggerClientEvent('esx_ambulancejob:revive', source)
		else
			TriggerClientEvent('esx_ambulancejob:revive', args[1])
		end
    else
        if source == 0 and args[1] ~= nil then 
            TriggerClientEvent('esx_ambulancejob:revive', args[1])
        end
    end
end)
RegisterCommand("players", function(source, args, user)
    if source ~= 0 then
        if GetNumPlayerIndices() == 1 then
            TriggerClientEvent("notifications", source, "g", "Warrios-System", "Nur du bist gerde auf dem Server !")
        else
            TriggerClientEvent("notifications", source, "g", "Warrios-System", "Es sind gerade  " .. GetNumPlayerIndices() .. " Spieler Online !")
        end
    end
end)
RegisterCommand("dv", function(source, args)
	local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer and xPlayer.getGroup() ~= "user" then
		local PedVehicle = GetVehiclePedIsIn(GetPlayerPed(xPlayer.source), false)
		if DoesEntityExist(PedVehicle) then
			DeleteEntity(PedVehicle)
		end
		local Vehicles = ESX.OneSync.GetVehiclesInArea(GetEntityCoords(GetPlayerPed(xPlayer.source)),
			tonumber(args.radius) or 5.0)
		for i = 1, #Vehicles do
			local Vehicle = NetworkGetEntityFromNetworkId(Vehicles[i])
			if DoesEntityExist(Vehicle) then
				DeleteEntity(Vehicle)
			end
		end
	else
        if source ~= 0 then
		    TriggerClientEvent('notifications', source, "r", "WARRIOS SYSTEM", "Keine Rechte")
        end
	end
end)

RegisterCommand('giveitem', function(source, args)
	if args[1] == -1 then return end
    local xPlayer = ESX.GetPlayerFromId(source)
    if args[1] == 'me' then args[1] = source end
    if xPlayer and xPlayer.getGroup() == "pl" then
        local targetId = tonumber(args[1])
        local item = args[2]
        local count = tonumber(args[3])
        if targetId and item and count then
            local xTarget = ESX.GetPlayerFromId(targetId)
            if xTarget then
                xTarget.addInventoryItem(item, count)
                local message = "Du hast " .. count .. "x " .. item .. " erhalten."
                TriggerClientEvent('notifications', xTarget.source, 'success', 'Warrios System', message)
                local discordMessage = {
                    {
                        ["color"] = 4886754,
                        ["title"] = "Admin Give Item",
                        ["fields"] = {
                            {["name"] = "Admin", ["value"] = "[" .. xTarget.source .. "] " .. GetPlayerName(xTarget.source), ["inline"] = true},
							{["name"] = "Spieler", ["value"] = "[" .. source .. "] " .. GetPlayerName(source), ["inline"] = true},
                            {["name"] = "Item", ["value"] = item.."/"..count, ["inline"] = true}                        },
                        ["footer"] = {
                            ["text"] = Webhooks.Footer
                        }
                    }
                }
                PerformHttpRequest(Webhooks.URLS['GiveItem'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
            else
                TriggerClientEvent('notifications', source, 'error', 'WARRIOS SYSTEM', 'Ungültige Ziel-ID.')
            end
        else
            TriggerClientEvent('notifications', source, 'error', 'WARRIOS SYSTEM', 'Ungültige Befehlsparameter.')
        end
    else
        TriggerClientEvent('notifications', source, "r", "WARRIOS SYSTEM", "Keine Rechte")
    end
end)

RegisterCommand('giveweapon', function(source, args)
	if args[1] == -1 then return end
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    if args[1] == 'me' then args[1] = source end
    if xPlayer then
        if (xPlayer.getGroup() == "pl" or xPlayer.getGroup() == "mng" ) then
            local targetId = tonumber(args[1])
            local weaponName = args[2]
            local ammo = tonumber(args[3])
            if targetId and weaponName and ammo then
                local xTarget = ESX.GetPlayerFromId(targetId)
                if xTarget then
                    if not xTarget.hasWeapon(weaponName) then
                        xTarget.addWeapon(weaponName, ammo)
                        TriggerClientEvent('updateloadout', xTarget.source, (xTarget.getLoadout() or {}))
                        local discordMessage = {
                            {
                                ["color"] = 4886754,
                                ["title"] = "Admin give Weapon",
                                ["fields"] = {
                                    {["name"] = "Admin", ["value"] = "["..source.."] ".. GetPlayerName(source), ["inline"] = true},
                                    {["name"] = "Spieler", ["value"] = "["..targetId.."] ".. GetPlayerName(targetId), ["inline"] = true},
                                    {["name"] = "Given Weapon", ["value"] = weaponName .." / " .. ammo, ["inline"] = true},
                                },
                                ["footer"] = {
                                    ["text"] = Webhooks.Footer
                                }
                            }
                        }
                        PerformHttpRequest(Webhooks.URLS['GiveWeapon'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
                    else
                        TriggerClientEvent('notifications', source, "r", "WARRIOS SYSTEM", "Spieler hat bereits diese Waffe.")
                    end
                else
                    TriggerClientEvent('notifications', source, "r", "WARRIOS SYSTEM", "Ungültige Ziel-ID.")
                end
            else
                TriggerClientEvent('notifications', source, "r", "WARRIOS SYSTEM", "Ungültige Befehlsparameter.")
            end
        else
            TriggerClientEvent('notifications', source, "r", "WARRIOS SYSTEM", "Keine Rechte")
        end
    else
        local targetId = tonumber(args[1])
        local weaponName = args[2]
        local ammo = tonumber(args[3])
        if targetId and weaponName and ammo then
            local xTarget = ESX.GetPlayerFromId(targetId)
            if xTarget then
                if not xTarget.hasWeapon(weaponName) then
                    xTarget.addWeapon(weaponName, ammo)
                    TriggerClientEvent('updateloadout', xTarget.source, (xTarget.getLoadout() or {}))
                    local discordMessage = {
                        {
                            ["color"] = 4886754,
                            ["title"] = "Admin give Weapon",
                            ["fields"] = {
                                {["name"] = "Admin", ["value"] = "Console", ["inline"] = true},
                                {["name"] = "Spieler", ["value"] = "["..targetId.."] ".. GetPlayerName(targetId), ["inline"] = true},
                                {["name"] = "Given Weapon", ["value"] = weaponName .." / " .. ammo, ["inline"] = true},
                            },
                            ["footer"] = {
                                ["text"] = Webhooks.Footer
                            }
                        }
                    }
                    PerformHttpRequest(Webhooks.URLS['GiveWeapon'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
                else
                    print("^8[WARRIOS] ^1Spieler hat bereits diese Waffe.")
                end
            else
                print("^8[WARRIOS] ^1Ungültige Ziel-ID.")
            end
        else
            print("^8[WARRIOS] ^1Ungültige Befehlsparameter.")
        end
    end
end)

RegisterCommand('setgroup', function(source, args)
	if args[1] == -1 then return end
	local s = source
    if (s == 0 or s == nil) then
		if args[1] and args[2] then
			local xPlayer = ESX.GetPlayerFromId(args[1])
			if xPlayer then
				xPlayer.setGroup(args[2])
				local discordMessage = {
					{
						["color"] = 4886754,
						["title"] = "Admin give Group",
						["fields"] = {
							{["name"] = "Admin", ["value"] = "Console", ["inline"] = true},
							{["name"] = "Spieler", ["value"] = "["..args[1].."] ".. GetPlayerName(args[1]), ["inline"] = true},
							{["name"] = "Given Group", ["value"] = args[2], ["inline"] = true},
						},
						["footer"] = {
							["text"] = Webhooks.Footer
						}
					}
				}
				PerformHttpRequest(Webhooks.URLS['GiveGroup'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
				print('^8[WARRIOS] ^2SUCCES')
			else
				print('^8[WARRIOS] ^1Ungültige ID')
			end
		else
			print('^8[WARRIOS] ^1Ungültige Parameter')
		end
	else
		TriggerClientEvent('notifications', source, "r", "WARRIOS SYSTEM", "Keine Rechte")
	end
end)

RegisterCommand('givemoney', function(source, args)
    if args[1] == -1 then return end
    if args[1] == 'me' then args[1] = source end
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer and (xPlayer.getGroup() == "pl" or xPlayer.getGroup() == "mng" ) then
        if args[1] then
            local xPlayer = ESX.GetPlayerFromId(args[1])
            if xPlayer then
                if args[2] then
                xPlayer.addAccountMoney('money', tonumber(args[2]))
                TriggerClientEvent('notifications', source, "g", "WARRIOS SYSTEM", "SUCCES")
                local discordMessage = {
                    {
                        ["color"] = 4886754,
                        ["title"] = "Admin give Money",
                        ["fields"] = {
                            {["name"] = "Admin", ["value"] = "["..source.."] ".. GetPlayerName(source), ["inline"] = true},
                            {["name"] = "Spieler", ["value"] = "["..args[1].."] ".. GetPlayerName(args[1]), ["inline"] = true},
                            {["name"] = "Given Money", ["value"] = tonumber(args[2]), ["inline"] = true},
                        },
                        ["footer"] = {
                            ["text"] = Webhooks.Footer
                        }
                    }
                }
                PerformHttpRequest(Webhooks.URLS['GiveMoney'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
                end
            else
                TriggerClientEvent('notifications', source, 'r', 'Fehler', 'Der Spieler existiert nicht.')
            end
        else
            TriggerClientEvent('notifications', source, 'r', 'Fehler', 'Ungültige Parameter')
        end
    else
        TriggerClientEvent('notifications', source, "r", "WARRIOS SYSTEM", "Keine Rechte")
    end
end)

RegisterCommand('tpm', function(source, args)
	local xPlayer = ESX.GetPlayerFromId(source)
	if xPlayer and xPlayer.getGroup() ~= "user" then
		xPlayer.triggerEvent("warrios_core:🌹🌹:tpm")
	else
		TriggerClientEvent('notifications', source, "r", "WARRIOS SYSTEM", "Keine Rechte")
	end
end)

RegisterCommand("job", function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.job.name == 'unemployed' then
        TriggerClientEvent("notifications", source, "r", "Frak-System", "Du bist in keiner Fration")
    else
        Wait(100)
        TriggerClientEvent("notifications", source, "g", "Frak-System", "Dein Job: "..xPlayer.job.name.." / Rang: "..xPlayer.job.grade)
    end
end)

RegisterCommand("invite", function(source, args)
	if args[1] == -1 then return end
	local xPlayer = ESX.GetPlayerFromId(source)
	local xTarget = ESX.GetPlayerFromId(tonumber(args[1]))
	if xTarget == nil then
	  	TriggerClientEvent('notifications', source, "r", "Frak-System", "Ungültige ID.")
	else
		if xPlayer.job.grade == 4 then 
			if xTarget.job.name == xPlayer.job.name then
				TriggerClientEvent('notifications', source, "r", "Frak-System", "Dieser Spieler ist bereits in deiner Fraktion.")
			else
				TriggerClientEvent("🚟🚟🚟🚟🚞🚞🚄🦽🦽🚜🚜🚐🚖", xTarget.source, Config.fraks[xPlayer.job.name].jobimage, xPlayer.job.name, source)
			end
		else
			TriggerClientEvent('notifications', source, "r", "Frak-System", "Du hast dazu keine Rechte.")
		end
	end
end, false)


RegisterCommand("tc", function(source, args, rawCommand)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer and xPlayer.getGroup() ~= "user" then
        local argString = table.concat(args, ' ')
        if argString and argString ~= '' then
            local xPlayers = ESX.GetPlayers()
            for i = 1, #xPlayers do
                local targetPlayer = ESX.GetPlayerFromId(xPlayers[i])
                if targetPlayer and targetPlayer.getGroup() ~= 'user' then
                    TriggerClientEvent('notifications', xPlayers[i], "t", "Team-Chat", '['..GetPlayerName(source)..'] '.. argString)
                end
            end
			local discordMessage = {
				{
					["color"] = 4886754,
					["title"] = "Teamchat",
					["fields"] = {
						{["name"] = "Teamler", ["value"] = "["..source.."] "..GetPlayerName(source).."", ["inline"] = true},
						{["name"] = "Message", ["value"] = argString, ["inline"] = true}
					},
					["footer"] = {
						["text"] = Webhooks.Footer
					}
				}
			}
			PerformHttpRequest(Webhooks.URLS['TeamChat'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
        else
            TriggerClientEvent('notifications', source, 'r', 'Fehler', 'Du musst eine Nachricht eingeben.')
        end
    else
        TriggerClientEvent('notifications', source, 'r', 'Fehler', 'Du hast keine Berechtigung für diesen Befehl.')
    end
end)

RegisterCommand('setjob', function(source, args, user)
	if args[1] == -1 then return end
    local xPlayer = ESX.GetPlayerFromId(source)
    if args[1] == 'me' then args[1] = source end
    if xPlayer and xPlayer.getGroup() == "pl" then
        local targetId = tonumber(args[1])
        local jobName = args[2]
        local jobGrade = tonumber(args[3])
        if targetId and jobName and jobGrade then
            local xTarget = ESX.GetPlayerFromId(targetId)
            if xTarget then
                if ESX.DoesJobExist(jobName, jobGrade) then
                    xTarget.setJob(jobName, jobGrade)
                    MySQL.Async.execute('UPDATE users SET job = @job, job_grade = @jobgrade WHERE identifier = @identifier', {
                        ['@identifier'] = xTarget.getIdentifier(),
                        ['@job'] = jobName,
                        ['@jobgrade'] = jobGrade
                    }, function(rowsChanged)
                    end)
                    local discordMessage = {
                        {
                            ["color"] = 4886754,
                            ["title"] = "Admin set Job",
                            ["fields"] = {
								{["name"] = "Admin", ["value"] = "[" .. source .. "] " .. GetPlayerName(source), ["inline"] = true},
                                {["name"] = "Spieler", ["value"] = "[" .. xTarget.source .. "] " .. GetPlayerName(xTarget.source), ["inline"] = true},
                                {["name"] = "Job", ["value"] = jobName.."/"..jobGrade, ["inline"] = true}
                            },
                            ["footer"] = {
                                ["text"] = Webhooks.Footer
                            }
                        }
                    }
                    PerformHttpRequest(Webhooks.URLS['SetJob'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
                else
                    TriggerClientEvent('notifications', source, 'error', 'Fehler', 'Der Job existiert nicht.')
                end
            else
                TriggerClientEvent('notifications', source, 'error', 'Fehler', 'Der Spieler existiert nicht.')
            end
        else
            TriggerClientEvent('notifications', source, 'error', 'Fehler', 'Ungültige Parameter.')
        end
    else
        TriggerClientEvent('notifications', source, "r", "WARRIOS SYSTEM", "Keine Rechte")
    end
end)

RegisterCommand('supcall', function(source, args)
	local xPlayer = ESX.GetPlayerFromId(source)
	if xPlayer then
		local group = xPlayer.getGroup()
		if group ~= "user" then
			if args[1] ~= nil then
				TriggerClientEvent('💨💨💨💨💨💨💨💨💨komma', args[1], source)
				TriggerClientEvent('notifications', source, "g", "WARRIOS SYSTEM", "Spieler erfolgreich in den Support gerufen")
				local playerId = source
				local discordMessage = {
					{
						["color"] = 4886754,
						["title"] = "Supportcall",
						["fields"] = {
							{["name"] = "Teamler", ["value"] = "["..source.."] "..GetPlayerName(source).."", ["inline"] = true},
							{["name"] = "Target", ["value"] = "["..args[1].."] "..GetPlayerName(args[1]).."", ["inline"] = true}
						},
						["footer"] = {
							["text"] = Webhooks.Footer
						}
					}
				}
				PerformHttpRequest(Webhooks.URLS['SupCall'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
			else
				TriggerClientEvent('notifications', source, "r", "WARRIOS SYSTEM", "Keine ID Angegeben")
			end
		else
			TriggerClientEvent('notifications', source, "r", "WARRIOS SYSTEM", "Keine Rechte")
		end
	else
		if args[1] ~= nil then
			TriggerClientEvent('💨💨💨💨💨💨💨💨💨komma', args[1], source)
			print("^8[WARRIOS] ^2Spieler erfolgreich in den Support gerufen")
			local playerId = source
			local discordMessage = {
				{
					["color"] = 4886754,
					["title"] = "Supportcall",
					["fields"] = {
						{["name"] = "Teamler", ["value"] = "Console", ["inline"] = true},
						{["name"] = "Target", ["value"] = "["..args[1].."] "..GetPlayerName(args[1]).."", ["inline"] = true}
					},
					["footer"] = {
						["text"] = Webhooks.Footer
					}
				}
			}
			PerformHttpRequest(Webhooks.URLS['SupCall'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
		else
			print('^8[WARRIOS] ^1Keine ID Angegeben')
		end
	end
end)

RegisterCommand('copyoutfit', function(source, args, raw)
    copyoutfit(source, args)
end)

RegisterCommand('copy', function(source, args, raw)
    copyoutfit(source, args)
end)

function copyoutfit(source, args)
    local xPlayer = ESX.GetPlayerFromId(args[1])
    if args[1] ~= nil then
        if xPlayer ~= nil then
            if xPlayer.source ~= source then
                player = source
                TriggerClientEvent('💥💥💥☪☪💝💟💚💚💤💦', xPlayer.source, source)
                TriggerClientEvent('notifications', source, "g", 'Copyoutfit-System', 'Du hast eine Anfrage an ' .. GetPlayerName(xPlayer.source) .. ' gesendet!')
            else
                TriggerClientEvent('notifications', source, "r", 'Copyoutfit-System', 'Du kannst dich nicht selber kopieren!')
            end
        else
            TriggerClientEvent('notifications', source, "r", 'Copyoutfit-System', 'Die angegebene ID wurde nicht gefunden!')
        end
    else
        TriggerClientEvent('notifications', source, "g", 'Copyoutfit-System', 'Benutze /copyoutfit ID')
    end
end

RegisterCommand('skin', function(source)
	TriggerClientEvent('esx_skin:openSaveableMenu', source)
end)

RegisterCommand('createfrak', function(source, args)
    if source == 0 then
        if not args[1] or not args[2] then
            print('^8[WARRIOS] ^1createfrak jobname showname ^1(alles ohne Leerzeichen!!)')
        else
            local frakName = args[1]
            local showName = args[2]
            MySQL.Async.execute('INSERT INTO jobs (name, label) VALUES (@frakName, @showName)', {
                ['@frakName'] = frakName,
                ['@showName'] = showName
            }, function(rowsChanged)
                if rowsChanged > 0 then
                    print('^8[WARRIOS] ^2Fraktion ' .. frakName .. ' mit dem Label ' .. showName .. ' erfolgreich erstellt und in die Datenbank eingefügt.')
                else
                    print('^8[WARRIOS] ^1Fehler beim Einfügen der Fraktion ' .. frakName .. ' in die Datenbank.')
                end
            end)
			Wait(10)
			MySQL.Async.execute('INSERT INTO job_grades (job_name, grade, name, label, salary) VALUES (@frakName, @grade, @name, @showName, @salary)', {
                ['@frakName'] = frakName,
				['@grade'] = 1,
				['@name'] = 'Rang1',
                ['@showName'] = showName,
				['@salary'] = 0,
            }, function(rowsChanged)
                if rowsChanged > 0 then
                    print('^8[WARRIOS] ^2Rang 1 Erstellt')
                else
                    print('^8[WARRIOS] ^1Fehler beim Einfügen der Fraktion ' .. frakName .. ' in die Datenbank.')
                end
            end)
			Wait(10)
			MySQL.Async.execute('INSERT INTO job_grades (job_name, grade, name, label, salary) VALUES (@frakName, @grade, @name, @showName, @salary)', {
                ['@frakName'] = frakName,
				['@grade'] = 2,
				['@name'] = 'Rang2',
                ['@showName'] = showName,
				['@salary'] = 0,
            }, function(rowsChanged)
                if rowsChanged > 0 then
                    print('^8[WARRIOS] ^2Rang 2 Erstellt')
                else
                    print('^8[WARRIOS] ^1Fehler beim Einfügen der Fraktion ' .. frakName .. ' in die Datenbank.')
                end
            end)
			Wait(10)
			MySQL.Async.execute('INSERT INTO job_grades (job_name, grade, name, label, salary) VALUES (@frakName, @grade, @name, @showName, @salary)', {
                ['@frakName'] = frakName,
				['@grade'] = 3,
				['@name'] = 'Rang3',
                ['@showName'] = showName,
				['@salary'] = 0,
            }, function(rowsChanged)
                if rowsChanged > 0 then
                    print('^8[WARRIOS] ^2Rang 3 Erstellt')
                else
                    print('^8[WARRIOS] ^1Fehler beim Einfügen der Fraktion ' .. frakName .. ' in die Datenbank.')
                end
            end)
			Wait(10)
			MySQL.Async.execute('INSERT INTO job_grades (job_name, grade, name, label, salary) VALUES (@frakName, @grade, @name, @showName, @salary)', {
                ['@frakName'] = frakName,
				['@grade'] = 4,
				['@name'] = 'Rang4',
                ['@showName'] = showName,
				['@salary'] = 0,
            }, function(rowsChanged)
                if rowsChanged > 0 then
                    print('^8[WARRIOS] ^2Rang 4 Erstellt')
                else
                    print('^8[WARRIOS] ^1Fehler beim Einfügen der Fraktion ' .. frakName .. ' in die Datenbank.')
                end
            end)
        end
    end
end, false)

RegisterCommand('showfraks', function(source)
    if source == 0 then
        MySQL.Async.fetchAll('SELECT * FROM jobs', {}, function(jobs)
            for i = 1, #jobs do
                print(string.format("^8[WARRIOS] ^0[^2"..i.."^0] ^1Name:^4 %s ^0| ^1Label:^4 %s", jobs[i].name, jobs[i].label))
            end
        end)
    end
end, false)

local bwp = {}
local cooldownTime = 120
RegisterServerEvent('🥗🧀🥗🥗🥞🥪🥪🥟🍠🥩🥗🥠🥠🥟', function()
    local _source = source
    local currentTime = os.time()
    local xPlayer = ESX.GetPlayerFromId(_source)
    local job = xPlayer.getJob().name
    local rank = xPlayer.getJob().grade
    if rank == 4 and job ~= 'unemployed' then
        if not bwp[job] or (currentTime - bwp[job]) >= cooldownTime then
            bwp[job] = currentTime
            TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "Die Fraktion "..Config.fraks[job].label.." hat eine offene Bewerbungsphase")
        else
            local remainingTime = math.ceil((cooldownTime - (currentTime - bwp[job])) / 60)
            TriggerClientEvent('notifications', _source, 'r', 'Information', 'Cooldown Aktiv! Bitte warte noch ' .. remainingTime .. ' Minuten.')
        end
    else
        TriggerClientEvent('notifications', _source, 'r', 'Information', 'Dazu hast du keine Rechte')
    end
end)

RegisterCommand('goto', function(source, args)
	local xPlayer = ESX.GetPlayerFromId(source)
	local xSource = ESX.GetPlayerFromId(args[1])
	if not xPlayer then
		print('^8[WARRIOS] ^1Dieser command ist nur ingame benutzbar')
		return
	end
	if xPlayer.getGroup() == 'user' then
		TriggerClientEvent('notifications', source, 'r', 'Information', 'Dazu hast du keine Rechte')
		return
	end
	if xSource then
		local pcoords = GetEntityCoords(GetPlayerPed(args[1]))
		SetEntityCoords(GetPlayerPed(source), pcoords)
	else
		TriggerClientEvent('notifications', source, 'r', 'Information', 'Dieser Spieler existiert nicht')
	end
end)

RegisterCommand('bring', function(source, args)
	local xPlayer = ESX.GetPlayerFromId(source)
	local xSource = ESX.GetPlayerFromId(args[1])
	if not xPlayer then
		print('^8[WARRIOS] ^1Dieser command ist nur ingame benutzbar')
		return
	end
	if xPlayer.getGroup() == 'user' then
		TriggerClientEvent('notifications', source, 'r', 'Information', 'Dazu hast du keine Rechte')
		return
	end
	if xSource then
		local pcoords = GetEntityCoords(GetPlayerPed(source))
		SetEntityCoords(GetPlayerPed(args[1]), pcoords)
		TriggerClientEvent('notifications', args[1], 'g', 'Information', 'Ein Admin hat dich zu sich gebracht')
	else
		TriggerClientEvent('notifications', source, 'r', 'Information', 'Dieser Spieler existiert nicht')
	end
end)