local ffaPlayerCounts = {}

RegisterServerEvent('joinffa')
AddEventHandler('joinffa', function(zoneid)
    local source = source
    local zoneName = Config.FFApoint.zones[zoneid]

    if not ffaPlayerCounts[zoneid] then
        ffaPlayerCounts[zoneid] = 1
    else
        ffaPlayerCounts[zoneid] = ffaPlayerCounts[zoneid] + 1
    end

    SetPlayerRoutingBucket(source, 9)
    local spawnPoints = zoneName.spawns
    local randomSpawn = spawnPoints[math.random(1, #spawnPoints)]
    SetEntityCoords(GetPlayerPed(source), randomSpawn.x, randomSpawn.y, randomSpawn.z)
    SetEntityHeading(GetPlayerPed(source), randomSpawn.w)
    TriggerClientEvent('warrios_base:❤❤❤❤:setffa', source, true)
end)

RegisterServerEvent('quitffa')
AddEventHandler('quitffa', function(zoneid, c)
    local source = source
    if ffaPlayerCounts[zoneid] and ffaPlayerCounts[zoneid] > 0 then
        ffaPlayerCounts[zoneid] = ffaPlayerCounts[zoneid] - 1
    end
    SetPlayerRoutingBucket(source, 0)
    TriggerClientEvent('warrios_base:❤❤❤❤:setffa', source, false)
    SetEntityCoords(GetPlayerPed(source), c)
    TriggerClientEvent("notifications", source, "g", "FFA", "Du hast das FFA verlassen")
end)

AddEventHandler('playerDropped', function(reason)
    local source = source
    TriggerClientEvent('notifications', -1, 't', 'INFO', GetPlayerName(source)..' disconnected. Grund:'..reason)
    if ffaPlayers ~= nil then
        local zoneid = ffaPlayers[source]
        if zoneid and ffaPlayerCounts[zoneid] and ffaPlayerCounts[zoneid] > 0 then
            ffaPlayerCounts[zoneid] = ffaPlayerCounts[zoneid] - 1
        end
    end
end)

CreateThread(function()
    while true do
        Wait(5 * 1000)
        TriggerClientEvent("warrios_base:❤❤❤❤:FFAdata", -1, ffaPlayerCounts)
    end
end)