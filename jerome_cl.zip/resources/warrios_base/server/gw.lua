local gwserveractive = false
local pointsfrak1 = 0
local pointsfrak2 = 0

RegisterServerEvent('💋💋💋💋💋💋💋💋💋💋💋💋💋💋💋💋💋💋💋', function(bool)
	local source = source
	if bool then
		SetPlayerRoutingBucket(source, 4)
	else
		SetPlayerRoutingBucket(source, 0)
	end
end)

for i = 0, GetNumPlayerIndices() - 1 do
    local player = GetPlayerFromIndex(i)
    SetPlayerRoutingBucket(player, 0)
end

RegisterServerEvent('💢💢💢💢💢✝✝✝🕉🕉💤💕', function(name)
	local source = source
	local xPlayer = ESX.GetPlayerFromId(source)
	local job = xPlayer.getJob().name
	if gwserveractive then 
		TriggerClientEvent('notifications', source, "r", "Gangwar", "Es ist bereits ein Gangwar aktiv!")
		return
	end
	MySQL.Async.fetchScalar("SELECT owner FROM gwzones WHERE zone = @zone", {
		['@zone'] = name
	}, function(owner)
		if owner == job then
			TriggerClientEvent('notifications', source, "r", "Gangwar", "Du kannst deine eigene Zone nicht angreifen.")
		else
			local ownercount = 0
			local angcount = 0
			local allplayers = GetPlayers()
			for i = 1, #allplayers do
				local s = allplayers[i]
				local p = ESX.GetPlayerFromId(s)
				if p then
					if p.job.name == owner then
						ownercount = ownercount +1
					elseif p.job.name == job then
						angcount = angcount + 1
					end
				end
			end
			if ownercount < Config.GWpoint.minonline then
				TriggerClientEvent('notifications', source, "r", "Gangwar", "Es sind zu wenig gegner Online!")
				return
			end
			if angcount < Config.GWpoint.minonline then
				TriggerClientEvent('notifications', source, "r", "Gangwar", "Es sind zu wenige Spieler deiner Frak Online")
				return
			end
			if ownercount >= Config.GWpoint.minonline and angcount >= Config.GWpoint.minonline then
				TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "Die Fraktion "..Config.fraks[job].label.." greift die Zone von "..Config.fraks[owner].label.." an")
				pointsfrak1 = 0
				pointsfrak2 = 0
				gwserveractive = true
				TriggerClientEvent('👏👏👏👏🎂🎂🎂🎂🎂🎂🎂', -1, false)
				for i = 1, #allplayers do
					local s = allplayers[i]
					local p = ESX.GetPlayerFromId(s)
					if not p then
						Wait(1000)
						p = ESX.GetPlayerFromId(s)
					end
					if p.job.name == owner then
						TriggerClientEvent('🌹🌹🤣🤦‍♂️😘😘😘😂😁💕💕😘🤣🌹🌹🌹🌹', s, true, job, name, 'frak1')
					elseif p.job.name == job then
						TriggerClientEvent('🌹🌹🤣🤦‍♂️😘😘😘😂😁💕💕😘🤣🌹🌹🌹🌹', s, true, owner, name, 'frak2')
					end
				end
			end
			Wait(100)
			TriggerClientEvent('👀✔🐱‍🚀🐱‍🚀🐱‍🚀🐱‍🚀🐱‍🚀🐱‍🚀🐱‍🚀🐱‍🚀🐱‍🚀🐱‍👓🐱‍👓🐱‍👓🐱‍👓🐱‍👓😒😒', source)
			local colors = {
				0xff0000,
				0x00ff00,
				0x0000ff
			}
			local discordMessage = {
				{
					["color"] = colors[math.random(1, 3)],
					["title"] = "Gangwar",
					["thumbnail"] = {
						["url"] = "https://cdn-icons-png.flaticon.com/512/12/12373.png"
					},
					["fields"] = {
						{["name"] = "Angreifer: "..Config.fraks[job].label, ["value"] = ""},
						{["name"] = "Verteidiger: "..Config.fraks[owner].label, ["value"] = ""},
						{["name"] = "Message: ", ["value"] = "Die Fraktion "..Config.fraks[job].label.." greift die Zone "..Config.GWpoint.zones[name].name.." an"},
					},
					["footer"] = {
						["text"] = Webhooks.Footer
					}
				}
			}
			PerformHttpRequest(Webhooks.URLS['GwAngriffe'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
			Wait((Config.GWpoint.gangwartime*60000))
			if pointsfrak1 > pointsfrak2 then
				MySQL.Async.execute('UPDATE `gwzones` SET `owner` = @owner WHERE zone = @zone', {
					['@owner'] = job,
					['@zone'] = name,
				})
				Wait(1000)
				for i = 1, #allplayers do
					local s = allplayers[i]
					local p = ESX.GetPlayerFromId(s)
					if p then
						if p.job.name == owner then
							TriggerClientEvent('esx_ambulancejob:revive', s)
							TriggerClientEvent('🐱‍💻🐱‍💻🐱‍💻🎶🎶🤦‍♂️🤣💕😂🎶😎🎉🙌😂😂', s)
						elseif p.job.name == job then
							TriggerClientEvent('esx_ambulancejob:revive', s)
							TriggerClientEvent('🐱‍💻🐱‍💻🐱‍💻🎶🎶🤦‍♂️🤣💕😂🎶😎🎉🙌😂😂', s)
						end
					end
				end
				TriggerClientEvent('🌹🌹🤣🤦‍♂️😘😘😘😂😁💕💕😘🤣🌹🌹🌹🌹', -1, false)
				TriggerClientEvent('👏👏👏👏🎂🎂🎂🎂🎂🎂🎂', -1, true)
				TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "Die Fraktion "..Config.fraks[job].label.." hat die Zone "..Config.GWpoint.zones[name].name.." erfolgreich eingenommen")
				local discordMessage = {
					{
						["color"] = 0xff0000,
						["title"] = "Gangwar",
						["thumbnail"] = {
							["url"] = "https://cdn-icons-png.flaticon.com/512/12/12373.png"
						},
						["fields"] = {
							{["name"] = "Angreifer: "..Config.fraks[job].label, ["value"] = "Punkte: "..pointsfrak1},
							{["name"] = "Verteidiger: "..Config.fraks[owner].label, ["value"] = "Punkte: "..pointsfrak2},
							{["name"] = "Ergebnis: ", ["value"] = "Die Fraktion "..Config.fraks[job].label.." hat die Zone "..Config.GWpoint.zones[name].name.." erfolgreich eingenommen"},
						},
						["footer"] = {
							["text"] = Webhooks.Footer
						}
					}
				}
				PerformHttpRequest(Webhooks.URLS['GwAdmin'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
			elseif pointsfrak1 < pointsfrak2 then
				Wait(1000)
				for i = 1, #allplayers do
					local s = allplayers[i]
					local p = ESX.GetPlayerFromId(s)
					if p then
						if p.job.name == owner then
							TriggerClientEvent('esx_ambulancejob:revive', s)
							TriggerClientEvent('🐱‍💻🐱‍💻🐱‍💻🎶🎶🤦‍♂️🤣💕😂🎶😎🎉🙌😂😂', s)
						elseif p.job.name == job then
							TriggerClientEvent('esx_ambulancejob:revive', s)
							TriggerClientEvent('🐱‍💻🐱‍💻🐱‍💻🎶🎶🤦‍♂️🤣💕😂🎶😎🎉🙌😂😂', s)
						end
					end
				end
				TriggerClientEvent('🌹🌹🤣🤦‍♂️😘😘😘😂😁💕💕😘🤣🌹🌹🌹🌹', -1, false)
				TriggerClientEvent('👏👏👏👏🎂🎂🎂🎂🎂🎂🎂', -1, true)
				TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "Die Fraktion "..Config.fraks[owner].label.." hat die Zone "..Config.GWpoint.zones[name].name.." erfolgreich verteidigt")
				local discordMessage = {
					{
						["color"] = 0xff0000,
						["title"] = "Gangwar",
						["thumbnail"] = {
							["url"] = "https://cdn-icons-png.flaticon.com/512/12/12373.png"
						},
						["fields"] = {
							{["name"] = "Angreifer: "..Config.fraks[job].label, ["value"] = "Punkte: "..pointsfrak1},
							{["name"] = "Verteidiger: "..Config.fraks[owner].label, ["value"] = "Punkte: "..pointsfrak2},
							{["name"] = "Ergebnis: ", ["value"] = "Die Fraktion "..Config.fraks[owner].label.." hat die Zone "..Config.GWpoint.zones[name].name.." erfolgreich verteidigt"},
						},
						["footer"] = {
							["text"] = Webhooks.Footer
						}
					}
				}
				PerformHttpRequest(Webhooks.URLS['GwErgebnis'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
			elseif pointsfrak1 == pointsfrak2 then
				Wait(1000)
				for i = 1, #allplayers do
					local s = allplayers[i]
					local p = ESX.GetPlayerFromId(s)
					if p then
						if p.job.name == owner then
							TriggerClientEvent('esx_ambulancejob:revive', s)
							TriggerClientEvent('🐱‍💻🐱‍💻🐱‍💻🎶🎶🤦‍♂️🤣💕😂🎶😎🎉🙌😂😂', s)
						elseif p.job.name == job then
							TriggerClientEvent('esx_ambulancejob:revive', s)
							TriggerClientEvent('🐱‍💻🐱‍💻🐱‍💻🎶🎶🤦‍♂️🤣💕😂🎶😎🎉🙌😂😂', s)
						end
					end
				end
				TriggerClientEvent('🌹🌹🤣🤦‍♂️😘😘😘😂😁💕💕😘🤣🌹🌹🌹🌹', -1, false)
				TriggerClientEvent('👏👏👏👏🎂🎂🎂🎂🎂🎂🎂', -1, true)
				TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "Die Fraktion "..Config.fraks[job].label.." hat die Zone "..Config.GWpoint.zones[name].name.." erfolgreich verteidigt")
				local discordMessage = {
					{
						["color"] = 0xff0000,
						["title"] = "Gangwar",
						["thumbnail"] = {
							["url"] = "https://cdn-icons-png.flaticon.com/512/12/12373.png"
						},
						["fields"] = {
							{["name"] = "Angreifer: "..Config.fraks[job].label, ["value"] = "Punkte: "..pointsfrak1},
							{["name"] = "Verteidiger: "..Config.fraks[owner].label, ["value"] = "Punkte: "..pointsfrak2},
							{["name"] = "Ergebnis: ", ["value"] = "Die Fraktion "..Config.fraks[owner].label.." hat die Zone "..Config.GWpoint.zones[name].name.." erfolgreich verteidigt"},
						},
						["footer"] = {
							["text"] = Webhooks.Footer
						}
					}
				}
				PerformHttpRequest(Webhooks.URLS['GwErgebnis'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
			end
			Wait(1000)
			MySQL.Async.fetchAll("SELECT owner, zone FROM gwzones WHERE owner IS NOT NULL", {}, function(results)
				if results and #results > 0 then
					local houseOwners = {}
					for _, h in ipairs(results) do
						table.insert(houseOwners, {
							owner = h.owner,
							name = h.zone
						})
					end
					TriggerClientEvent('updateblips', -1, houseOwners)
				end
			end)
			Wait(5*60000)
			gwserveractive = false
		end
	end)
end)

RegisterServerEvent('💢💢💢💢💢💢💢💢💢💢💢💌💌💌❣❣❣', function(killer, myfrak)
	local source = source
	if killer and myfrak then
		local myplayer = ESX.GetPlayerFromId(source)
		local killerplayer = ESX.GetPlayerFromId(killer)
		local myjob = myplayer.getJob().name
		local killerjob = killerplayer.getJob().name
		if myplayer and myjob and killerjob and killerplayer then
			if myplayer == killer then
				return
			end
			if myjob == killerjob then
				if myfrak == 'frak1' then
					if pointsfrak1 > 2 then
						pointsfrak1 = pointsfrak1 -3
						TriggerClientEvent('😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁🐱‍🚀', -1, pointsfrak1, pointsfrak2)
					end
				else
					if pointsfrak2 > 2 then
						pointsfrak2 = pointsfrak2 -3
						TriggerClientEvent('😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁🐱‍🚀', -1, pointsfrak1, pointsfrak2)
						return
					end
				end
			else
				if myfrak == 'frak1' then
					pointsfrak1 = pointsfrak1 +3
					TriggerClientEvent('😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁🐱‍🚀', -1, pointsfrak1, pointsfrak2)
				else
					pointsfrak2 = pointsfrak2 +3
					TriggerClientEvent('😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁🐱‍🚀', -1, pointsfrak1, pointsfrak2)
				end
			end
		end
	end
end)

ESX.RegisterServerCallback('getowners', function(source, cb)
    MySQL.Async.fetchAll("SELECT owner, zone FROM gwzones WHERE owner IS NOT NULL", {}, function(results)
        if results and #results > 0 then
            local houseOwners = {}
            for _, h in ipairs(results) do
                table.insert(houseOwners, {
                    owner = h.owner,
                    name = h.zone
                })
            end
            cb(houseOwners)
        else
            cb({})
        end
    end)
end)

RegisterCommand('showgw', function()
	if gwserveractive then
		print('^0[WARRIOS-GW] ^1- ^4Es ist ein Gangwar Aktiv // '..pointsfrak1..' - '..pointsfrak2)
	else
		print('^0[WARRIOS-GW] ^1- ^4Es ist kein Gangwar Aktiv')
	end
	MySQL.Async.fetchAll("SELECT owner, zone FROM gwzones WHERE owner IS NOT NULL", {}, function(results)
		if results and #results > 0 then
			for _, h in ipairs(results) do
				print('^0[WARRIOS-GW] ^1- Zone: ^4'..h.zone..' ^0| ^1Owner: ^4'..h.owner)
			end
		else
			print('^0[WARRIOS-GW] ^1- ^4Es gibt keien Gangwar zonen!')
		end
	end)
end)