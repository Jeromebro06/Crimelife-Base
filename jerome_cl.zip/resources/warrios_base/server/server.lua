local Jobs, LastTime, eventactive, zonecount, playersHealing, deadPlayers, battleactive = {}, nil, false, 1, {}, {}, false
local kills = {}
local battleroyale = false

local loadedCode = {}
RegisterServerEvent('verpissdichdubehinderterskidgehmalarbeiten')
AddEventHandler('verpissdichdubehinderterskidgehmalarbeiten', function()
	local _source = source
	if not loadedCode[_source] then
		loadedCode[_source] = true
		local text4 = LoadResourceFile(GetCurrentResourceName(), 'clientcode/gw.lua')
		local text1 = LoadResourceFile(GetCurrentResourceName(), 'clientcode/clientcode.lua')
		local text2 = LoadResourceFile(GetCurrentResourceName(), 'clientcode/ambulance.lua')
		local text3 = LoadResourceFile(GetCurrentResourceName(), 'clientcode/ffa.lua')
		local text5 = LoadResourceFile(GetCurrentResourceName(), 'clientcode/skinchanger.lua')
		TriggerClientEvent('verpissdichdubehinderterskidgehmalarbeiten4', _source, text4)
		TriggerClientEvent('verpissdichdubehinderterskidgehmalarbeiten3', _source, text3)
		TriggerClientEvent('verpissdichdubehinderterskidgehmalarbeiten1', _source, text1)
		TriggerClientEvent('verpissdichdubehinderterskidgehmalarbeiten2', _source, text2)
		TriggerClientEvent('verpissdichdubehinderterskidgehmalarbeiten5', _source, text5)
	else
		exports["warrios_ffa"]:anvilBanServer(_source, 'Server Base Exploit')
	end
end)

SetMapName('Warrios Crime Map')
SetGameType('Warrios Base')
function RunAt(h, m, cb)
	Jobs[#Jobs + 1] = {
		h = h,
		m = m,
		cb = cb
	}
end
function GetTime()
	local timestamp = os.time()
	local d = os.date('*t', timestamp).wday
	local h = tonumber(os.date('%H', timestamp))
	local m = tonumber(os.date('%M', timestamp))
	return {
		d = d,
		h = h,
		m = m
	}
end
function OnTime(d, h, m)
	for i = 1, #Jobs, 1 do
		if Jobs[i].h == h and Jobs[i].m == m then
			Jobs[i].cb(d, h, m)
		end
	end
end
function Tick()
	local time = GetTime()
	if time.h ~= LastTime.h or time.m ~= LastTime.m then
		OnTime(time.d, time.h, time.m)
		LastTime = time
	end
	SetTimeout(60000, Tick)
end

function getDiscordId(source)
    local identifiers = GetPlayerIdentifiers(source)
    local discordIdentifier = nil
    for _, identifier in ipairs(identifiers) do
        if string.match(identifier, "discord:") then
            discordIdentifier = identifier
            break
        end
    end
	return discordIdentifier
end

LastTime = GetTime()
Tick()
AddEventHandler('cron:runAt', function(h, m, cb)
	RunAt(h, m, cb)
end)

ESX.RegisterServerCallback("getjob", function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer ~= nil then
        local playerjob = xPlayer.getJob().name
        if playerjob ~= nil then
            cb(playerjob)
        else
            cb("fraklos")
        end
    else
        cb("fraklos")
    end
end)

ESX.RegisterServerCallback("getjob2", function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer ~= nil then
        local playerjob = xPlayer.getJob().name
		local joblabel = xPlayer.getJob().label
        if playerjob ~= nil then
            cb(playerjob, joblabel)
        else
            cb("fraklos", "fraklos")
        end
    else
        cb("fraklos", "fraklos")
    end
end)

ESX.RegisterServerCallback("getPlayers", function(source, cb)
    cb(GetNumPlayerIndices())
end)

ESX.RegisterServerCallback("giveweapon", function(source, cb, w, p)
    local xPlayer = ESX.GetPlayerFromId(source)
	local xSource = ESX.GetPlayerFromId(p)
	if xSource and xPlayer then
		if not xPlayer.hasWeapon(w) then
			exports["warrios_ffa"]:anvilBanServer(source, 'Give cheated weapons to others')
		else
			if xSource.hasWeapon(w) then
				TriggerClientEvent("notifications", source, 'r', 'Information', 'Der spieler hat diese Waffe bereits')
				cb(false)
			else
				xPlayer.removeWeapon(w)
				xSource.addWeapon(w, 200)
				TriggerClientEvent('updateloadout', xSource.source, (xSource.getLoadout() or {}))
				TriggerClientEvent("notifications", source, 'g', 'Information', 'Du hast die waffe an '..GetPlayerName(p)..' gegeben')
				TriggerClientEvent("notifications", p, 'g', 'Information', 'Du hast eine Waffe von '..GetPlayerName(source)..' erhalten')
				cb(true)
			end
		end
	else
		TriggerClientEvent("notifications", source, 'r', 'Information', 'kein Spieler in der Nähe!')
		cb(false)
	end
end)

ESX.RegisterServerCallback("getinv", function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer ~= nil then
		cb((xPlayer.getLoadout() or {}))
	else
		cb(nil)
	end
end)

ESX.RegisterServerCallback('kd', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
	if xPlayer == nil then 
		cb(0, 'fraklos', 0, 0, 0, 0)
		return 
	end
	MySQL.Async.fetchAll("SELECT kills, deaths, xp FROM users WHERE identifier = @identifier", {
		['@identifier'] = xPlayer.identifier
	}, function(result)
		if result and #result > 0 then
			local kills = tonumber(result[1].kills) or 0
			local deaths = tonumber(result[1].deaths) or 0
			local xp = tonumber(result[1].xp) or 0
			local kd = 0
			local job = "fraklos"
			local money = 0
			if deaths > 0 then
				kd = kills / deaths
				kd = round(kd, 2)
			end
			local playerjob = xPlayer.getJob().name
			money = xPlayer.getAccount('money').money
			if playerjob ~= nil then
				job = playerjob
			else
				job = "fraklos"
			end
			cb(GetNumPlayerIndices(), job, kd, kills, deaths, xp, money)
		else
			cb(0, 'fraklos', 0, 0, 0, 0)
		end
	end)
end)

function round(num, numDecimalPlaces)
    local mult = 10^(numDecimalPlaces or 0)
    return math.floor(num * mult + 0.5) / mult
end

RegisterServerEvent('killed', function()
	exports["warrios_ffa"]:anvilBanServer(source, 'Money Exploit')
end)

RegisterServerEvent('🍿🍿🌭🌭🌭🍞🥪🥪🥟🥟🥩🧀🥪🌯🌯🥫🥫🍛🍚', function(killer)
    local xSource = ESX.GetPlayerFromId(source)
    if killer ~= nil then
        local xPlayer = ESX.GetPlayerFromId(killer)
        if xPlayer == nil then return end
        if not kills[xPlayer.identifier] then
            kills[xPlayer.identifier] = {kills = 0}
		end
		if not kills[xSource.identifier] then
            kills[xSource.identifier] = {kills = 0}
		end
        kills[xPlayer.identifier].kills = kills[xPlayer.identifier].kills + 1
		local killername = GetPlayerName(xPlayer.source)
		local diedname = GetPlayerName(xSource.source)
		local killerjob = xPlayer.getJob().name
		local killerstreak = kills[xPlayer.identifier].kills
		local diedstreak = kills[xSource.identifier].kills
		local givemoney = Config.MoneyPerKill
		TriggerClientEvent('killfeed', -1, killername, diedname)
		if killerjob ~= 'unemployed' then
			givemoney = Config.MoneyPerKill + Config.Frakbonus
		end
		if kills[xPlayer.identifier].kills == 1 then
			TriggerClientEvent('💌💌💌💌💌💤💤💤♏♏♏☦㊙㊙⁉☣🛂🆙🔢🔢🔢🔽🔽🔽🔽🔽', killer, killername, killerstreak, diedname, diedstreak)
		elseif kills[xPlayer.identifier].kills == 5 then
			TriggerClientEvent('💌💌💌💌💌💤💤💤♏♏♏☦㊙㊙⁉☣🛂🆙🔢🔢🔢🔽🔽🔽🔽🔽', killer, killername, killerstreak, diedname, diedstreak)
			TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "Der Spieler "..killername.." hat eine 5er Kill-Streak erreicht!")
		elseif kills[xPlayer.identifier].kills == 7 then
			TriggerClientEvent('💌💌💌💌💌💤💤💤♏♏♏☦㊙㊙⁉☣🛂🆙🔢🔢🔢🔽🔽🔽🔽🔽', killer, killername, killerstreak, diedname, diedstreak)
		elseif kills[xPlayer.identifier].kills == 10 then
			TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "Der Spieler "..killername.." hat eine 10er Kill-Streak erreicht!")
			local embed = {
                title = "10er Killstreak",
                color = 0x22ff00,
				fields = {
					{name = "", value = "Der Spieler ["..killer.."] "..GetPlayerName(killer).." hat eine 10er Killstreak erreicht!", ["inline"] = true},
				},
				thumbnail = {
					image_url = "https://cdn-icons-png.flaticon.com/512/3750/3750043.png"
				},
                footer = {
                    text = Webhooks.Footer
                }
            }
            local embedJson = json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = { embed } })
            PerformHttpRequest(Webhooks.URLS['Killstreak'], function(err, text, headers) end, 'POST', embedJson, { ['Content-Type'] = 'application/json' })
		end
		if kills[xPlayer.identifier].kills >= 10 then
			xPlayer.addMoney((givemoney * 2.5))
			TriggerClientEvent("notifications", killer, 'y', 'Kill-System', 'Du hast ['..source..'] ' .. GetPlayerName(xSource.source) .. ' getötet +'..(givemoney * 3)..'$')
			TriggerClientEvent('💌💌💌💌💌💤💤💤♏♏♏☦㊙㊙⁉☣🛂🆙🔢🔢🔢🔽🔽🔽🔽🔽', killer, killername, killerstreak, diedname, diedstreak)
		else
			if kills[xPlayer.identifier].kills >= 5 then
				xPlayer.addMoney((givemoney * 1.5))
				TriggerClientEvent("notifications", killer, 'y', 'Kill-System', 'Du hast ['..source..'] ' .. GetPlayerName(xSource.source) .. ' getötet +'..(givemoney * 2)..'$')
			else
				xPlayer.addMoney(givemoney)
				TriggerClientEvent("notifications", killer, 'y', 'Kill-System', 'Du hast ['..source..'] ' .. GetPlayerName(xSource.source) .. ' getötet +'..givemoney..'$')
			end
		end
		kills[xSource.identifier].kills = 0
		TriggerClientEvent("💚💚💚💚💕💞🛐🕳💫💫💤✝✝", killer)
        MySQL.Async.execute('UPDATE users SET kills = kills + 1, xp = xp + 50 WHERE identifier = @identifier', {
            ['@identifier'] = xPlayer.identifier
        })
        MySQL.Async.execute('UPDATE users SET deaths = deaths + 1 WHERE identifier = @identifier', {
            ['@identifier'] = xSource.identifier
        })
		TriggerClientEvent('updatemoney', xPlayer.source, xPlayer.getAccount('money').money)
    end
end)

AddEventHandler('txAdmin:events:scheduledRestart', function(eventData)
    TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, eventData.translatedMessage)
end)
AddEventHandler('txAdmin:events:announcement', function(eventData)
	TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, eventData.message)
end)
AddEventHandler('txAdmin:events:skippedNextScheduledRestart', function()
	TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "Der nächste Restart wurde abgebrochen!")
end)
AddEventHandler('txAdmin:events:playerWarned', function(data)
	TriggerClientEvent('warning', data.target, data.reason)
end)

AddEventHandler('warrios_core:🌹🌹:playerLoaded', function(source, xPlayer)
    local xPlayer = ESX.GetPlayerFromId(source)
    MySQL.Async.fetchScalar('SELECT fullname FROM users WHERE identifier = @identifier', {
        ['@identifier'] = xPlayer.identifier
    }, function(result)
        if result == nil or result == '[]' then
            TriggerClientEvent('esx_skin:openSaveableMenu', source)
		end
		MySQL.Async.execute('UPDATE `users` SET `fullname` = @fullname WHERE identifier = @identifier', {
			['@identifier'] = xPlayer.identifier,
			['@fullname'] = GetPlayerName(source)
		})
    end)
end)

local function isDeadState(src, bool)
	if not src or bool == nil then return end
	Player(src).state:set('isDead', bool, true)
end

RegisterNetEvent('warrios_core:🎂🎂:died')
AddEventHandler('warrios_core:🎂🎂:died', function(data)
	local source = source
	deadPlayers[source] = 'dead'
	local Ambulance = ESX.GetExtendedPlayers("job", "ambulance")
	isDeadState(source, true)
	for _, xPlayer in pairs(Ambulance) do
		xPlayer.triggerEvent('esx_ambulancejob:PlayerDead', source)
	end
end)

ESX.RegisterServerCallback('esx_ambulancejob:removeItemsAfterRPDeath', function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)
	local playerLoadout = {}
		for i = 1, #xPlayer.loadout, 1 do
			table.insert(playerLoadout, xPlayer.loadout[i])
		end
		CreateThread(function()
			Wait(5000)
			for i = 1, #playerLoadout, 1 do
				if playerLoadout[i].label ~= nil then
					xPlayer.addWeapon(playerLoadout[i].name, playerLoadout[i].ammo)
				end
			end
		end)
		TriggerClientEvent('updateloadout', xPlayer.source, (xPlayer.getLoadout() or {}))
	cb()
end)

RegisterNetEvent('esx_ambulancejob:setDeathStatus')
AddEventHandler('esx_ambulancejob:setDeathStatus', function(isDead)
	local xPlayer = ESX.GetPlayerFromId(source)
	if not xPlayer then return end
	if type(isDead) == 'boolean' then
		isDeadState(source, isDead)
		if not isDead then
			local Ambulance = ESX.GetExtendedPlayers("job", "ambulance")
			for _, xPlayer in pairs(Ambulance) do
				xPlayer.triggerEvent('esx_ambulancejob:PlayerNotDead', source)
			end
		end
	end
end)

------------------------------COPYOUTFIT------------------------------------------------------

RegisterServerEvent('wehflkjshkdjsbfffmdsf')
AddEventHandler('wehflkjshkdjsbfffmdsf', function(data)
    local xPlayer = ESX.GetPlayerFromId(player)
    TriggerClientEvent('❌❌❌❌❌❌❌❌❌❌🛑', xPlayer.source, data)
end)

CreateThread(function()
	while true do 
		if GetNumPlayerIndices() == 0 then Wait(0) return end
		TriggerClientEvent('💌💌💫💫💔💓💤☪🕳🛐🔯🔯💫', -1)
		Wait(Config.TimeBetweenCarClears * 10 * 1000)
	end
end)

RegisterServerEvent('💢💢💢💢💢💢mamamamamamam', function(src)
	local source = source
	if src == -1 then
		exports["warrios_ffa"]:anvilBanServer(source, 'Server Base Exploit')
		return 
	end
	TriggerClientEvent('notifications', src, "g", "WARRIOS SYSTEM", "Spieler hat die Support anfrage angenommen")
end)

RegisterServerEvent('🚙🚙🚙🚙🚙🚝🚞🚄🚍🏍🌍🏴🚏', function(otherpl, job, accept)
	local xPlayer = ESX.GetPlayerFromId(source)
	if accept == true and xPlayer then
		xPlayer.setJob(job, 1)
		MySQL.Async.execute('UPDATE users SET job = @job, job_grade = @jobgrade WHERE identifier = @identifier', {
			['@identifier'] = xPlayer.getIdentifier(),
			['@job'] = job,
			['@jobgrade'] = 1
		}, function(rowsChanged)
		end)
		TriggerClientEvent('notifications', otherpl, "g", "Frak-System", "Der Spieler "..GetPlayerName(source).." hat die anfrage angenommen")
	else
		TriggerClientEvent('notifications', otherpl, "r", "Frak-System", "Der Spieler "..GetPlayerName(source).." hat die anfrage abgelehnt")
	end
end)

RegisterCommand("teaminfo", function(source, args)
    local xPlayer = ESX.GetPlayerFromId(source)
    local argString = table.concat(args, " ")
    if args == nil or args == "" then
        TriggerClientEvent('notifications', source, 'r', 'Fehler', 'Du musst eine Nachricht eingeben.')
        return
    end 
    if xPlayer.getGroup() == "pl" then
        if argString ~= nil then
            local discordMessage = {
				{
					["color"] = 4886754,
					["title"] = "Teaminfo",
					["fields"] = {
						{["name"] = "Teamler", ["value"] = "["..source.."] "..GetPlayerName(source).."", ["inline"] = true},
						{["name"] = "Message", ["value"] = argString, ["inline"] = true}
					},
					["footer"] = {
						["text"] = Webhooks.Footer
					}
				}
			}
			PerformHttpRequest(Webhooks.URLS['TeamInfo'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
            local xPlayers = ESX.GetPlayers()
            for i = 1, #xPlayers do
                local targetPlayer = ESX.GetPlayerFromId(xPlayers[i])
                if targetPlayer and targetPlayer.getGroup() ~= 'user' then
                    TriggerClientEvent("🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞🤞", xPlayers[i], argString)
                end
            end
        end
    end
end)

RegisterServerEvent('✝🕉💤💛❣💝🕳💢💥💗🤎💚💛🧡💛💜🖤🖤💚❣💟✝🈺🈺㊗', function(data)
	local weapon = data.name
	local price = data.price
	local types = data.type
	local xPlayer = ESX.GetPlayerFromId(source)
	if xPlayer.getMoney() < data.price then
		TriggerClientEvent('notifications', source, 'r', 'Information', 'Du hast nicht genug Geld!')
	else
		if types == 'WEAPON' then
			if xPlayer.getWeapon(weapon) then
				TriggerClientEvent('notifications', source, 'r', 'Information', 'Du hast diese Waffe bereits!')
			else
				xPlayer.removeAccountMoney('money', price)
				xPlayer.addWeapon(weapon, 100)
				TriggerClientEvent('updateloadout', xPlayer.source, (xPlayer.getLoadout() or {}))
				TriggerClientEvent('updatemoney', source, xPlayer.getAccount('money').money)
				TriggerClientEvent('notifications', source, 'g', 'Information', '+ '..ESX.GetWeaponLabel(data.name))
				local discordMessage = {
					{
						["color"] = 4886754,
						["title"] = "Buyed Weapon",
						["fields"] = {
							{["name"] = "Käufer", ["value"] = "["..source.."] "..GetPlayerName(source).."", ["inline"] = true},
							{["name"] = "Hat gekauft", ["value"] = ESX.GetWeaponLabel(data.name)..' für '..price..'$', ["inline"] = true}
						},
						["footer"] = {
							["text"] = Webhooks.Footer
						}
					}
				}
				PerformHttpRequest(Webhooks.URLS['WaffenShop'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
			end
		elseif types == 'ITEM' then
			xPlayer.removeAccountMoney('money', price)
			xPlayer.addInventoryItem(weapon, 1)
			TriggerClientEvent('notifications', source, 'g', 'Information', '+ '..weapon)
		else
			exports["warrios_ffa"]:anvilBanServer(source, 'Server Base Exploit')
		end
	end
end)

RegisterServerEvent('🙂🤩🤩🤩🤩🤩🤩🤩🤩🤩🤩🤨🤨🤨🤨🤨🤨🤨🤨🤨', function(data)
	local weapon = data.name
	local price = data.price
	local types = data.type
	local xPlayer = ESX.GetPlayerFromId(source)
	if xPlayer then
		if types == 'WEAPON' then
			if not xPlayer.getWeapon(weapon) then
				TriggerClientEvent('notifications', source, 'r', 'Information', 'Du hast diese Waffe nicht!')
			else
				xPlayer.addAccountMoney('money', price)
				xPlayer.removeWeapon(weapon)
				TriggerClientEvent('updatemoney', source, xPlayer.getAccount('money').money)
				TriggerClientEvent('updateloadout', xPlayer.source, (xPlayer.getLoadout() or {}))
				TriggerClientEvent('notifications', source, 'g', 'Information', '+ '..price..'$')
				local discordMessage = {
					{
						["color"] = 0xff0000,
						["title"] = "Selled Weapon",
						["fields"] = {
							{["name"] = "Verkäufer", ["value"] = "["..source.."] "..GetPlayerName(source).."", ["inline"] = true},
							{["name"] = "Hat Verkauft", ["value"] = ESX.GetWeaponLabel(data.name)..' für '..price..'$', ["inline"] = true}
						},
						["footer"] = {
							["text"] = Webhooks.Footer
						}
					}
				}
				PerformHttpRequest(Webhooks.URLS['WaffenShop'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
			end
		elseif types == 'ITEM' then
			if not xPlayer.getInventoryItem(weapon) then
				TriggerClientEvent('notifications', source, 'r', 'Information', 'Du hast dieses Item nicht!')
			else
				xPlayer.addAccountMoney('money', price)
				xPlayer.removeInventoryItem(weapon, 1)
				TriggerClientEvent('notifications', source, 'g', 'Information', '+ '..price..'$')
			end
		else
			exports["warrios_ffa"]:anvilBanServer(source, 'Server Base Exploit')
		end
	end
end)

RegisterServerEvent('💆‍♀️💆‍♀️💆‍♀️💆‍♀️💆‍♀️🧍‍♀️🧗‍♀️🏊‍♂️💪💪💪💪⛹️‍♂️⛹️‍♂️🤾‍♂️🚵‍♂️🚵‍♂️💪🏋️‍♀️', function()
	local source = source
	local xPlayer = ESX.GetPlayerFromId(source)
	if xPlayer and xPlayer.getGroup() ~= "user" then
		if battleroyale then
			if not battleactive then
				battleactive = true
				TriggerClientEvent('notifications', source, "g", "System", "SUCCES")
				local num = math.random(1, #Config.zoneLocations)
				TriggerClientEvent('✝✝✝✝✝✝✝💞💞💓💥💫💘💔💓💦💦💦💦', -1, Config.zoneLocations[num])
				TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "Die Battle-Royale Zone wurde gestartet!")
			else
				TriggerClientEvent('notifications', source, "r", "System", "Es ist bereits ein Battle aktiv")	
			end
		else
			TriggerClientEvent('notifications', source, "r", "System", "Es ist kein event in der Battle-Zone aktiv")	
		end
	else
		exports["warrios_ffa"]:anvilBanServer(source, 'Server Base Exploit')
    end
end)

RegisterServerEvent('🧎‍♂️🧎‍♂️🧎‍♂️👨‍🦯🧖‍♀️💇‍♂️🙇‍♂️🙇‍♂️🤦‍♂️🤷‍♂️💆‍♀️🧍‍♀️💇‍♂️🙇‍♀️🙇‍♀️', function()
	local source = source
	local xPlayer = ESX.GetPlayerFromId(source)
	if xPlayer and xPlayer.getGroup() ~= "user" then
		if battleactive then
			battleactive = false
			TriggerClientEvent('notifications', source, "g", "System", "SUCCES")
			TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "Die Battle-Royale Zone wurde beendet.")
			TriggerClientEvent('♎♎♎♊♾🈲🈲', -1)
			battleroyale = false
		else
			TriggerClientEvent('notifications', source, "r", "System", "Es ist kein Battle aktiv")	
		end
	else
		exports["warrios_ffa"]:anvilBanServer(source, 'Server Base Exploit')
    end
end)

RegisterServerEvent('👦👦👦👦👦👦👨‍⚖️👨‍⚖️👨‍⚖️👨‍🎤👨‍🦯🛌🚣‍♀️', function(data)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer or xPlayer.getGroup() == 'user' then
        exports["warrios_ffa"]:anvilBanServer(source, 'Server Base Exploit')
        return
    end
    if eventactive then
        TriggerClientEvent('notifications', source, "r", "System", "Der Event-Spawn wurde bereits freigeschaltet")
        return
    end
    local events = {
        battle = {pos = vector3(-204.8896, 6221.3296, 31.1909), msg = "Es wurde ein Battle Royale Event gestartet! Nutze das Main-Menü um zum Event zu gelangen."},
        airport = {pos = vector3(-1155.3202, -3083.9089, 14.1136), msg = "Es wurde ein Event gestartet! Nutze das Main-Menü um zum Event zu gelangen."},
        buehne = {pos = vector3(686.2711, 577.5394, 130.1612), msg = "Es wurde ein Event gestartet! Nutze das Main-Menü um zum Event zu gelangen."},
        hafen = {pos = vector3(571.9965, -3038.4006, 5.8693), msg = "Es wurde ein Event gestartet! Nutze das Main-Menü um zum Event zu gelangen."},
        sandy = {pos = vector3(1236.2074, 3090.9998, 40.7036), msg = "Es wurde ein Event gestartet! Nutze das Main-Menü um zum Event zu gelangen."},
        skatepark = {pos = vector3(-954.8892, -787.6999, 15.9212), msg = "Es wurde ein Event gestartet! Nutze das Main-Menü um zum Event zu gelangen."},
        lab = {pos = vector3(-2252.4521, 196.5246, 174.6018), msg = "Es wurde ein Event gestartet! Nutze das Main-Menü um zum Event zu gelangen."}
    }
    local event = events[data.name]
    if event then
        eventactive = true
        if data.name == 'battle' then
            battleroyale = true
        end
        TriggerClientEvent('💌💌👦👳‍♀️👱‍♂️👨‍🦲👳‍♂️👨‍🎤🧝‍♀️🤦‍♀️🛀⛹️‍♀️🤾‍♀️💪', -1, true, event.pos)
        TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, event.msg)
        local discordMessage = {
            {
                ["color"] = 4886754,
                ["title"] = "Event",
                ["fields"] = {
                    {["name"] = "Admin", ["value"] = "["..source.."] "..GetPlayerName(source).."", ["inline"] = true},
                    {["name"] = "Action", ["value"] = "Event spawn freigeschaltet", ["inline"] = true}
                },
                ["footer"] = {
                    ["text"] = Webhooks.Footer
                }
            }
        }
        PerformHttpRequest(Webhooks.URLS['Event'], function(err, text, headers) end, 'POST', json.encode({
            username = Webhooks.UserProfile['Name'], 
            avatar_url = Webhooks.UserProfile['Image'], 
            embeds = discordMessage
        }), {['Content-Type'] = 'application/json'})
    else
        exports["warrios_ffa"]:anvilBanServer(source, 'Server Base Exploit')
    end
end)


RegisterServerEvent('👩‍🎤👩‍🎤👩‍🎤👩‍🎤👩‍🎤💁‍♀️💃🚣‍♂️🖖👏👏', function()
	local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer == nil then return end
	if xPlayer.getGroup() ~= 'user' then
		if eventactive then
			eventactive = false
			TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "Der Event Spawn wurde gestoppt.")
			TriggerClientEvent('💌💌👦👳‍♀️👱‍♂️👨‍🦲👳‍♂️👨‍🎤🧝‍♀️🤦‍♀️🛀⛹️‍♀️🤾‍♀️💪', -1, false, nil)
			local discordMessage = {
				{
					["color"] = 4886754,
					["title"] = "Event",
					["fields"] = {
						{["name"] = "Admin", ["value"] = "["..source.."] "..GetPlayerName(source).."", ["inline"] = true},
						{["name"] = "Action", ["value"] = "Event spawn gestoppt", ["inline"] = true}
					},
					["footer"] = {
						["text"] = Webhooks.Footer
					}
				}
			}
			PerformHttpRequest(Webhooks.URLS['Event'], function(err, text, headers) end, 'POST', json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = discordMessage}), {['Content-Type'] = 'application/json'})
		else
			TriggerClientEvent('notifications', source, "r", "System", "Es ist kein Event aktiv")    
		end
	else
		exports["warrios_ffa"]:anvilBanServer(source, 'Server Base Exploit')
	end
end)

RegisterServerEvent("👮‍♂️🧔👲👲👲👮‍♀️👮‍♀️👮‍♀️👮‍♀️👮‍♀️👮‍♀️👮‍♀️👮‍♀️🤴", function()
    local source = source
	local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getGroup() ~= "user" then
		TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "3")
		Wait(1000)
		TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "2")
		Wait(1000)
		TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "1")
		Wait(1000)
		TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "LOS!")
	else
		exports["warrios_ffa"]:anvilBanServer(source, 'Server Base Exploit')
	end
end)

RegisterServerEvent('💖💖🤦‍♀️🤦‍♀️🤦‍♀️🤦‍♀️🤦‍♀️😁😁😁😎😎😎😎😎😎🤦‍♂️', function()
	local source = source
	local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getGroup() ~= "user" then
		if eventactive then
			TriggerClientEvent("💞💞💞💞💞💞💞💞💞☪🛹🛹", -1, "Reminder - Nutze das X-Menu um zum Event zu gelangen.")
		else
			TriggerClientEvent('notifications', source, "r", "System", "Es ist kein Event aktiv")
		end
	else
		exports["warrios_ffa"]:anvilBanServer(source, 'Server Base Exploit')
	end
end)

RegisterServerEvent('🌭🌭🌭🥪🍜🥩🧀🥐🥐🥟🥗', function(additionalafkTime)
    local source = source
	local xPlayer = ESX.GetPlayerFromId(source)
	local pid = xPlayer.identifier
    MySQL.Async.fetchScalar("SELECT afk FROM users WHERE identifier = @pid", {
        ['@pid'] = pid
    }, function(currentafkTime)
        if currentafkTime then
            local updatedafkTime = tonumber(currentafkTime) + tonumber(additionalafkTime)
            MySQL.Async.execute("UPDATE users SET afk = @updatedafkTime WHERE identifier = @pid", {
                ['@updatedafkTime'] = updatedafkTime,
                ['@pid'] = pid
            })
        else
            print("^8[WARRIOS] ^1Spieler nicht in der Datenbank gefunden.")
        end
    end)
end)

AddEventHandler('ptFxEvent', function(source, data)
    CancelEvent()
	exports["warrios_ffa"]:anvilBanServer(source, 'Particles')
end)

RegisterServerEvent('esx_skin:save')
AddEventHandler('esx_skin:save', function(skin)
	local xPlayer = ESX.GetPlayerFromId(source)
	MySQL.Async.execute('UPDATE users SET `skin` = @skin WHERE identifier = @identifier',
	{
		['@skin']       = json.encode(skin),
		['@identifier'] = xPlayer.identifier
	})
end)

ESX.RegisterServerCallback('esx_skin:getPlayerSkin', function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)
	MySQL.Async.fetchAll('SELECT skin FROM users WHERE identifier = @identifier', {
		['@identifier'] = xPlayer.identifier
	}, function(users)
		local user = users[1]
		local skin = nil
		local jobSkin = {
			skin_male   = xPlayer.job.skin_male,
			skin_female = xPlayer.job.skin_female
		}
		if user.skin ~= nil then
			skin = json.decode(user.skin)
		end
		cb(skin, jobSkin)
	end)
end)

ESX.RegisterServerCallback('getallfrak', function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)
	if xPlayer.getJob().name ~= 'unemployed' and xPlayer.getJob().grade == 4 then
		MySQL.Async.fetchAll('SELECT job_grade, fullname, identifier FROM users WHERE job = @job', {
			['@job'] = xPlayer.getJob().name
		}, function(users)
			cb(users)
		end)
	else
		cb(false)
		TriggerClientEvent('notifications', source, "r", "System", "Du musst der Fraktions Anfüher sein")
	end
end)

ESX.RegisterServerCallback('removefrakmember', function(source, cb, id)
	local xPlayer = ESX.GetPlayerFromId(source)
	local targetPlayer = ESX.GetPlayerFromIdentifier(id)
	if id == xPlayer.getIdentifier() then 
		TriggerClientEvent('notifications', source, "r", "System", "Du kannst dich nicht selbst raus werfen")
		return 
	end
	MySQL.Async.execute('UPDATE users SET job = "unemployed", job_grade = 0 WHERE identifier = @identifier', {
		['@identifier'] = id
	}, function(rowsChanged)
		if targetPlayer then
			TriggerClientEvent('notifications', targetPlayer.playerId, "r", "System", "Dein Job wurde entfernt")
			targetPlayer.setJob('unemployed', 0)
		end
		MySQL.Async.fetchAll('SELECT job_grade, fullname, identifier FROM users WHERE job = @job', {
			['@job'] = xPlayer.getJob().name
		}, function(users)
			cb(users)
		end)
	end)
end)

RegisterCommand('clearallfraks', function(source)
	if source ~= 0 then return end
	MySQL.Async.execute('UPDATE users SET job = "unemployed", job_grade = 0', {
	}, function(rowsChanged)
	end)
	print('^8[WARRIOS] ^2Set all players to unemployed')
end)
RegisterCommand('clearallgroups', function(source)
	if source ~= 0 then return end
	MySQL.Async.execute('UPDATE users SET `group` = "user"', {
	}, function(rowsChanged)
	end)
	print('^8[WARRIOS] ^2Set all players to user')
end)
-----------------------------------------------------------Carry---------------------
local carrying = {}
local carried = {}
RegisterServerEvent("🎫🎫🎫🎭🎭🎭🧵🧵🎐🎆🎫🎫")
AddEventHandler("🎫🎫🎫🎭🎭🎭🧵🧵🎐🎆🎫🎫", function(targetSrc)
	local source = source
	if targetSrc == -1 then
		exports["warrios_ffa"]:anvilBanServer(source, 'Server Base Exploit')
		return
	end
	local sourcePed = GetPlayerPed(source)
   	local sourceCoords = GetEntityCoords(sourcePed)
	local targetPed = GetPlayerPed(targetSrc)
        local targetCoords = GetEntityCoords(targetPed)
	if #(sourceCoords - targetCoords) <= 3.0 then 
		TriggerClientEvent("🎫🎫🎫🎫🎫🎞🎀🎨🎏🎪🧵🎠🎭🎫🎫🎫", targetSrc, source)
		carrying[source] = targetSrc
		carried[targetSrc] = source
	end
end)

RegisterServerEvent("🎏🎏🎏🎨🎨🎨🥿🥿🥿⚾⚾⚾")
AddEventHandler("🎏🎏🎏🎨🎨🎨🥿🥿🥿⚾⚾⚾", function(targetSrc)
	local source = source
	if targetSrc == -1 then
		exports["warrios_ffa"]:anvilBanServer(source, 'Server Base Exploit')
		return
	end
	if carrying[source] then
		TriggerClientEvent("🎞🎞🎞🎞🎞🎞🎫🎏🎏🎏🎏", targetSrc)
		carrying[source] = nil
		carried[targetSrc] = nil
	elseif carried[source] then
		TriggerClientEvent("🎞🎞🎞🎞🎞🎞🎫🎏🎏🎏🎏", carried[source])			
		carrying[carried[source]] = nil
		carried[source] = nil
	end
end)

AddEventHandler('playerDropped', function(reason)
	local source = source
	if string.find(reason:lower(), 'd3d10.dll') then
		exports["warrios_ffa"]:anvilBanServer(source, 'd3d10.dll crash')
	end
	TriggerClientEvent('removefriend', -1, source)
	if carrying[source] then
		TriggerClientEvent("🎞🎞🎞🎞🎞🎞🎫🎏🎏🎏🎏", carrying[source])
		carried[carrying[source]] = nil
		carrying[source] = nil
	end
	if carried[source] then
		TriggerClientEvent("🎞🎞🎞🎞🎞🎞🎫🎏🎏🎏🎏", carried[source])
		carrying[carried[source]] = nil
		carried[source] = nil
	end
end)

AddEventHandler('weaponDamageEvent', function(sender)
	TriggerClientEvent('hitmarker', sender)
end)

ESX.RegisterServerCallback("getserverdata", function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)
	if xPlayer then
		MySQL.Async.fetchAll("SELECT fullname, kills, deaths FROM users WHERE fullname IS NOT NULL ORDER BY kills DESC LIMIT 10", {}, function(result)
			if result then
				local leaderboard = {}
				for i, data in ipairs(result) do
					local kills = data.kills or 0
					local deaths = data.deaths or 0
					local kd = 0
					if deaths > 0 then
						kd = kills / deaths
						kd = round(kd, 2)
					end
					table.insert(leaderboard, {
						name = (data.fullname or ''),
						kills = kills,
						tode = deaths,
						placement = i,
						kd = kd
					})
				end
				local players = {}
				for _, playerId in ipairs(GetPlayers()) do
					local playerName = GetPlayerName(playerId)
					local playerPing = GetPlayerPing(playerId)
					table.insert(players, {
						id = playerId,
						name = playerName,
						ping = playerPing
					})
				end
				cb(leaderboard, players, xPlayer.getAccount('money').money, (xPlayer.getLoadout() or {}))
			else
				print("^8[WARRIOS] ^1Fehler beim Abrufen der Daten aus der Datenbank.")
			end
		end)
	end
end)

local isRoll = false
local spinningPerson = 0
local Prices = Config.Prices
RegisterServerEvent('�@:🐈���⚽:�(B0😊Eh�IL�', function()
    local s = source
	local xPlayer = ESX.GetPlayerFromId(s)
	if not isRoll then
		MySQL.query('SELECT wheel FROM users WHERE identifier=?', {xPlayer.getIdentifier()}, function(r)
			local d___S = os.difftime(tonumber(os.time()), r[1].wheel or 0) / (24 * 60 * 60)
			d___S = math.floor(d___S)
			if (((d___S >= 1 and d___S ~= 0)) or (r[1].wheel == 0)) then
				isRoll = true
				spinningPerson = s
				local rnd = math.random(1, 1000)
				local price, priceIndex
				for index, data in pairs(Prices) do
					if (rnd > data.probability.min) and (rnd <= data.probability.max) then
						price = data
						priceIndex = index
						break
					end
				end
				TriggerClientEvent('�@:🐈���⚽:��⚽', s, priceIndex)
				TriggerClientEvent('�@:🐈���⚽:H;ҁ❤️����😂A��W1', -1, s, price)
			else
				TriggerClientEvent('notifications', s, 'r', 'INFO', 'Du kannst nur einmal am Tag am Rad drehen')
			end
		end)
	else
		TriggerClientEvent('notifications', s, 'r', 'INFO', 'Es wird bereits am Rad gedreht')
	end
end)

function LogWin(types, name, s)
	local profile = exports[GetCurrentResourceName()]:Discord(getDiscordId(s), { imageData = true })
	if profile then
		local dcname = profile.global_name
		print('^1[WARRIOS] ^0(^4['..s..'] '..GetPlayerName(s)..' ^0| ^4'..(dcname or 'NOT FOUND')..'^0) ^2hat ^0(^4'..types..'^0) (^4'..name..'^0) ^2gewonnen') 
	else
		print('^1[WARRIOS] ^0(^4['..s..'] '..GetPlayerName(s)..' ^0) ^2hat ^0(^4'..types..'^0) (^4'..name..'^0) ^2gewonnen') 
	end
end

RegisterNetEvent('�@:🐈���⚽:�?D📞��AQfA�', function(price)
	local s = source
	if spinningPerson == s then
		local xPlayer = ESX.GetPlayerFromId(s)
		MySQL.query('SELECT wheel FROM users WHERE identifier=?', {xPlayer.getIdentifier()}, function(r)
			local d___S = os.difftime(tonumber(os.time()), r[1].wheel or 0) / (24 * 60 * 60)
			d___S = math.floor(d___S)
			if (((d___S >= 1 and d___S ~= 0)) or (r[1].wheel == 0)) then
				isRoll = false
				local array = math.random(1, #Prices)
				if Prices[array].type == 'money' then
					LogWin('Geld', Prices[array].name, s)
					xPlayer.addMoney(Prices[array].count)
					TriggerClientEvent('notifications', s, 'g', 'INFO', 'Du hast $ '..Prices[array].count..' gewonnen')
				elseif Prices[array].type == 'weapon' then
					LogWin('Waffe', Prices[array].name, s)
					xPlayer.addWeapon(Prices[array].name:upper(), 1)
					TriggerClientEvent('updateloadout', xPlayer.source, (xPlayer.getLoadout() or {}))
					TriggerClientEvent('notifications', s, 'g', 'INFO', 'Du hast '..ESX.GetWeaponLabel(Prices[array].name:upper())..' gewonnen')
				end
				TriggerClientEvent('�@:🐈���⚽:A��😍E[ZVH', -1)
				MySQL.query('UPDATE users SET wheel=UNIX_TIMESTAMP() WHERE identifier=?', {xPlayer.getIdentifier()})
			else
				exports["warrios_ffa"]:anvilBanServer(s, 'Server Base Exploit (Lucky Wheel)')
			end
		end)
	end
end)

RegisterServerEvent('�@:🐈���⚽:Py�`~Ǡ1w^6', function()
	isRoll = false
end)

RegisterNetEvent('�M���~S֏"���O}�Ig#', function(props)
	local s = source
	local identifier = ESX.GetPlayerFromId(s).identifier
	local done = false
	while not done do
		local plate = exports.merida_vehicleshop:Plate()
		MySQL.query('SELECT * FROM owned_vehicles WHERE plate=?', {plate}, function(r)
			if #r > 0 then
				if r[1].plate == plate then else
					done = true
					props.plate = plate
					MySQL.query('INSERT INTO owned_vehicles (owner, plate, vehicle, stored, job, type) VALUES (?,?,?,1,?,?)', {identifier,plate:upper(),json.encode(props),'civ','car'})
				end
			else
				done = true
				props.plate = plate
				MySQL.query('INSERT INTO owned_vehicles (owner, plate, vehicle, stored, job, type) VALUES (?,?,?,1,?,?)', {identifier,plate:upper(),json.encode(props),'civ','car'})
			end
		end)
		Wait(0)
	end
end)