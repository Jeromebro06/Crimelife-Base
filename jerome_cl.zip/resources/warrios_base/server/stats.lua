RegisterCommand('times', function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer then
        local group = xPlayer.getGroup()
        if group == 'pl' then
            sendtopafk()
            sendTopKills()
            sendgw()
        else
            TriggerClientEvent('notifications', source, "r", "WARRIOS SYSTEM", "Keine Rechte")
        end
    else
        sendtopafk()
        sendTopKills()
        sendgw()
    end
end)

CreateThread(function()
    while true do
		local currentTime = os.date("*t")
		if (currentTime.hour == 15 or currentTime.hour == 22 or currentTime.hour == 10) and currentTime.min == 0 then
			sendtopafk()
            Wait(1000)
			sendTopKills()
            Wait(1000)
            Wait(1000)
            sendgw()
		end
		Wait(60 * 1000)
    end
end)

function formatMinutes(minutes)
    if minutes < 60 then
        return "``"..minutes.."`` Minuten"
    else
        local hours = math.floor(minutes / 60)
        local remainingMinutes = minutes % 60
        if hours == 01 then
            return string.format("``%02d`` Stunde und ``%02d`` Minuten", hours, remainingMinutes)
        else
            return string.format("``%02d`` Stunden und ``%02d`` Minuten", hours, remainingMinutes)
        end
    end
end

function sendtopafk()
	MySQL.Async.fetchAll("SELECT fullname, afk FROM users ORDER BY afk DESC LIMIT 5", {}, function(result)
		if result then
			local embedFields = {}
			for i, data in ipairs(result) do
                local placement = i
                local playerName = (data.fullname or '')
                local afkTime = data.afk or 0
                local e = {'🥇','🥈','🥉','🏅','🏅'}
                table.insert(embedFields, {
                    name = e[i]..' '..placement .. '. ' .. playerName,
                    value = formatMinutes(math.floor(tostring(afkTime)/60)),
                    inline = false
                })
            end
			local embed = {
				title = "Top 5 Spieler mit höchster AFK-Zeit",
				color = 16711680,
				fields = embedFields,
                thumbnail = {
                    url = "https://cdn-icons-png.flaticon.com/512/12178/12178375.png"
                },
				footer = {
					text = Webhooks.Footer
				}
			}
			local embedJson = json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = {embed}})
			PerformHttpRequest(Webhooks.URLS['TopAfk'], function(err, text, headers) end, 'POST', embedJson, {['Content-Type'] = 'application/json'})
		else
			print("^8[WARRIOS] ^1Fehler beim Abrufen der Daten aus der Datenbank.")
		end
	end)
end


function sendTopKills()
    MySQL.Async.fetchAll("SELECT fullname, kills, deaths FROM users ORDER BY kills DESC LIMIT 5", {}, function(result)
        if result then
            local embedFields = {}
            for i, data in ipairs(result) do
                local playerName = (data.fullname or '')
                local kills = data.kills or 0
                local deaths = data.deaths or 0
                local placement = i
                local e = {'🥇','🥈','🥉','🏅','🏅'}
                table.insert(embedFields, {
                    name = e[i]..' '..placement .. '. ' .. playerName,
                    value = '``'..tostring(kills)..'`` Kills und ``'..tostring(deaths)..'`` Tode',
                    inline = false
                })
            end
            local embed = {
                title = "Top 5 Spieler mit den meisten Kills",
                color = 16711680,
                fields = embedFields,
                thumbnail = {
                    url = "https://cdn-icons-png.flaticon.com/512/12178/12178375.png"
                },
                footer = {
                    text = Webhooks.Footer
                }
            }
            local embedJson = json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = { embed } })
            PerformHttpRequest(Webhooks.URLS['TopKills'], function(err, text, headers) end, 'POST', embedJson, { ['Content-Type'] = 'application/json' })
        else
            print("^8[WARRIOS] ^1Fehler beim Abrufen der Daten aus der Datenbank.")
        end
    end)
end

function sendgw()
    MySQL.Async.fetchAll("SELECT owner, zone FROM gwzones WHERE owner IS NOT NULL", {}, function(results)
        if results and #results > 0 then
            local houseOwners = {}
            for _, h in ipairs(results) do
                table.insert(houseOwners, {
                    name = Config.GWpoint.zones[h.zone].name..' Zone',
                    value = 'gehört der Fraktion ``'..tostring(Config.fraks[h.owner].label)..'``',
                    inline = false
                })
            end
            local embed = {
                title = "Gangwar Zonen Besitzer",
                color = 16711680,
                fields = houseOwners,
                thumbnail = {
                    url = "https://cdn3.iconfinder.com/data/icons/food-delivery-aesthetics-vol-1/256/Delivery_Zone_1-512.png"
                },
                footer = {
                    text = Webhooks.Footer
                }
            }
            local embedJson = json.encode({username = Webhooks.UserProfile['Name'], avatar_url = Webhooks.UserProfile['Image'], embeds = { embed } })
            PerformHttpRequest(Webhooks.URLS['GwBesitzer'], function(err, text, headers) end, 'POST', embedJson, { ['Content-Type'] = 'application/json' })
        end
    end)
end