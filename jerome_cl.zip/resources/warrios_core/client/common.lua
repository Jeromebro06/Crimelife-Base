exports('getSharedObject', function()
	return ESX
end)

AddEventHandler("warrios_core:🌹🌹:getSharedObject", function(cb)
    cb(ESX)
end)