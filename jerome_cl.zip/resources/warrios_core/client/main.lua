local pickups = {}

CreateThread(function()
	while true do
		Wait(100)
		if NetworkIsPlayerActive(PlayerId()) then
			exports.warrios_base:setAutoSpawn(false)
			DoScreenFadeOut(0)
			Wait(500)
			TSecuredServer('warrios_core:loaded')
			break
		end
	end
end)

RegisterNetEvent('warrios_core:🌹🌹:playerLoaded')
AddEventHandler('warrios_core:🌹🌹:playerLoaded', function(xPlayer, isNew, skin)
	ESX.PlayerData = xPlayer
	exports.warrios_base:spawnPlayer({
		x = ESX.PlayerData.coords.x,
		y = ESX.PlayerData.coords.y,
		z = ESX.PlayerData.coords.z + 0.25,
		heading = ESX.PlayerData.coords.heading,
		model = `mp_m_freemode_01`,
		skipFade = false
	}, function()
		TSecuredServer('warrios_core:spawned')
		TriggerEvent('warrios_core:spawned')
		TriggerEvent('warrios_core:🌹🌹:restoreLoadout')
		if isNew then
			TriggerEvent('wallahduhastnenkleinen:gebmaherDefaultModel', skin.sex == 0)
		elseif skin then
			TriggerEvent('wallahduhastnenkleinen:gebmaherSkin', skin)
		end
		TriggerEvent('warrios_core:🌹🌹:loadingScreenOff')
		ShutdownLoadingScreen()
		ShutdownLoadingScreenNui()
	end)
	ESX.PlayerLoaded = true
	while ESX.PlayerData.ped == nil do Wait(20) end
	if Config.EnablePVP then
		SetCanAttackFriendly(ESX.PlayerData.ped, true, false)
		NetworkSetFriendlyFireOption(true)
	end
	for i = 1, #(Config.RemoveHudCommonents) do
		if Config.RemoveHudCommonents[i] then
			SetHudComponentPosition(i, 999999.0, 999999.0)
		end
	end
	if Config.DisableDispatchServices then
		for i = 1, 15 do
			EnableDispatchService(i, false)
		end
	end
	StartServerSyncLoops()
end)

RegisterNetEvent('warrios_core:🌹🌹:onPlayerLogout')
AddEventHandler('warrios_core:🌹🌹:onPlayerLogout', function()
	ESX.PlayerLoaded = false
end)

RegisterNetEvent('warrios_core:🌹🌹:setMaxWeight')
AddEventHandler('warrios_core:🌹🌹:setMaxWeight', function(newMaxWeight) ESX.SetPlayerData("maxWeight", newMaxWeight) end)

local function onPlayerSpawn()
	ESX.SetPlayerData('ped', PlayerPedId())
	ESX.SetPlayerData('dead', false)
end
AddEventHandler('playerSpawned', onPlayerSpawn)
AddEventHandler('warrios_core:spawned', onPlayerSpawn)
AddEventHandler('warrios_core:🎂🎂:died', function()
	ESX.SetPlayerData('ped', PlayerPedId())
	ESX.SetPlayerData('dead', true)
end)

AddEventHandler('wallahduhastnenkleinen:modelLoaded', function()
	while not ESX.PlayerLoaded do
		Wait(100)
	end
	TriggerEvent('warrios_core:🌹🌹:restoreLoadout')
end)

AddEventHandler('warrios_core:🌹🌹:restoreLoadout', function()
	ESX.SetPlayerData('ped', PlayerPedId())
	local ammoTypes = {}
	RemoveAllPedWeapons(ESX.PlayerData.ped, true)
	for _, v in ipairs(ESX.PlayerData.loadout) do
		local weaponName = v.name
		local weaponHash = joaat(weaponName)
		GiveWeaponToPed(ESX.PlayerData.ped, weaponHash, 0, false, false)
		SetPedWeaponTintIndex(ESX.PlayerData.ped, weaponHash, v.tintIndex)
		local ammoType = GetPedAmmoTypeFromWeapon(ESX.PlayerData.ped, weaponHash)
		for _, v2 in ipairs(v.components) do
			local componentHash = ESX.GetWeaponComponent(weaponName, v2).hash
			GiveWeaponComponentToPed(ESX.PlayerData.ped, weaponHash, componentHash)
		end
		if not ammoTypes[ammoType] then
			AddAmmoToPed(ESX.PlayerData.ped, weaponHash, v.ammo)
			ammoTypes[ammoType] = true
		end
	end
end)

AddStateBagChangeHandler('VehicleProperties', nil, function(bagName, _, value)
	if not value then
		return
	end
	local netId = bagName:gsub('entity:', '')
	local timer = GetGameTimer()
	while not NetworkDoesEntityExistWithNetworkId(tonumber(netId)) do
		Wait(0)
		if GetGameTimer() - timer > 10000 then
			return
		end
	end
	local vehicle = NetToVeh(tonumber(netId))
	local timer2 = GetGameTimer()
	while NetworkGetEntityOwner(vehicle) ~= PlayerId() do
		Wait(0)
		if GetGameTimer() - timer2 > 10000 then
			return
		end
	end
	ESX.Game.SetVehicleProperties(vehicle, value)
end)

RegisterNetEvent('warrios_core:🌹🌹:setAccountMoney')
AddEventHandler('warrios_core:🌹🌹:setAccountMoney', function(account)
	for i = 1, #(ESX.PlayerData.accounts) do
		if ESX.PlayerData.accounts[i].name == account.name then
			ESX.PlayerData.accounts[i] = account
			break
		end
	end
	ESX.SetPlayerData('accounts', ESX.PlayerData.accounts)
end)

RegisterNetEvent('warrios_core:🌹🌹:removeWeaponComponent')
AddEventHandler('warrios_core:🌹🌹:removeWeaponComponent', function(weapon, weaponComponent)
	local componentHash = ESX.GetWeaponComponent(weapon, weaponComponent).hash
	RemoveWeaponComponentFromPed(ESX.PlayerData.ped, joaat(weapon), componentHash)
end)

RegisterNetEvent('warrios_core:🌹🌹:setJob')
AddEventHandler('warrios_core:🌹🌹:setJob', function(Job)
	ESX.SetPlayerData('job', Job)
end)

function StartServerSyncLoops()
	CreateThread(function()
		local currentWeapon = { Ammo = 0 }
		while ESX.PlayerLoaded do
			local sleep = 1500
			if GetSelectedPedWeapon(ESX.PlayerData.ped) ~= -1569615261 then
				sleep = 1000
				local _, weaponHash = GetCurrentPedWeapon(ESX.PlayerData.ped, true)
				local weapon = ESX.GetWeaponFromHash(weaponHash)
				if weapon then
					local ammoCount = GetAmmoInPedWeapon(ESX.PlayerData.ped, weaponHash)
					if weapon.name ~= currentWeapon.name then
						currentWeapon.Ammo = ammoCount
						currentWeapon.name = weapon.name
					else
						if ammoCount ~= currentWeapon.Ammo then
							currentWeapon.Ammo = ammoCount
							TSecuredServer('warrios_core:update', weapon.name, ammoCount)
						end
					end
				end
			end
			Wait(sleep)
		end
	end)
end

RegisterNetEvent("warrios_core:🌹🌹:tpm")
AddEventHandler("warrios_core:🌹🌹:tpm", function()
	local GetEntityCoords = GetEntityCoords
	local GetGroundZFor_3dCoord = GetGroundZFor_3dCoord
	local GetFirstBlipInfoId = GetFirstBlipInfoId
	local DoesBlipExist = DoesBlipExist
	local DoScreenFadeOut = DoScreenFadeOut
	local GetBlipInfoIdCoord = GetBlipInfoIdCoord
	local GetVehiclePedIsIn = GetVehiclePedIsIn
	ESX.TriggerServerCallback("warrios_core:🌹🌹:isUserAdmin", function(admin)
		if not admin then
			return
		end
		local blipMarker = GetFirstBlipInfoId(8)
		if not DoesBlipExist(blipMarker) then
			return 'marker'
		end
		DoScreenFadeOut(650)
		while not IsScreenFadedOut() do
			Wait(0)
		end
		local ped, coords = ESX.PlayerData.ped, GetBlipInfoIdCoord(blipMarker)
		local vehicle = GetVehiclePedIsIn(ped, false)
		local oldCoords = GetEntityCoords(ped)
		local x, y, groundZ, Z_START = coords['x'], coords['y'], 850.0, 950.0
		local found = false
		FreezeEntityPosition(vehicle > 0 and vehicle or ped, true)
		for i = Z_START, 0, -25.0 do
			local z = i
			if (i % 2) ~= 0 then
				z = Z_START - i
			end
			NewLoadSceneStart(x, y, z, x, y, z, 50.0, 0)
			local curTime = GetGameTimer()
			while IsNetworkLoadingScene() do
				if GetGameTimer() - curTime > 1000 then
					break
				end
				Wait(0)
			end
			NewLoadSceneStop()
			SetPedCoordsKeepVehicle(ped, x, y, z)
			while not HasCollisionLoadedAroundEntity(ped) do
				RequestCollisionAtCoord(x, y, z)
				if GetGameTimer() - curTime > 1000 then
					break
				end
				Wait(0)
			end
			found, groundZ = GetGroundZFor_3dCoord(x, y, z, false)
			if found then
				Wait(0)
				SetPedCoordsKeepVehicle(ped, x, y, groundZ)
				break
			end
			Wait(0)
		end
		DoScreenFadeIn(650)
		FreezeEntityPosition(vehicle > 0 and vehicle or ped, false)
		if not found then
			SetPedCoordsKeepVehicle(ped, oldCoords['x'], oldCoords['y'], oldCoords['z'] - 1.0)
		end
		SetPedCoordsKeepVehicle(ped, x, y, groundZ)
	end)
end)
ESX.RegisterClientCallback("warrios_core:🌹🌹:GetVehicleType", function(cb, model)
	cb(ESX.GetVehicleType(model))
end)
RegisterNetEvent('warrios_core:🌹🌹:updatePlayerData', function(key, val)
	ESX.SetPlayerData(key, val)
end)