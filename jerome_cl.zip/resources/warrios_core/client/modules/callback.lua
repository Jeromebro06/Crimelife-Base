local RequestId = 0
local serverRequests = {}
local clientCallbacks = {}
ESX.TriggerServerCallback = function(eventName, callback, ...)
	serverRequests[RequestId] = callback
	TSecuredServer('warrios_core:🌹🌹:servercb', eventName, RequestId, GetInvokingResource() or "unknown", ...)
	RequestId = RequestId + 1
end

RegisterNetEvent('warrios_core:🌹🌹:serverCallback', function(requestId, invoker, ...)
	if not serverRequests[requestId] then
		return
	end
	serverRequests[requestId](...)
	serverRequests[requestId] = nil
end)

ESX.RegisterClientCallback = function(eventName, callback)
	clientCallbacks[eventName] = callback
end

RegisterNetEvent('warrios_core:🌹🌹:triggerClientCallback', function(eventName, requestId, invoker, ...)
	if not clientCallbacks[eventName] then
		return
	end
	clientCallbacks[eventName](function(...)
		TSecuredServer('warrios_core:🌹🌹:clientcb', requestId, invoker, ...)
	end, ...)
end)