function ESX.Scaleform.Utils.RequestScaleformMovie(movie)
	local scaleform = RequestScaleformMovie(movie)
	while not HasScaleformMovieLoaded(scaleform) do
		Wait(0)
	end
	return scaleform
end
