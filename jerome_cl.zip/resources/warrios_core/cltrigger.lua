function TSecuredServer(event, ...)
    TriggerServerEvent(event, ...)
end