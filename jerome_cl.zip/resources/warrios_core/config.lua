Config                      = {}
Config.Locale               = 'de'

Config.Accounts             = {
	bank = {
		label = TranslateCap('account_bank'),
		round = true
	},
	black_money = {
		label = TranslateCap('account_black_money'),
		round = true
	},
	money = {
		label = TranslateCap('account_money'),
		round = true
	}
}

Config.StartingAccountMoney = { money = 1000000 }


Config.DefaultSpawns = {
	{ x = -2258.1250,  y =  3252.7671, z =  32.8102, heading = 234.3152 },
}

Config.AdminGroups = {
	['pl'] = true,
	['admin'] = true
}

Config.MaxWeight                 = 500        -- the max inventory weight without backpack
Config.EnablePVP                 = true      -- Allow Player to player combat

Config.DistanceGive              = 4.0   -- Max distance when giving items, weapons etc.

Config.DisableDispatchServices   = true -- Disable Dispatch services
Config.RemoveHudCommonents       = {
	[1] = false,                         --WANTED_STARS,
	[2] = false,                         --WEAPON_ICON
	[3] = true,                         --CASH
	[4] = true,                         --MP_CASH
	[5] = false,                         --MP_MESSAGE
	[6] = true,                         --VEHICLE_NAME
	[7] = true,                         -- AREA_NAME
	[8] = true,                         -- VEHICLE_CLASS
	[9] = true,                         --STREET_NAME
	[10] = false,                        --HELP_TEXT
	[11] = false,                        --FLOATING_HELP_TEXT_1
	[12] = false,                        --FLOATING_HELP_TEXT_2
	[13] = true,                        --CASH_CHANGE
	[14] = false,                        --RETICLE
	[15] = true,                        --SUBTITLE_TEXT
	[16] = true,                        --RADIO_STATIONS
	[17] = true,                        --SAVING_GAME,
	[18] = false,                        --GAME_STREAM
	[19] = false,                        --WEAPON_WHEEL
	[20] = true,                        --WEAPON_WHEEL_STATS
	[21] = false,                        --HUD_COMPONENTS
	[22] = false,                        --HUD_WEAPONS
}