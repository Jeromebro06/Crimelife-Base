fx_version 'adamant'
lua54 'yes'
game 'gta5'

client_script 'cltrigger.lua'
server_script 'dist/build.js'

shared_scripts {
	'locale.lua',
	'locales/*.lua',
	'config.lua',
	'config.weapons.lua',
}

server_scripts {
	'lib/MySQL.lua',
	'server/common.lua',
	'server/modules/callback.lua',
	'server/classes/player.lua',
	'server/functions.lua',
	'server/onesync.lua',
	'server/main.lua',
	'common/modules/*.lua',
	'common/functions.lua'
}


client_scripts {
	'client/common.lua',
	'client/functions.lua',
	'client/wrapper.lua',
	'client/modules/callback.lua',
	'client/main.lua',
	'common/modules/*.lua',
	'common/functions.lua',
	'common/functions.lua',
	'client/modules/death.lua',
	'client/modules/scaleform.lua',
	'client/modules/streaming.lua',
}

dependencies {
	'/native:0x6AE51D4B',
	'/server:5104',
}

files {
	'web/build/**/*',
	'imports.lua',
	'locale.js',
	'html/ui.html',
	'html/css/app.css',
	'html/js/mustache.min.js',
	'html/js/wrapper.js',
	'html/js/app.js',
	'html/fonts/pdown.ttf',
	'html/fonts/bankgothic.ttf',
}

ui_page {
	'html/ui.html'
}

provide 'mysql-async'
provide 'ghmattimysql'

convar_category 'OxMySQL' {
	'Configuration',
	{
		{ 'Connection string', 'mysql_connection_string', 'CV_STRING', 'mysql://user:password@localhost/database' },
		{ 'Debug', 'mysql_debug', 'CV_BOOL', 'false' }
	}
}

shared_script "anvil.lua"