ESX = exports['warrios_core']:getSharedObject()
if not IsDuplicityVersion() then
    AddEventHandler('warrios_core:🌹🌹:setPlayerData', function(key, val, last)
        if GetInvokingResource() == 'warrios_core' then
            ESX.PlayerData[key] = val
            if OnPlayerData then
                OnPlayerData(key, val, last)
            end
        end
    end)
    RegisterNetEvent('warrios_core:🌹🌹:playerLoaded', function(xPlayer)
        ESX.PlayerData = xPlayer
        ESX.PlayerLoaded = true
    end)
    RegisterNetEvent('warrios_core:🌹🌹:onPlayerLogout', function()
        ESX.PlayerLoaded = false
        ESX.PlayerData = {}
    end)
end