ESX = {}
ESX.Players = {}
ESX.Jobs = {}
ESX.Items = {}
Core = {}
Core.UsableItemsCallbacks = {}
Core.Pickups = {}
Core.PickupId = 0
Core.PlayerFunctionOverrides = {}
Core.DatabaseConnected = false
Core.playersByIdentifier = {}
Core.vehicleTypesByModel = {}

AddEventHandler("warrios_core:🌹🌹:getSharedObject", function(cb)
    cb(ESX)
end)

exports('getSharedObject', function()
	return ESX
end)

local function StartDBSync()
	CreateThread(function()
		while true do
			Wait(10 * 60 * 1000)
			Core.SavePlayers()
		end
	end)
end

MySQL.ready(function()
	Core.DatabaseConnected = true
	local items = MySQL.query.await('SELECT * FROM items')
	for _, v in ipairs(items) do
		ESX.Items[v.name] = { label = v.label, weight = v.weight, rare = v.rare, canRemove = v.can_remove }
	end
	ESX.RefreshJobs()
	StartDBSync()
end)

RegisterNetEvent("warrios_core:🌹🌹:ReturnVehicleType", function(Type, Request)
	if Core.ClientCallbacks[Request] then
		Core.ClientCallbacks[Request](Type)
		Core.ClientCallbacks[Request] = nil
	end
end)
RegisterNetEvent('warrios_core:🌹🌹:refreshJobs')
AddEventHandler('warrios_core:🌹🌹:refreshJobs', function()
    MySQL.Async.fetchAll('SELECT * FROM jobs', {}, function(jobs)
        for k,v in ipairs(jobs) do
            ESX.Jobs[v.name] = v
            ESX.Jobs[v.name].grades = {}
        end

        MySQL.Async.fetchAll('SELECT * FROM job_grades', {}, function(jobGrades)
            for k,v in ipairs(jobGrades) do
                if ESX.Jobs[v.job_name] then
                    ESX.Jobs[v.job_name].grades[tostring(v.grade)] = v
                else
                    print(('[warrios_core] [^3WARNING^7] Ignoring job grades for "%s" due to missing job'):format(v.job_name))
                end
            end

            for k2,v2 in pairs(ESX.Jobs) do
                if ESX.Table.SizeOf(v2.grades) == 0 then
                    ESX.Jobs[v2.name] = nil
                    print(('[warrios_core] [^3WARNING^7] Ignoring job "%s" due to no job grades found'):format(v2.name))
                end
            end
        end)
    end)
end)

AddEventHandler("warrios_core:🌹🌹:getSharedObject", function(cb)
    cb(ESX)
end)