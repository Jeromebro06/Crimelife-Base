function Core.SavePlayer(xPlayer, cb)
	local parameters <const> = {
		json.encode(xPlayer.getAccounts(true)),
		xPlayer.job.name,
		xPlayer.job.grade,
		xPlayer.group,
		json.encode(xPlayer.getCoords()),
		json.encode(xPlayer.getInventory(true)),
		json.encode(xPlayer.getLoadout(true)),
		json.encode(xPlayer.getMeta()),
		xPlayer.identifier
	}

	MySQL.prepare(
		'UPDATE `users` SET `accounts` = ?, `job` = ?, `job_grade` = ?, `group` = ?, `position` = ?, `inventory` = ?, `loadout` = ?, `metadata` = ? WHERE `identifier` = ?',
		parameters,
		function(affectedRows)
			if affectedRows == 1 then
				print(('[^2INFO^7] Saved player ^5"%s^7"'):format(xPlayer.name))
				TriggerEvent('warrios_core:🌹🌹:playerSaved', xPlayer.playerId, xPlayer)
			end
			if cb then
				cb()
			end
		end
	)
end

function Core.SavePlayers(cb)
	local xPlayers <const> = ESX.Players
	if not next(xPlayers) then
		return
	end

	local startTime <const> = os.time()
	local parameters = {}

	for _, xPlayer in pairs(ESX.Players) do
		parameters[#parameters + 1] = {
			json.encode(xPlayer.getAccounts(true)),
			xPlayer.job.name,
			xPlayer.job.grade,
			xPlayer.group,
			json.encode(xPlayer.getCoords()),
			json.encode(xPlayer.getInventory(true)),
			json.encode(xPlayer.getLoadout(true)),
			json.encode(xPlayer.getMeta()),
			xPlayer.identifier
		}
	end

	MySQL.prepare(
		"UPDATE `users` SET `accounts` = ?, `job` = ?, `job_grade` = ?, `group` = ?, `position` = ?, `inventory` = ?, `loadout` = ?, `metadata` = ? WHERE `identifier` = ?",
		parameters,
		function(results)
			if not results then
				return
			end

			if type(cb) == 'function' then
				return cb()
			end

			print(('[^2INFO^7] Saved ^5%s^7 %s over ^5%s^7 ms'):format(#parameters, #parameters > 1 and 'players' or 'player', ESX.Math.Round((os.time() - startTime) / 1000000, 2)))
		end
	)
end

ESX.GetPlayers = GetPlayers

local function checkTable(key, val, player, xPlayers)
	for valIndex = 1, #val do
		local value = val[valIndex]
		if not xPlayers[value] then
			xPlayers[value] = {}
		end

		if (key == 'job' and player.job.name == value) or player[key] == value then
			xPlayers[value][#xPlayers[value] + 1] = player
		end
	end
end

function ESX.GetExtendedPlayers(key, val)
	if not key then return ESX.Players end

	local xPlayers = {}
	if type(val) == "table" then
		for _, v in pairs(ESX.Players) do
			checkTable(key, val, v, xPlayers)
		end
	else
		for _, v in pairs(ESX.Players) do
			if (key == 'job' and v.job.name == val) or v[key] == val then
				xPlayers[#xPlayers + 1] = v
			end
		end
	end

	return xPlayers
end

function ESX.GetPlayerFromId(source)
	return ESX.Players[tonumber(source)]
end

function ESX.GetPlayerFromIdentifier(identifier)
	return Core.playersByIdentifier[identifier]
end

function ESX.GetIdentifier(playerId)
	local fxDk = GetConvarInt('sv_fxdkMode', 0)
	if fxDk == 1 then
		return "ESX-DEBUG-LICENCE"
	end
	for _, v in ipairs(GetPlayerIdentifiers(playerId)) do
		if string.match(v, 'license:') then
			local identifier = string.gsub(v, 'license:', '')
			return identifier
		end
	end
end

function ESX.GetVehicleType(model, player, cb)
	model = type(model) == 'string' and joaat(model) or model

	if Core.vehicleTypesByModel[model] then
		return cb(Core.vehicleTypesByModel[model])
	end

	ESX.TriggerClientCallback(player, "warrios_core:🌹🌹:GetVehicleType", function(vehicleType)
		Core.vehicleTypesByModel[model] = vehicleType
		cb(vehicleType)
	end, model)
end

function ESX.CreateJob(name, label, grades)
	if not name then
		return print('[^3WARNING^7] missing argument `name(string)` while creating a job')
	end

	if not label then
		return print('[^3WARNING^7] missing argument `label(string)` while creating a job')
	end

	if not grades or not next(grades) then
		return print('[^3WARNING^7] missing argument `grades(table)` while creating a job!')
	end

	local parameters = {}
	local job = { name = name, label = label, grades = {} }

	for _, v in pairs(grades) do
		job.grades[tostring(v.grade)] = { job_name = name, grade = v.grade, name = v.name, label = v.label, salary = v.salary, skin_male = {}, skin_female = {} }
		parameters[#parameters + 1] = { name, v.grade, v.name, v.label, v.salary }
	end

	MySQL.insert('INSERT IGNORE INTO jobs (name, label) VALUES (?, ?)', { name, label })
	MySQL.prepare('INSERT INTO job_grades (job_name, grade, name, label, salary) VALUES (?, ?, ?, ?, ?)', parameters)

	ESX.Jobs[name] = job
end

function ESX.RefreshJobs()
	local Jobs = {}
	local jobs = MySQL.query.await('SELECT * FROM jobs')

	for _, v in ipairs(jobs) do
		Jobs[v.name] = v
		Jobs[v.name].grades = {}
	end

	local jobGrades = MySQL.query.await('SELECT * FROM job_grades')

	for _, v in ipairs(jobGrades) do
		if Jobs[v.job_name] then
			Jobs[v.job_name].grades[tostring(v.grade)] = v
		else
			print(('[^3WARNING^7] Ignoring job grades for ^5"%s"^0 due to missing job'):format(v.job_name))
		end
	end

	for _, v in pairs(Jobs) do
		if ESX.Table.SizeOf(v.grades) == 0 then
			Jobs[v.name] = nil
			print(('[^3WARNING^7] Ignoring job ^5"%s"^0 due to no job grades found'):format(v.name))
		end
	end

	if not Jobs then
		-- Fallback data, if no jobs exist
		ESX.Jobs['unemployed'] = { label = 'Unemployed', grades = { ['0'] = { grade = 0, label = 'Unemployed', salary = 200, skin_male = {}, skin_female = {} } } }
	else
		ESX.Jobs = Jobs
	end
end

function ESX.RegisterUsableItem(item, cb)
	Core.UsableItemsCallbacks[item] = cb
end

function ESX.RegisterPlayerFunctionOverrides(index, overrides)
	Core.PlayerFunctionOverrides[index] = overrides
end

function ESX.SetPlayerFunctionOverride(index)
	if not index or not Core.PlayerFunctionOverrides[index] then
		return print('[^3WARNING^7] No valid index provided.')
	end

	Config.PlayerFunctionOverride = index
end

function ESX.GetItemLabel(item)
	if ESX.Items[item] then
		return ESX.Items[item].label
	else
		print(('[^3WARNING^7] Attemting to get invalid Item -> ^5%s^7'):format(item))
	end
end

function ESX.GetJobs()
	return ESX.Jobs
end

function ESX.GetUsableItems()
	local Usables = {}
	for k in pairs(Core.UsableItemsCallbacks) do
		Usables[k] = true
	end
	return Usables
end

function ESX.DoesJobExist(job, grade)
	grade = tostring(grade)

	if job and grade then
		if ESX.Jobs[job] and ESX.Jobs[job].grades[grade] then
			return true
		end
	end

	return false
end

function Core.IsPlayerAdmin(playerId)
	if (IsPlayerAceAllowed(playerId, 'command') or GetConvar('sv_lan', '') == 'true') and true or false then
		return true
	end

	local xPlayer = ESX.Players[playerId]

	if xPlayer then
		if Config.AdminGroups[xPlayer.group] then
			return true
		end
	end

	return false
end
