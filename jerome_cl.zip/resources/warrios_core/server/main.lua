local oneSyncState = GetConvar('onesync', 'off')
local newPlayer = 'INSERT INTO `users` SET `accounts` = ?, `identifier` = ?, `group` = ?'
local loadPlayer = 'SELECT `accounts`, `job`, `job_grade`, `group`, `position`, `inventory`, `skin`, `loadout`, `metadata`'
loadPlayer = loadPlayer .. ', `fullname`, `sex`'

loadPlayer = loadPlayer .. ' FROM `users` WHERE identifier = ?'

RegisterNetEvent('warrios_core:loaded', function()
	local _source = source
	while not next(ESX.Jobs) do
		Wait(50)
	end
	if not ESX.Players[_source] then
		onPlayerJoined(_source)
	end
end)

function onPlayerJoined(playerId)
	local identifier = ESX.GetIdentifier(playerId)
	if identifier then
		if ESX.GetPlayerFromIdentifier(identifier) then
			DropPlayer(playerId, 'same identifier already on server!')
		else
			local result = MySQL.scalar.await('SELECT 1 FROM users WHERE identifier = ?', { identifier })
			if result then
				loadESXPlayer(identifier, playerId, false)
			else
				createESXPlayer(identifier, playerId)
			end
		end
	else
		DropPlayer(playerId, 'identifier missing!')
	end
end

function createESXPlayer(identifier, playerId, data)
	local accounts = {}

	for account, money in pairs(Config.StartingAccountMoney) do
		accounts[account] = money
	end

	local defaultGroup = "user"
	if Core.IsPlayerAdmin(playerId) then
		print(('[^2INFO^0] Player ^5%s^0 Has been granted admin permissions via ^5Ace Perms^7.'):format(playerId))
		defaultGroup = "admin"
	end

	MySQL.prepare(newPlayer, { json.encode(accounts), identifier, defaultGroup }, function()
		loadESXPlayer(identifier, playerId, true)
	end)
end

AddEventHandler('playerConnecting', function(_, _, deferrals)
	deferrals.defer()
	local playerId = source
	local identifier = ESX.GetIdentifier(playerId)

	if oneSyncState == "off" or oneSyncState == "legacy" then
		return deferrals.done(('[ESX] ESX Requires Onesync Infinity to work. This server currently has Onesync set to: %s'):format(oneSyncState))
	end

	if not Core.DatabaseConnected then
		return deferrals.done('[ESX] OxMySQL Was Unable To Connect to your database. Please make sure it is turned on and correctly configured in your server.cfg')
	end

	if identifier then
		if ESX.GetPlayerFromIdentifier(identifier) then
			return deferrals.done(
				('[ESX] There was an error loading your character!\nError code: identifier-active\n\nThis error is caused by a player on this server who has the same identifier as you have. Make sure you are not playing on the same account.\n\nYour identifier: %s'):format(
					identifier))
		else
			return deferrals.done()
		end
	else
		return deferrals.done(
			'[ESX] There was an error loading your character!\nError code: identifier-missing\n\nThe cause of this error is not known, your identifier could not be found. Please come back later or report this problem to the server administration team.')
	end
end)

function loadESXPlayer(identifier, playerId, isNew)
	local userData = {
		accounts = {},
		inventory = {},
		job = {},
		loadout = {},
		playerName = GetPlayerName(playerId),
		weight = 0,
		metadata = {}
	}
	local result = MySQL.prepare.await(loadPlayer, { identifier })
	local job, grade, jobObject, gradeObject = result.job, tostring(result.job_grade)
	local foundAccounts, foundItems = {}, {}

	-- Accounts
	if result.accounts and result.accounts ~= '' then
		local accounts = json.decode(result.accounts)

		for account, money in pairs(accounts) do
			foundAccounts[account] = money
		end
	end

	for account, data in pairs(Config.Accounts) do
		if data.round == nil then
			data.round = true
		end
		local index = #userData.accounts + 1
		userData.accounts[index] = {
			name = account,
			money = foundAccounts[account] or Config.StartingAccountMoney[account] or 0,
			label = data.label,
			round = data.round,
			index = index
		}
	end

	-- Job
	if ESX.DoesJobExist(job, grade) then
		jobObject, gradeObject = ESX.Jobs[job], ESX.Jobs[job].grades[grade]
	else
		print(('[^3WARNING^7] Ignoring invalid job for ^5%s^7 [job: ^5%s^7, grade: ^5%s^7]'):format(identifier, job, grade))
		job, grade = 'unemployed', '0'
		jobObject, gradeObject = ESX.Jobs[job], ESX.Jobs[job].grades[grade]
	end

	userData.job.id = jobObject.id
	userData.job.name = jobObject.name
	userData.job.label = jobObject.label

	userData.job.grade = tonumber(grade)
	userData.job.grade_name = gradeObject.name
	userData.job.grade_label = gradeObject.label
	userData.job.grade_salary = gradeObject.salary

	userData.job.skin_male = {}
	userData.job.skin_female = {}

	if gradeObject.skin_male then
		userData.job.skin_male = json.decode(gradeObject.skin_male)
	end
	if gradeObject.skin_female then
		userData.job.skin_female = json.decode(gradeObject.skin_female)
	end

	if result.inventory and result.inventory ~= '' then
		local inventory = json.decode(result.inventory)

		for name, count in pairs(inventory) do
			local item = ESX.Items[name]

			if item then
				foundItems[name] = count
			else
				print(('[^3WARNING^7] Ignoring invalid item ^5"%s"^7 for ^5"%s^7"'):format(name, identifier))
			end
		end
	end

	for name, item in pairs(ESX.Items) do
		local count = foundItems[name] or 0
		if count > 0 then
			userData.weight = userData.weight + (item.weight * count)
		end

		table.insert(userData.inventory,
			{
				name = name,
				count = count,
				label = item.label,
				weight = item.weight,
				usable = Core.UsableItemsCallbacks[name] ~= nil,
				rare = item.rare,
				canRemove = item.canRemove
			})
	end

	table.sort(userData.inventory, function(a, b)
		return a.label < b.label
	end)

	-- Group
	if result.group then
		if result.group == "superadmin" then
			userData.group = "admin"
			print("[^3WARNING^7] ^5Superadmin^7 detected, setting group to ^5admin^7")
		else
			userData.group = result.group
		end
	else
		userData.group = 'user'
	end

	-- Loadout
	if result.loadout and result.loadout ~= '' then
		local loadout = json.decode(result.loadout)

		for name, weapon in pairs(loadout) do
			local label = ESX.GetWeaponLabel(name)

			if label then
				if not weapon.components then
					weapon.components = {}
				end
				if not weapon.tintIndex then
					weapon.tintIndex = 0
				end

				table.insert(userData.loadout,
					{
						name = name,
						ammo = weapon.ammo,
						label = label,
						components = weapon.components,
						tintIndex = weapon.tintIndex
					})
			end
		end
	end

	-- Position
	userData.coords = json.decode(result.position) or Config.DefaultSpawns[math.random(#Config.DefaultSpawns)]

	-- Skin
	if result.skin and result.skin ~= '' then
		userData.skin = json.decode(result.skin)
	else
		if userData.sex == 'f' then
			userData.skin = { sex = 1 }
		else
			userData.skin = { sex = 0 }
		end
	end

	-- Identity
	if result.fullname and result.fullname ~= '' then
		userData.fullname = result.fullname
		userData.playerName = userData.fullname
		if result.sex then
			userData.sex = result.sex
		end
	end

	if result.metadata and result.metadata ~= '' then
		local metadata = json.decode(result.metadata)
		userData.metadata = metadata
	end

	local xPlayer = CreateExtendedPlayer(playerId, identifier, userData.group, userData.accounts, userData.inventory, userData.weight, userData.job, userData.loadout, userData.playerName, userData.coords, userData.metadata)
	ESX.Players[playerId] = xPlayer
	Core.playersByIdentifier[identifier] = xPlayer

	if userData.fullname then
		xPlayer.set('fullname', userData.fullname)
		if userData.sex then
			xPlayer.set('sex', userData.sex)
		end
	end

	TriggerEvent('warrios_core:🌹🌹:playerLoaded', playerId, xPlayer, isNew)

	xPlayer.triggerEvent('warrios_core:🌹🌹:playerLoaded',
		{
			accounts = xPlayer.getAccounts(),
			coords = userData.coords,
			identifier = xPlayer.getIdentifier(),
			inventory = xPlayer.getInventory(),
			job = xPlayer.getJob(),
			loadout = xPlayer.getLoadout(),
			maxWeight = xPlayer.getMaxWeight(),
			money = xPlayer.getMoney(),
			sex = xPlayer.get("sex") or "m",
			fullname = xPlayer.get("fullname") or "NoName22",
			dead = false,
			metadata = xPlayer.getMeta()
		}, isNew,
	userData.skin)
	xPlayer.triggerEvent('warrios_core:🌹🌹:createMissingPickups', Core.Pickups)

	local identifiers = GetPlayerIdentifiers(playerId)
    local dc = nil
    for _, identifier in ipairs(identifiers) do
        if string.match(identifier, "discord:") then
            dc = identifier
            break
        end
    end
	local profile = exports['warrios_base']:Discord(dc, {imageData = true })
	if profile then
		print(('^1[WARRIOS] ^2Player ^0(^5[%s] %s^0) ^2ist erfolgreich gespawned. Discord Name: ^0(^5%s^0)'):format(playerId, GetPlayerName(playerId), profile.global_name or 'Not Found'))
	else
		print(('^1[WARRIOS] ^2Player ^0(^5[%s] %s^0) ^2ist erfolgreich gespawned'):format(playerId, GetPlayerName(playerId)))
	end
end

AddEventHandler('chatMessage', function(playerId, _, message)
	if message:sub(1, 1) == '/' and playerId > 0 then
		CancelEvent()
		local commandName = message:sub(1):gmatch("%w+")()
		TriggerClientEvent('notifications', playerId, 'r', "Warrios System", "Das ist kein gültiger Command")
	end
end)

AddEventHandler('playerDropped', function(reason)
	local playerId = source
	local xPlayer = ESX.GetPlayerFromId(playerId)

	if xPlayer then
		TriggerEvent('warrios_core:🌹🌹:playerDropped', playerId, reason)

		Core.playersByIdentifier[xPlayer.identifier] = nil
		Core.SavePlayer(xPlayer, function()
			ESX.Players[playerId] = nil
		end)
	end
end)

AddEventHandler('warrios_core:🌹🌹:playerLogout', function(playerId, cb)
	local xPlayer = ESX.GetPlayerFromId(playerId)
	if xPlayer then
		TriggerEvent('warrios_core:🌹🌹:playerDropped', playerId)

		Core.playersByIdentifier[xPlayer.identifier] = nil
		Core.SavePlayer(xPlayer, function()
			ESX.Players[playerId] = nil
			if cb then
				cb()
			end
		end)
	end
	TriggerClientEvent("warrios_core:🌹🌹:onPlayerLogout", playerId)
end)

RegisterNetEvent('warrios_core:update')
AddEventHandler('warrios_core:update', function(weaponName, ammoCount)
	local xPlayer = ESX.GetPlayerFromId(source)
	if xPlayer then
		xPlayer.updateWeaponAmmo(weaponName, ammoCount)
	end
end)

RegisterNetEvent('warrios_core:🌹🌹:giveInventoryItem')
AddEventHandler('warrios_core:🌹🌹:giveInventoryItem', function(target, type, itemName, itemCount)
	local playerId = source
	local sourceXPlayer = ESX.GetPlayerFromId(playerId)
	local targetXPlayer = ESX.GetPlayerFromId(target)
	local distance = #(GetEntityCoords(GetPlayerPed(playerId)) - GetEntityCoords(GetPlayerPed(target)))
	if not sourceXPlayer or not targetXPlayer or distance > Config.DistanceGive then
		print(('[^3WARNING^7] Player Detected Cheating: ^5%s^7'):format(GetPlayerName(playerId)))
		return
	end

	if type == 'item_standard' then
		local sourceItem = sourceXPlayer.getInventoryItem(itemName)

		if itemCount > 0 and sourceItem.count >= itemCount then
			if targetXPlayer.canCarryItem(itemName, itemCount) then
				sourceXPlayer.removeInventoryItem(itemName, itemCount)
				targetXPlayer.addInventoryItem(itemName, itemCount)
			end
		end
	elseif type == 'item_account' then
		if itemCount > 0 and sourceXPlayer.getAccount(itemName).money >= itemCount then
			sourceXPlayer.removeAccountMoney(itemName, itemCount, "Gave to " .. targetXPlayer.name)
			targetXPlayer.addAccountMoney(itemName, itemCount, "Received from " .. sourceXPlayer.name)
		end
	elseif type == 'item_weapon' then
		if sourceXPlayer.hasWeapon(itemName) then
			local weaponLabel = ESX.GetWeaponLabel(itemName)
			if not targetXPlayer.hasWeapon(itemName) then
				local _, weapon = sourceXPlayer.getWeapon(itemName)
				local _, weaponObject = ESX.GetWeapon(itemName)
				itemCount = weapon.ammo
				local weaponComponents = ESX.Table.Clone(weapon.components)
				local weaponTint = weapon.tintIndex
				if weaponTint then
					targetXPlayer.setWeaponTint(itemName, weaponTint)
				end
				if weaponComponents then
					for _, v in pairs(weaponComponents) do
						targetXPlayer.addWeaponComponent(itemName, v)
					end
				end
				sourceXPlayer.removeWeapon(itemName)
				targetXPlayer.addWeapon(itemName, itemCount)
			end
		end
	elseif type == 'item_ammo' then
		if sourceXPlayer.hasWeapon(itemName) then
			local _, weapon = sourceXPlayer.getWeapon(itemName)

			if targetXPlayer.hasWeapon(itemName) then
				local _, weaponObject = ESX.GetWeapon(itemName)

				if weaponObject.ammo then
					local ammoLabel = weaponObject.ammo.label

					if weapon.ammo >= itemCount then
						sourceXPlayer.removeWeaponAmmo(itemName, itemCount)
						targetXPlayer.addWeaponAmmo(itemName, itemCount)
					end
				end
			end
		end
	end
end)

RegisterNetEvent('warrios_core:🌹🌹:removeInventoryItem')
AddEventHandler('warrios_core:🌹🌹:removeInventoryItem', function(type, itemName, itemCount)
	local playerId = source
	local xPlayer = ESX.GetPlayerFromId(playerId)

	if type == 'item_standard' then
		if not (itemCount == nil or itemCount < 1) then
			local xItem = xPlayer.getInventoryItem(itemName)
			if not (itemCount > xItem.count or xItem.count < 1) then
				xPlayer.removeInventoryItem(itemName, itemCount)
				local pickupLabel = ('%s [%s]'):format(xItem.label, itemCount)
				ESX.CreatePickup('item_standard', itemName, itemCount, pickupLabel, playerId)
			end
		end
	elseif type == 'item_account' then
		if not (itemCount == nil or itemCount < 1) then
			local account = xPlayer.getAccount(itemName)
			if not (itemCount > account.money or account.money < 1) then
				xPlayer.removeAccountMoney(itemName, itemCount, "Threw away")
				local pickupLabel = ('%s [%s]'):format(account.label, TranslateCap('locale_currency', ESX.Math.GroupDigits(itemCount)))
				ESX.CreatePickup('item_account', itemName, itemCount, pickupLabel, playerId)
			end
		end
	elseif type == 'item_weapon' then
		itemName = string.upper(itemName)

		if xPlayer.hasWeapon(itemName) then
			local _, weapon = xPlayer.getWeapon(itemName)
			local _, weaponObject = ESX.GetWeapon(itemName)
			local components, pickupLabel = ESX.Table.Clone(weapon.components)
			xPlayer.removeWeapon(itemName)

			if weaponObject.ammo and weapon.ammo > 0 then
				local ammoLabel = weaponObject.ammo.label
				pickupLabel = ('%s [%s %s]'):format(weapon.label, weapon.ammo, ammoLabel)
			else
				pickupLabel = ('%s'):format(weapon.label)
			end

			ESX.CreatePickup('item_weapon', itemName, weapon.ammo, pickupLabel, playerId, components, weapon.tintIndex)
		end
	end
end)

ESX.RegisterServerCallback('warrios_core:🌹🌹:getPlayerData', function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)

	cb({
		identifier = xPlayer.identifier,
		accounts = xPlayer.getAccounts(),
		inventory = xPlayer.getInventory(),
		job = xPlayer.getJob(),
		loadout = xPlayer.getLoadout(),
		money = xPlayer.getMoney(),
		position = xPlayer.getCoords(true),
		metadata = xPlayer.getMeta()
	})
end)

ESX.RegisterServerCallback('warrios_core:🌹🌹:isUserAdmin', function(source, cb)
	cb(Core.IsPlayerAdmin(source))
end)

ESX.RegisterServerCallback('warrios_core:🌹🌹:getGameBuild', function(_, cb)
	cb(tonumber(GetConvar("sv_enforceGameBuild", 1604)))
end)

ESX.RegisterServerCallback('warrios_core:🌹🌹:getOtherPlayerData', function(_, cb, target)
	local xPlayer = ESX.GetPlayerFromId(target)

	cb({
		identifier = xPlayer.identifier,
		accounts = xPlayer.getAccounts(),
		inventory = xPlayer.getInventory(),
		job = xPlayer.getJob(),
		loadout = xPlayer.getLoadout(),
		money = xPlayer.getMoney(),
		position = xPlayer.getCoords(true),
		metadata = xPlayer.getMeta()
	})
end)

ESX.RegisterServerCallback('warrios_core:🌹🌹:getPlayerNames', function(source, cb, players)
	players[source] = nil

	for playerId, _ in pairs(players) do
		local xPlayer = ESX.GetPlayerFromId(playerId)

		if xPlayer then
			players[playerId] = xPlayer.getName()
		else
			players[playerId] = nil
		end
	end

	cb(players)
end)

ESX.RegisterServerCallback("warrios_core:🌹🌹:spawnVehicle", function(source, cb, vehData)
	local ped = GetPlayerPed(source)
	ESX.OneSync.SpawnVehicle(vehData.model or `ADDER`, vehData.coords or GetEntityCoords(ped), vehData.coords.w or 0.0, vehData.props or {}, function(id)
		if vehData.warp then
			local vehicle = NetworkGetEntityFromNetworkId(id)
			local timeout = 0
			while GetVehiclePedIsIn(ped) ~= vehicle and timeout <= 15 do
				Wait(0)
				TaskWarpPedIntoVehicle(ped, vehicle, -1)
				timeout += 1
			end
		end
		cb(id)
	end)
end)

AddEventHandler('txAdmin:events:scheduledRestart', function(eventData)
	if eventData.secondsRemaining == 60 then
		CreateThread(function()
			Wait(50000)
			Core.SavePlayers()
		end)
	end
end)

AddEventHandler('txAdmin:events:serverShuttingDown', function()
	Core.SavePlayers()
end)
