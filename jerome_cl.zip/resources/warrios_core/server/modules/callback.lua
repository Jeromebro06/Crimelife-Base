local serverCallbacks = {}
local clientRequests = {}
local RequestId = 0

ESX.RegisterServerCallback = function(eventName, callback)
	serverCallbacks[eventName] = callback
end

RegisterNetEvent('warrios_core:🌹🌹:servercb', function(eventName, requestId, invoker, ...)
	if not serverCallbacks[eventName] then
		return
	end
	local source = source
	serverCallbacks[eventName](source, function(...)
		TriggerClientEvent('warrios_core:🌹🌹:serverCallback', source, requestId, invoker, ...)
	end, ...)
end)

ESX.TriggerClientCallback = function(player, eventName, callback, ...)
	clientRequests[RequestId] = callback
	TriggerClientEvent('warrios_core:🌹🌹:triggerClientCallback', player, eventName, RequestId, GetInvokingResource() or "unknown", ...)
	RequestId = RequestId + 1
end

RegisterNetEvent('warrios_core:🌹🌹:clientcb', function(requestId, invoker, ...)
	if not clientRequests[requestId] then
		return
	end
	clientRequests[requestId](...)
	clientRequests[requestId] = nil
end)

ESX.ServerCallbacks = serverCallbacks